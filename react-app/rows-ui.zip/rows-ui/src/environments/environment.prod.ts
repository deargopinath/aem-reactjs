export const environment = {
    production: true,
    baseURL: 'https://lapuksnprdwafrowsdev6001.azurewebsites.net/',
    msalConfig: {
        auth: {
            clientId: 'f20654f5-fc87-402d-b64c-8cbda57056fe',
            authority:
                'https://login.microsoftonline.com/4db80b03-6d92-48a1-bc12-05c043d199c7',
        },
    },
    apiConfig: {
        scopes: ['user.read'],
        uri: 'https://graph.microsoft.com/v1.0/me',
    },
    redirectUri: '/',
    postLogoutRedirectUri: '/',
}

export const API_END_POINTS = {
    organizationalBoundry:
        'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/organizationalBoundryAssoc',
    hotRunningRail:
        'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/hotRunningRail',
    fireRisk:
        'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/fireRiskIndex',
    steamRisk:
        'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/steamRiskIndex',
    getHazardForeCast:
        'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/weeklyHazardWeather/',
    getForecast24:
        'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/weatherHourly/',
    getAlertSummaryCount:
        // 'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/alertSummaryCount/',
        'https://apim-uks-nprd-waf-6001.azure-api.net/rows-mock/api/alertSummaryCount/',
    getUserDetails:
        'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/profile/',
    setUserDetails:
        'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/profile',
    osBaseMapLight_27700:
        'https://api.os.uk/maps/raster/v1/zxy/Light_27700/{z}/{x}/{y}.png?key=',
    geoServer:
        'https://was-uks-nprd-waf-rowsdev6001.azurewebsites.net/geoserver/',
    gisMicroservices:
        'https://was-uks-nprd-waf-rowsdev6003.azurewebsites.net/api/',
    zoomToFeatures: 'zoomToFeatures',
    regionRagStatus: 'regionRagStatus',
    routeRagStatus: 'routeRagStatus',
    mduRagStatus: 'mduRagStatus',
    getWeatherImagePNG: 'getWeatherImagePNG',
    layerMetadata: 'layerMetadata',
    getDataPoints: 'getDataPoints',
    getDataPointsDataBricks: 'getDataPointsDataBricks',
    steamIndexAPI: 'steamIndexAPI',
    hrrRagStatus: 'hrrRagStatus',
    windForecast:
        'https://apim-uks-nprd-waf-6001.azure-api.net/rows-mock/api/windCurrent',
    airTempForecast:
        'https://apim-uks-nprd-waf-6001.azure-api.net/rows-mock/api/temperatureNow',
    humidityForecast:
        'https://apim-uks-nprd-waf-6001.azure-api.net/rows-mock/api/humidityNow',
    precipitationForecast:
        'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/precipitationNow',
    hrrAirRagStatus: 'hrrAirRagStatus',
}
