export const environment = {
    production: false,
    baseURL: 'http://localhost:8000',

    apiConfig: {
        scopes: ['user.read'],
        uri: 'https://graph.microsoft.com/v1.0/me',
    },
    redirectUri: '/',
    postLogoutRedirectUri: '/',
}

export const API_END_POINTS = {
    organizationalBoundry:
        'http://localhost:8000/api/organizationalBoundryAssoc',
    hotRunningRail:
        'http://localhost:8000/api/hotRunningRail',
    fireRisk:
        'http://localhost:8000/api/fireRiskIndex',
    steamRisk:
        'http://localhost:8000/api/steamRiskIndex',
    getHazardForeCast:
        'http://localhost:8000/api/weeklyHazardWeather/',
    getForecast24:
        'http://localhost:8000/api/weatherHourly/',
    getUserDetails:
        'http://localhost:8000/api/profile/',
    setUserDetails:
        'http://localhost:8000/api/profile',
    getAlertSummaryCount:
        'http://localhost:8000/api/alertSummaryCount/',
    osBaseMapLight_27700:
        'https://api.os.uk/maps/raster/v1/zxy/Light_27700/{z}/{x}/{y}.png?key=',
    geoServer:
        'http://localhost:8000',
    gisMicroservices:
        'http://localhost:8000',
    gisMicroservices1: 'http://localhost:8000',
    zoomToFeatures: 'zoomToFeatures',
    regionRagStatus: 'regionRagStatus',
    routeRagStatus: 'routeRagStatus',
    mduRagStatus: 'mduRagStatus',
    getWeatherImagePNG: 'getWeatherImagePNG',
    layerMetadata: 'layerMetadata',
    getDataPoints: 'getDataPoints',
    getDataPointsDataBricks: 'getDataPointsDataBricks',
    steamIndexAPI: 'steamIndexAPI',
    hrrRagStatus: 'hrrRagStatus',
    windForecast:
        'http://localhost:8000/api/windCurrent',
    airTempForecast:
        'http://localhost:8000/api/temperatureNow',
    humidityForecast:
        'http://localhost:8000/api/humidityNow',
    precipitationForecast:
        'http://localhost:8000/api/precipitationNow',
    hrrAirRagStatus: 'hrrAirRagStatus',
}
