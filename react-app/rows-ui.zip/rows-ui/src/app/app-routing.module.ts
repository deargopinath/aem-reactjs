import { NgModule } from '@angular/core'
import { Routes, RouterModule } from '@angular/router'
import { UserProfileComponent } from './components/user-profile/user-profile.component'

const routes: Routes = [
    {
        path: '',
        loadChildren: () =>
            import('./modules/dashboard/dashboard.module').then(
                (m) => m.DashboardModule,
            ),
        canActivate: [],
    },
    {
        path: 'dashboard',
        loadChildren: () =>
            import('./modules/dashboard/dashboard.module').then(
                (m) => m.DashboardModule,
            ),
    },
    {
        path: 'feature',
        loadChildren: () =>
            import('./modules/features/feature.module').then(
                (m) => m.FeatureModule,
            ),
    },

    {
        path: 'myProfile',
        component: UserProfileComponent,
        canActivate: [],
    },
]

@NgModule({
    imports: [
        RouterModule.forRoot(routes, {
            initialNavigation: 'enabledNonBlocking',
            useHash: true,
        }),
    ],
    exports: [RouterModule],
})
export class AppRoutingModule {}
