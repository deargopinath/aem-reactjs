import { ViewContainerRef } from '@angular/core'
import { AdDirective } from './ad.directive'

describe('AdDirective', () => {
    it('should create an instance', () => {
        let viewContainerRef!: ViewContainerRef
        const directive = new AdDirective(viewContainerRef)
        expect(directive).toBeTruthy()
    })
})
