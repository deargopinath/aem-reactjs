import {
    Component,
    ElementRef,
    EventEmitter,
    Inject,
    Input,
    Output,
    QueryList,
    ViewChildren,
} from '@angular/core'
import { IDropdownSelectedList } from '../../interfaces/interface'
import { DOCUMENT } from '@angular/common'

@Component({
    selector: 'app-drop-down',
    templateUrl: './drop-down.component.html',
    styleUrls: ['./drop-down.component.scss'],
})
export class DropDownComponent {
    @Input() name = ''
    @Input() multiple = true
    @Input() tableFilter = false
    @Input() filterList: Array<string> = []
    @Input() singleSelectType = false
    @Input() selectedItems: Array<string> = []
    @Input() isError = false
    @Input() appendBody = false
    @Output() shareCheckedList = new EventEmitter<IDropdownSelectedList>()
    @ViewChildren('buttonOption') buttonOption!: QueryList<ElementRef>

    showDropDown = false
    showList = false
    single_select = ''
    openTop = false
    isKeyPress = false
    copyElement: any
    constructor(@Inject(DOCUMENT) private document: Document) {}
    /** updating the dropdown based on user selection */
    selectItem(filterName: string) {
        const index = this.selectedItems.findIndex(
            (name) => filterName === name,
        )
        if (index >= 0) {
            this.selectedItems.splice(index, 1)
        } else {
            this.selectedItems.push(filterName)
        }
        this.emitSelectedList(this.selectedItems)
    }

    /** updating the drop down if user select all */
    selectAll() {
        if (this.selectedItems.length !== this.filterList.length) {
            this.selectedItems = [...this.filterList]
        } else {
            this.selectedItems = []
        }
        this.emitSelectedList(this.selectedItems)
    }

    /** emmiting the selected values */
    emitSelectedList(selectedListItems: string[]) {
        const selectedList: IDropdownSelectedList = {
            name: this.name,
            selectedItems: selectedListItems.sort(),
        }
        this.shareCheckedList.emit(selectedList)
    }

    /** opening the drop down based on the remaining space on the screen */
    toggleDropdown(event: MouseEvent) {
        this.showDropDown = !this.showDropDown
        if (this.showDropDown) {
            if (this.appendBody) this.appendToBody(event)
            this.calculateHeight(event)
        } else {
            this.closeDropDown()
        }
    }

    calculateHeight(event: MouseEvent | KeyboardEvent) {
        this.openTop =
            window.innerHeight -
                (event.target as HTMLElement).getBoundingClientRect().bottom <
            (event.target as HTMLElement).getBoundingClientRect().top
    }

    /** access dropdown using keyboard keys */
    toggleByKeyBoard(event: KeyboardEvent) {
        this.isKeyPress = true
        console.log(this.buttonOption)
        const buttongrp = this.buttonOption.toArray()
        if (['ArrowDown', 'ArrowUp'].includes(event.key)) {
            event.preventDefault()
        }
        const activeButtonIndex = buttongrp.findIndex((activeButton) => {
            return activeButton.nativeElement === this.document.activeElement
        })
        if (event.key === 'ArrowDown') {
            if (
                activeButtonIndex < 0 ||
                activeButtonIndex + 1 >= buttongrp.length
            )
                buttongrp[0].nativeElement.focus()
            if (activeButtonIndex + 1 < buttongrp.length)
                buttongrp[activeButtonIndex + 1].nativeElement.focus()
        }
        if (event.key === 'ArrowUp') {
            if (activeButtonIndex <= 0)
                buttongrp[buttongrp.length - 1].nativeElement.focus()
            if (
                activeButtonIndex - 1 < buttongrp.length &&
                activeButtonIndex - 1 >= 0
            )
                buttongrp[activeButtonIndex - 1].nativeElement.focus()
        }
        if (event.key === 'Escape') this.closeDropDown()
    }

    /** function will be use and update in fututre developement for single select dropdown */
    selectSingleItem(selectedOption: string) {
        this.closeDropDown()
        this.selectedItems = [selectedOption]
        console.log(this.selectedItems)
        this.shareCheckedList.emit({
            name: this.name,
            selectedItems: [selectedOption],
        })
    }

    /** append dropdown container in body */
    appendToBody(event: MouseEvent) {
        if (!this.copyElement)
            this.copyElement = this.document.getElementById(
                'dropdown-'.concat('' + this.name),
            )!
        const dropdown = this.copyElement
        if (!this.isKeyPress) this.document.body.appendChild(dropdown)
        else this.document.getElementById('dropdown')?.appendChild(dropdown)
        dropdown.style.position = 'absolute'
        dropdown.style.top = '' + event.y + 'px'
        dropdown.style.left = '' + (event.x - 10) + 'px'
        dropdown.style.width = 'max-content'
    }

    /** remove dropdown container from body */
    removeFromBody(document: Document) {
        const dropdown = document.getElementById(
            'dropdown-'.concat('' + this.name),
        )
        dropdown!.remove()
    }

    /** close dropdown */
    closeDropDown() {
        if (this.appendBody && this.showDropDown) {
            this.removeFromBody(this.document)
        }
        this.showDropDown = false
        this.isKeyPress = false
    }
}
