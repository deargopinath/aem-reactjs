import { ComponentFixture, TestBed } from '@angular/core/testing'
import { DropDownComponent } from './drop-down.component'

describe('DropDownComponent', () => {
    let component: DropDownComponent
    let document: Document
    beforeEach(() => {
        component = new DropDownComponent(document)
    })

    it('should create the component', () => {
        expect(component).toBeTruthy()
    })

    it('should have the correct name', () => {
        expect(component.name).toEqual('')
    })

    it('should have the correct list', () => {
        expect(component.filterList).toEqual([])
    })

    it('should have the correct singleSelectType', () => {
        expect(component.singleSelectType).toEqual(false)
    })

    it('should have the correct multiple', () => {
        expect(component.multiple).toEqual(true)
    })

    it('should have the correct selectedItems', () => {
        expect(component.selectedItems).toEqual([])
    })

    it('should emit the shareCheckedList event', () => {
        const spy = spyOn(component, 'shareCheckedList').and.callThrough()
        component.selectSingleItem('item')
        expect(spy).toHaveBeenCalledWith()
    })

    it('should select the All option when the user clicks on it', () => {
        component.selectedItems = []
        component.selectItem('Option 1')
        expect(component.selectedItems).toEqual([...component.filterList])
    })

    it('should deselect the All option when the user clicks on another option', () => {
        component.selectedItems = [...component.filterList]
        component.selectItem('All')
        expect(component.selectedItems).toEqual([])
    })

    it('should add an option to the selected items when the user clicks on it', () => {
        component.selectedItems = []
        component.selectItem('Option 1')
        expect(component.selectedItems).toEqual(['Option 1'])
    })

    it('should remove an option from the selected items when the user clicks on it', () => {
        component.selectedItems = ['Option 1']
        component.selectItem('Option 1')
        expect(component.selectedItems).toEqual([])
    })

    it('should select all items when "All" option is chosen and none selected', () => {
        // Arrange
        const event = 'Option 1'
        component.selectedItems = []

        // Act
        component.selectItem(event)

        // Assert
        expect(component.selectedItems).toEqual(component.filterList)
    })

    // Add more test cases to cover different scenarios...

    it('should emit updated selected items list', () => {
        // Arrange
        const event = 'Option 1'
        component.selectedItems = ['Item B']

        // Spy on the emit method of the output event
        spyOn(component.shareCheckedList, 'emit')

        // Act
        component.selectItem(event)
        const filter = { name: 'region', selectedItems: ['Option 1'] }
        // Assert
        expect(component.shareCheckedList.emit).toHaveBeenCalledWith(filter)
    })

    it('should select all filter', () => {
        component.selectedItems = ['region1']
        component.filterList = ['region1', 'reegion2']
        component.selectAll()
        expect(component.selectedItems).toEqual(component.filterList)
    })
    it('should remove all filter', () => {
        component.selectedItems = ['region1']
        component.filterList = ['region1']
        component.selectAll()
        expect(component.selectedItems).toEqual([])
    })
    it('should toggle dropdown', () => {
        let event!: MouseEvent
        component.showDropDown = false
        component.toggleDropdown(event)
        expect(component.openTop).toBeTrue()
    })

    it('should call append to body', () => {
        let event!: MouseEvent
        component.showDropDown = true
        component.appendBody = true
        component.toggleDropdown(event)
        expect(component.appendToBody).toHaveBeenCalledWith(event)
    })

    it('should close dropdown', () => {
        component.showDropDown = true
        component.appendBody = true
        component.closeDropDown()
        expect(component.removeFromBody).toHaveBeenCalledWith(new Document())
    })
    it('should  remove dropdown', () => {
        const document: any = {
            getElementById(str: any) {
                return { remove() {}, str: str }
            },
        }

        expect(component.removeFromBody(document)).toBeUndefined()
    })

    it('should append to body', () => {
        const event: any = {}
        expect(component.appendToBody(event)).toBeUndefined()
    })

    it('should append to body - keypress-false', () => {
        const event: any = {}
        component.isKeyPress = false
        component.copyElement = {}
        expect(component.appendToBody(event)).toBeUndefined()
    })

    it('should append to body - keypress-true', () => {
        const event: any = {}
        component.isKeyPress = true
        component.copyElement = {
            style: { position: '', top: '', left: '', width: '' },
        }

        expect(component.appendToBody(event)).toBeUndefined()
    })

    it('should append to body - keypress-true', () => {
        const event: any = {}
        component.isKeyPress = false
        component.copyElement = {
            style: { position: '', top: '', left: '', width: '' },
        }

        expect(component.appendToBody(event)).toBeUndefined()
    })

    it('should toggle by keyboard', () => {
        const queryButton: any = {
            toArray() {
                return []
            },
        }
        component.buttonOption = queryButton
        const event: any = { key: 'ArrowDown', preventDefault() {} }
        component.isKeyPress = false
        component.copyElement = {
            style: { position: '', top: '', left: '', width: '' },
        }
        expect(component.toggleByKeyBoard(event)).toBeUndefined()
    })
})
