import { ComponentFixture, TestBed } from '@angular/core/testing'

import { TimeSliderComponent } from './time-slider.component'
import { SubjectService } from 'src/app/services/subject.service'

describe('TimeSliderComponent', () => {
    let component: TimeSliderComponent
    // let fixture: ComponentFixture<TimeSliderComponent>
    let subjectServiceSpy: jasmine.SpyObj<SubjectService>

    beforeEach(() => {
        const subjectServiceSpyObj = jasmine.createSpyObj('SubjectService', [
            'isReset',
        ])

        TestBed.configureTestingModule({
            providers: [
                TimeSliderComponent,
                { provide: SubjectService, useValue: subjectServiceSpyObj },
            ],
        })

        component = TestBed.inject(TimeSliderComponent)
        subjectServiceSpy = TestBed.inject(
            SubjectService,
        ) as jasmine.SpyObj<SubjectService>
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })

    describe('ngOnInit', () => {
        it('should call forecastMinMax', () => {
            expect(component.ngAfterViewInit()).toHaveBeenCalled()
        })
    })

    describe('playTimeSeries', () => {
        beforeEach(() => {
            jasmine.clock().install()
        })

        it('should call callback', () => {
            const callback = jasmine.createSpy('callback')
            const interval = 1000
            component.timeSliderValue = 20
            component.hours = 20
            expect(component.playTimeSeries()).toHaveBeenCalled()
        })

        it('should call callback', () => {
            const callback = jasmine.createSpy('callback')
            const interval = 1000
            component.timeSliderValue = 0
            component.hours = 20
            expect(component.playTimeSeries()).toHaveBeenCalled()
            jasmine.clock().tick(interval * 3)
            expect(callback.calls.count()).toBe(3)
        })

        afterEach(() => {
            jasmine.clock().uninstall()
        })
    })

    describe('onDateRangeSelection', () => {
        it('should call onDateRangeSelection', () => {
            const range = {
                from: new Date('11/09/2023'),
                to: new Date('20/09/2023'),
            }
            expect(component.onDateRangeSelection(range)).toHaveBeenCalled()
        })

        it('should type = observation', () => {
            component.sliderRange!.style.background = '#96BAC5'
            const range = {
                from: new Date(
                    'Fri Sep 22 2023 06:00:46 GMT+0530 (India Standard Time)',
                ),
                to: new Date(
                    'Thu Sep 28 2023 06:00:46 GMT+0530 (India Standard Time)',
                ),
            }
            component.type = 'isobservation'
            expect(component.onDateRangeSelection(range)).toHaveBeenCalled()
        })
    })

    describe('resetDateRange', () => {
        it('should call resetDateRange', () => {
            expect(component.resetDateRange()).toHaveBeenCalled()
        })
    })

    describe('resetDateTime', () => {
        it('should call resetDateTime', () => {
            expect(component.resetDateTime()).toHaveBeenCalled()
            expect(component.setDateTime(new Date())).toHaveBeenCalled()
        })
    })

    describe('getDates', () => {
        it('should call getDates', () => {
            const startDate = new Date(
                'Fri Sep 22 2023 06:00:46 GMT+0530 (India Standard Time)',
            )
            const endDate = new Date(
                'Thu Sep 28 2023 06:00:46 GMT+0530 (India Standard Time)',
            )
            expect(component.getDates(startDate, endDate)).toHaveBeenCalled()
        })
    })

    describe('simpleFormat', () => {
        it('should call simpleFormat', () => {
            const arr: any = [
                'Fri Sep 22 2023 06:00:46 GMT+0530 (India Standard Time)',
                'Sat Sep 23 2023 06:00:46 GMT+0530 (India Standard Time)',
            ]
            expect(component.simpleFormat(arr)).toHaveBeenCalled()
        })
    })

    describe('playTimeSeries', () => {
        it('should call playTimeSeries', () => {
            expect(component.playTimeSeries()).toHaveBeenCalled()
        })

        it('should check timeslidervalue greater than hours value', () => {
            component.timeSliderValue = 20
            component.hours = 20
            expect(component.playTimeSeries()).toHaveBeenCalled()
        })

        it('should check timeslidervalue less than hours value', () => {
            component.timeSliderValue = 0
            component.hours = 48
            expect(component.playTimeSeries()).toHaveBeenCalled()
        })
    })

    describe('pauseTimeSeries', () => {
        it('should call pauseTimeSeries', () => {
            expect(component.pauseTimeSeries()).toHaveBeenCalled()
        })

        it('should check when timeslidervalue is less than hours value', () => {
            component.timeSliderValue = 6
            component.hours = 20
            expect(component.pauseTimeSeries()).toHaveBeenCalled()
        })
    })

    describe('previousTimeSeries', () => {
        it('should call previousTimeSeries', () => {
            expect(component.previousTimeSeries()).toHaveBeenCalled()
        })

        it('should check when timeslidervalue is greaterthan 0', () => {
            component.timeSliderValue = 8
            expect(component.previousTimeSeries()).toHaveBeenCalled()
        })
    })

    describe('nextTimeSeries', () => {
        it('should call nextTimeSeries', () => {
            expect(component.nextTimeSeries()).toHaveBeenCalled()
        })

        it('should check when timeslidervalue is less than hours value', () => {
            component.timeSliderValue = 0
            component.hours = 20
            expect(component.nextTimeSeries()).toHaveBeenCalled()
        })

        it('should check when timeslidervalue is greater than hours value', () => {
            component.timeSliderValue = 20
            component.hours = 20
            expect(component.nextTimeSeries()).toHaveBeenCalled()
            expect(component.timeSliderValue).toBe(0)
            expect(component.setDateTime(component.from)).toHaveBeenCalled()
        })
    })

    describe('changed', () => {
        it('should call changed', () => {
            const event = {
                target: {
                    value: 2,
                },
            }
            expect(component.changed(event)).toHaveBeenCalled()
            expect(component.timeSliderValue).toEqual(event.target.value)
        })

        it('should check when timeslider is equal to hours value', () => {
            const event = {
                target: {
                    value: 20,
                },
            }
            component.timeSliderValue = 20
            component.hours = 20
            expect(component.changed(event)).toHaveBeenCalled()
        })
    })

    describe('generateDateTime', () => {
        it('should call generateDateTime', () => {
            const hour = 1
            const startDate =
                'Fri Sep 22 2023 06:00:46 GMT+0530 (India Standard Time)'
            expect(
                component.generateDateTime(hour, startDate),
            ).toHaveBeenCalled()
        })

        it('should check when timeslidervalue is less than hours value', () => {
            const hour = 1
            const startDate =
                'Fri Sep 22 2023 06:00:46 GMT+0530 (India Standard Time)'
            component.timeSliderValue = 2
            component.hours = 48
            expect(
                component.generateDateTime(hour, startDate),
            ).toHaveBeenCalled()
        })
    })

    describe('ngOnDestroy', () => {
        it('should call ngOnDestroy', () => {
            expect(component.ngOnDestroy()).toHaveBeenCalled()
        })

        it('should check for id', () => {
            component.id = 1
            expect(component.ngOnDestroy()).toHaveBeenCalled()
        })
    })
})
