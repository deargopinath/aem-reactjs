import {
    Component,
    EventEmitter,
    HostListener,
    Input,
    OnInit,
    Output,
    ViewChild,
} from '@angular/core'
import {
    NgbDateStruct,
    NgbInputDatepicker,
} from '@ng-bootstrap/ng-bootstrap'

import moment from 'moment/moment'
import { SubjectService } from 'src/app/services/subject.service'


@Component({
    selector: 'app-range-calender',
    templateUrl: './range-calender.component.html',
    styleUrls: ['./range-calender.component.scss'],
})
export class RangeCalenderComponent implements OnInit {
    @ViewChild('dp') private datePicker!: NgbInputDatepicker
    @Input({ required: true }) component!: string
    @Input() from: Date | null = new Date()
    @Input() to: Date | null = new Date()
    @Input() placeholder = moment(new Date()).format('DD/MM/yyyy HH00')
    @Input() type = 'forecast'
    @Output() dateRangeSelection = new EventEmitter<{ from: Date; to: Date }>()
    hoveredDate: Date | null = new Date()
    isOpen = false
    exceeded = false
    formatttedDate = moment(new Date()).format('DD/MM/yyyy HH00')
    startWeekDay = 7
    minDate!: NgbDateStruct
    maxDate!: NgbDateStruct
    //type = 'isforcast'
    timeFormat = new Date()
    start_time = moment(this.timeFormat).format('HH00')
    end_time = '0600'

    calenderDateRange: any = {
        forecast: {
            mindate: {
                day: 0,
                month: 0,
                year: 0,
            },
            maxdate: {
                day: 0,
                month: 0,
                year: 0,
            },
        },
        observered: {
            mindate: {
                day: 0,
                month: 0,
                year: 0,
            },
            maxdate: {
                day: 0,
                month: 0,
                year: 0,
            },
        },
    }

    @HostListener('document:click', ['$event.target']) onClick(element: any) {
        const host = document.getElementById('dateRangePicker')
        if (
            this.datePicker &&
            this.isOpen &&
            !this.isDescendant(host, element)
        ) {
            this.emit(true)
        }
    }

    constructor(private subjectService: SubjectService) {}

    ngOnInit() {
        this.forecastMinMax()
        this.observedMinMax()
        this.subjectService.isReset.subscribe((val) => {
            if (val) {
                this.formatttedDate = moment(new Date()).format(
                    'DD/MM/YYYY HH00',
                )
                this.from = null
                this.to = null
                this.datePicker.startDate = {
                    day: this.timeFormat.getDate(),
                    month: this.timeFormat.getMonth() + 1,
                    year: this.timeFormat.getFullYear(),
                }
                this.exceeded = false
            }
        })
    }

    /** set the minDate and maxDate for forecast */
    forecastMinMax() {
        const date = new Date()
        this.calenderDateRange.forecast.mindate = {
            day: date.getDate(),
            month: date.getMonth() + 1,
            year: date.getFullYear(),
        }
        this.calenderDateRange.forecast.maxdate = {
            day: date.getDate() + 20,
            month: date.getMonth() + 1,
            year: date.getFullYear(),
        }
    }

    /** set the minDate and maxDate for observed */
    observedMinMax() {
        const date = new Date()
        this.calenderDateRange.observered.mindate = {
            day: date.getDate(),
            month: date.getMonth(),
            year: date.getFullYear(),
        }
        this.calenderDateRange.observered.maxdate = {
            day: date.getDate(),
            month: date.getMonth() + 1,
            year: date.getFullYear(),
        }
    }

    /** set the custom class for making Sunday date as red color */
    myClass(date: NgbDateStruct) {
        const d = new Date(date.year, date.month - 1, date.day)
        return d.getDay() === 0 ? 'weekend-color' : 'classNormal'
    }

    /** set the calender close or open */
    private emit(close?: boolean) {
        const dateRange: any = {
            from: this.from,
            to: this.to,
        }

        this.dateRangeSelection.emit(dateRange)

        if (close) {
            this.isOpen = false
            this.datePicker.close()
        }
    }

    /**
     * Check whether or not an element is a child of another element
     *
     * @private
     * @param {any} parent
     * @param {any} child
     * @returns if child is a descendant of parent
     * @memberof SelectDateRangeComponent
     */
    private isDescendant(parent: any, child: any) {
        let node = child
        while (node !== null) {
            if (node === parent) {
                return true
            } else {
                node = node.parentNode
            }
        }
        return false
    }

    /** format of dates after selection from calender */
    formattedDateRange() {
        const date = new Date()
        const fromFormatted = moment(this.from).format('DD/MM/YYYY')

        const hours =
            date.getHours() > 12 ? date.getHours() - 12 : date.getHours()
        this.formatttedDate = this.to
            ? `${fromFormatted}` +
              ' ' +
              `${
                  fromFormatted !== moment(date).format('DD/MM/YYYY')
                      ? `0600`
                      : hours + '00'
              }` +
              ` - ` +
              `${moment(this.to).format('DD/MM/YYYY')}` +
              ' ' +
              `0600`
            : `${fromFormatted}` +
              ' ' +
              `${moment(this.from).isValid() ? hours + '00' : ' '}`
    }

    /** triggered when selection of date from the calender */
    onDateSelection(date: NgbDateStruct) {
        this.exceeded = false
        if (!this.from && !this.to) {
            this.from = this.toDate(date)
        } else if (this.from && !this.to) {
            if (this.toDate(date)?.getDate() !== this.from?.getDate()) {
                const endDate = this.setDates(this.toDate(date))
                this.to = endDate.toDate()
            } else {
                this.to = new Date(this.from!)
                this.to.setDate(this.from!.getDate() + 1)
            }
            const startDate = this.from!.getTime() / (1000 * 3600 * 24)
            const lastDate = this.to?.getTime()! / (1000 * 3600 * 24)
            if (this.checkMaxDateRange(lastDate, startDate, this.component)) {
                this.exceeded = true
                this.to = null
                this.from = null
            } else {
                this.exceeded = false
                this.emit(true)
            }
        } else {
            this.to = null
            this.from = this.toDate(date)
        }
        if (this.to && this.to!.getTime() < this.from!.getTime()) {
            const temp = this.from
            this.from = this.to
            this.to = temp
            const startDate = this.from!.getTime() / (1000 * 3600 * 24)
            const lastDate = this.to?.getTime()! / (1000 * 3600 * 24)
            if (this.checkMaxDateRange(lastDate, startDate, this.component)) {
                this.exceeded = true
                this.to = null
                this.from = null
            } else {
                this.exceeded = false
                this.emit(true)
            }
        }
        this.formattedDateRange()
    }

    /** set the date&time */
    setDates(date: any) {
        const endDate = moment(date, undefined, false)
        return endDate.set({ h: 6, m: 0 })
    }

    /** checking the exceeding dates for each feature */
    checkMaxDateRange(lastDate: any, startDate: any, component: any) {
        if (component === 'hotRunningRail') {
            if (lastDate - startDate > 7 && lastDate != null) {
                return true
            }
            return false
        } else if (component === 'fireRisk') {
            if (lastDate - startDate > 10 && lastDate != null) {
                return true
            }
            return false
        } else if (component === 'dashboard') {
            if (lastDate - startDate > 15 && lastDate != null) {
                return true
            }
            return false
        }
        return false
    }

    /** return the moment date for the selected date */
    toDate(dateStruct: NgbDateStruct): Date | null {
        return dateStruct
            ? new Date(dateStruct.year, dateStruct.month - 1, dateStruct.day)
            : null
    }

    toMoment(dateStruct: NgbDateStruct): moment.Moment {
        return moment(this.toDate(dateStruct)!, undefined, false)
    }

    /** select the hovered dates */
    isHovered = (date: NgbDateStruct) =>
        this.from &&
        !this.to &&
        this.hoveredDate &&
        this.toMoment(date).isAfter(this.from) &&
        this.toMoment(date).isBefore(this.hoveredDate)

    isInside = (date: NgbDateStruct) =>
        this.toMoment(date).isAfter(
            moment(this.from!, undefined, false).startOf('day'),
        ) &&
        this.toMoment(date).isBefore(
            moment(this.to!, undefined, false).startOf('day'),
        )
    isFrom = (date: NgbDateStruct) =>
        this.toMoment(date).isSame(this.from!, 'd')
    isTo = (date: NgbDateStruct) => this.toMoment(date).isSame(this.to!, 'd')
}
