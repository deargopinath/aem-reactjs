import { BrowserModule } from '@angular/platform-browser'
import { NoopAnimationsModule } from '@angular/platform-browser/animations'
import { NgModule } from '@angular/core'

import { AppRoutingModule } from './app-routing.module'
import { AppComponent } from './app.component'
import { HeaderComponent } from './components/header/header.component'

import { HttpClientModule } from '@angular/common/http'

import { FeatureModule } from './modules/features/feature.module'
import { MapComponent } from './components/GIS/map/map.component'
import { AppInitializeService } from './services/app-initialize.service'
import { SidenavComponent } from './components/sidenav/sidenav.component'
import { UserProfileComponent } from './components/user-profile/user-profile.component'


@NgModule({
    declarations: [AppComponent],
    imports: [
        BrowserModule,
        NoopAnimationsModule,
        AppRoutingModule,
        HttpClientModule,
        HeaderComponent,
        SidenavComponent,
        FeatureModule,
        MapComponent,
        UserProfileComponent,
    ],
    providers: [
        AppInitializeService,
    ],
    bootstrap: [AppComponent],
})
export class AppModule {}
