import { ComponentFixture, TestBed } from '@angular/core/testing'

import { DetailedHazardComponent } from './detailed-hazard.component'
import { ActivatedRoute } from '@angular/router'

describe('DetailedHazardComponent', () => {
    let component: DetailedHazardComponent
    let activatedRoute: ActivatedRoute

    beforeEach(() => {
        component = new DetailedHazardComponent(activatedRoute)
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })

    it('should call ngOnInit', () => {
        component.ngOnInit()
        expect(component.ngOnInit()).toHaveBeenCalled()
    })

    it('should call getFilteredTable', () => {
        const filterCollection = {
            name: '',
            action: '',
            regions: [],
            routes: [],
            mdus: [],
        }
        expect(component.getFilteredTable(filterCollection)).toHaveBeenCalled()
    })
})
