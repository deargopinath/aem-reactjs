import { Component, OnInit } from '@angular/core'
import { ActivatedRoute } from '@angular/router'
import { IFilters } from '../../../shared/interfaces/interface'

@Component({
    selector: 'app-detailed-hazard',
    templateUrl: './detailed-hazard.component.html',
    styleUrls: ['./detailed-hazard.component.scss'],
})
export class DetailedHazardComponent implements OnInit {
    weatherParameterNeeded = true
    constructor(private activatedRoute: ActivatedRoute) {}
    ngOnInit(): void {
        this.activatedRoute.data.subscribe((d) => {
            console.log(d['breadcrumbs'])
        })
    }

    /** collecting the selected filter valuse from the filter panel and providinig it to api call */
    getFilteredTable(filterCollection: IFilters) {
        console.log('table-filter')
    }
}
