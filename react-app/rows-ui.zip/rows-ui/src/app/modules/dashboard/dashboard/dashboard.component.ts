import {
    Component,
    QueryList,
    ViewChildren,
    AfterViewInit,
} from '@angular/core'
import { ActivatedRoute } from '@angular/router'
import { DASHBOARD_WEATHER_PARAMETERS } from 'src/app/core/constants/app.constants'
import { SubjectService } from '../../../services/subject.service'
import { UserAuthService } from '../../../services/user-auth.service'
import { ApiCallService } from '../../../services/web-serivces/api-call.service'
import { AdDirective } from '../../../shared/directives/ad.directive'
import { MapService } from '../../../services/gis/map.service'
import { IUser } from '../../../shared/interfaces/interface'
import { API_END_POINTS } from '../../../../environments/environment'
import moment from 'moment'
import { combineLatest } from 'rxjs'
import { FilterService } from '../../../services/filter.service'

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent implements AfterViewInit {
    @ViewChildren(AdDirective) leftContainer!: QueryList<AdDirective>
    components: Array<any> = [[], []]
    feature: any = DASHBOARD_WEATHER_PARAMETERS
    selectedType = 'forecast'
    parameterName = ''
    subParameterName = ''
    isCapsuleSelect = false
    tableVisible = false
    tableData: any
    user!: IUser
    showtableBtn = false
    tableHeaders: string[] = []
    tableTitle = ''
    details = ''
    cachefilter: any
    istablefetched = false
    userRegion = ''
    userRoute = ''
    showTempTable = false;
    dailyTemp = false
    transformedData: any = []
    transformedTableHeaders: string[] = []
    transformedTableTitle = ''

    constructor(
        private apiCall: ApiCallService,
        private userSvc: UserAuthService,
        private subjectSvc: SubjectService,
        private activatedRoute: ActivatedRoute,
        private mapService: MapService,
        private filterService: FilterService,
    ) {}

    ngOnInit(): void {
        this.activatedRoute.data.subscribe((d) => {
            console.log(d['breadcrumbs'])
        })

        this.subjectSvc.adComponents.subscribe(
            ({ component, section }: any) => {
                this.checkComponentVisiblity(component, section)
            },
        )
        this.subjectSvc.updateWidget.next([false])

        this.userSvc.getUser().subscribe((user) => {
            this.user = user
            this.userRegion = user.region
            this.userRoute = user.route
        })

        this.displayCurrentTable()
    }

    displayCurrentTable(): void {
        combineLatest([
            this.subjectSvc.parameterName,
            this.subjectSvc.subParameterName,
            this.subjectSvc.isCapsuleSelected,
        ]).subscribe(([parameterName, subParameterName, isCapsuleSelect]) => {
            if (
                parameterName == 'Wind (mph)' &&
                (subParameterName == 'Wind speed' ||
                    subParameterName == 'Wind direction' ||
                    subParameterName == 'Wind gusts') &&
                isCapsuleSelect
            ) {
                this.subParameterName = subParameterName
                this.showtableBtn = true
                this.showTempTable = false
                this.fetchCurrentWindData()
            } else if (
                parameterName == 'Air Temperature (\u00B0C)' &&
                (subParameterName == 'Maximum Temperature' ||
                    subParameterName == 'Minimum Temperature') &&
                isCapsuleSelect
            ) {
                this.subParameterName = subParameterName
                this.showtableBtn = true
                this.showTempTable = true
                this.fetchCurrentAirTempData()
            } else if (
                parameterName == 'Humidity (%)' &&
                subParameterName == 'Humidity (%)' &&
                isCapsuleSelect
            ) {
                this.subParameterName = subParameterName
                this.showtableBtn = true
                this.showTempTable = false
                this.fetchCurrentHumidityData()
            }  else if (
                parameterName == 'Precipitation (mm)' &&
                (subParameterName == 'Precipitation' ||
                    subParameterName == 'Soil Moisture') &&
                isCapsuleSelect
            ) {
                this.subParameterName = subParameterName
                this.showtableBtn = true
                this.showTempTable = false
                this.fetchCurrentPrecipitationData()
            } else {
                this.showtableBtn = false
                this.tableVisible = false
                this.showTempTable = false
            }
        })
    }

    ngAfterViewInit(): void {
        //Initialize map here
        const post_options = {
            wpi: [1,2],
            module: 2,
        }
        this.mapService.getLayerMetadata(post_options)
    }

    /** checking if widget is on the dashboard or not */
    checkComponentVisiblity(newComponent: any, section: number) {
        const componentFoundIndex = this.components[section].findIndex(
            (component: any) => {
                return component.instance instanceof newComponent
            },
        )
        const viewContainerRef =
            this.leftContainer.toArray()[section].viewContainerRef
        if (componentFoundIndex >= 0)
            this.removeComponent(componentFoundIndex, viewContainerRef, section)
        else this.addComponent(newComponent, viewContainerRef, section)
    }

    /** adding widget on the dashboard */
    addComponent(componentName: any, viewContainerRef: any, section: number) {
        const componentRef = viewContainerRef.createComponent(componentName)
        this.components[section].push(componentRef)
        this.updateWidgetsHeight(section, 'add')
    }

    /** removing widget from the dashboard */
    removeComponent(
        componentIndex: number,
        viewContainerRef: any,
        section: number,
    ) {
        viewContainerRef.remove(componentIndex)
        this.components[section].splice(componentIndex, 1)
        this.updateWidgetsHeight(section, 'remove')
    }

    /** updating the widget size if there is another widget is getting open below the widget */
    updateWidgetsHeight(section: number, status: string) {
        const lastVal = this.subjectSvc.adjustWidgetsPosition.getValue()
        if (this.components[section].length > 1) {
            if (section === 0)
                this.subjectSvc.adjustWidgetsPosition.next({
                    left: true,
                    right: lastVal.right,
                })
            else
                this.subjectSvc.adjustWidgetsPosition.next({
                    left: lastVal.left,
                    right: true,
                })
        } else {
            if (section === 0)
                this.subjectSvc.adjustWidgetsPosition.next({
                    left: false,
                    right: lastVal.right,
                })
            else
                this.subjectSvc.adjustWidgetsPosition.next({
                    left: lastVal.left,
                    right: false,
                })
        }
    }

    fetchCurrentWindData(): void {
        if (!this.istablefetched) {
            this.istablefetched = true
            this.apiCall
                .singleApiCall(`${API_END_POINTS.windForecast}`, 'GET')
                .subscribe((response) => {
                    this.tableHeaders = [
                        'Wind Gust (mph)',
                        'Wind Speed (mph)',
                        'Wind Direction',
                    ]
                    this.tableTitle = 'Wind Forecast (Current)'
                    this.cachefilter = response
                    this.tableData = this.filterService.filterTable(
                        this.cachefilter,
                        [this.userRoute],
                        'RouteName',
                    )
                    const dateTime = response[0].Value
                    let dateTimeValues = dateTime.map(
                        (item: any) => item.DateTime,
                    )
                    this.getTableDetails(dateTimeValues[0])
                    this.istablefetched = false
                })
        }
    }

    fetchCurrentAirTempData(): void {
        if (!this.istablefetched) {
            this.istablefetched = true
            this.apiCall
                .singleApiCall(`${API_END_POINTS.airTempForecast}`, 'GET')
                .subscribe((response) => {
                    this.tableHeaders = [
                        'Air Temperature (\u00B0C)',
                        'Dew Point (\u00B0C)',
                    ]
                    this.tableTitle = 'Air Temperature Forecast (Current)'
                    this.cachefilter = response
                    this.tableData = this.filterService.filterTable(
                        this.cachefilter,
                        [this.userRoute],
                        'RouteName',
                    )
                    const values = response[0].Value
                    let dateTimeValues = values.map(
                        (item: any) => item.DateTime,
                    )
                    this.getTableDetails(dateTimeValues[0])
                    this.istablefetched = false
                })
        }
    }

    fetchCurrentHumidityData(): void {
        if (!this.istablefetched) {
            this.istablefetched = true
            this.apiCall
                .singleApiCall(`${API_END_POINTS.humidityForecast}`, 'GET')
                .subscribe((response) => {
                    this.tableHeaders = ['Humidity (%)']
                    this.tableTitle = 'Humidity Forecast (Current)'
                    this.cachefilter = response
                    this.tableData = this.filterService.filterTable(
                        this.cachefilter,
                        [this.userRoute],
                        'RouteName',
                    )
                    const values = response[0].Value
                    let dateTimeValues = values.map(
                        (item: any) => item.DateTime,
                    )
                    this.getTableDetails(dateTimeValues[0])
                    this.istablefetched = false
                })
        }
    }

    fetchCurrentPrecipitationData(): void {
        if (!this.istablefetched) {
            this.istablefetched = true
            this.apiCall
                .singleApiCall(`${API_END_POINTS.precipitationForecast}`, 'GET')
                .subscribe((response) => {
                    this.tableHeaders = ['Precipitation (mm)']
                    this.tableTitle = 'Precipitation Forecast (Current hour)'
                    this.cachefilter = response
                    this.tableData = this.filterService.filterTable(
                        this.cachefilter,
                        [this.userRoute],
                        'RouteName',
                    )
                    const values = response[0].Value
                    let dateTimeValues = values.map(
                        (item: any) => item.DateTime,
                    )
                    this.getTableDetails(dateTimeValues[0])
                    this.istablefetched = false
                })
        }
    }

    getTableDetails(dateTime: string): void {
        let initialDate = dateTime.split(' ')
        let tableDate = initialDate[0]
        let tableTime = initialDate[1]
        // let formattedDate = this.datePipe.transform(tableDate, 'dd/MM/yyyy')
        let formattedDate = moment(tableDate).format('DD/MM/YYYY')
        let formattedTime = this.convertTime(tableTime)
        let timeRange = this.getRange(tableTime)
        let tableDay = this.getDay(tableDate)
        this.details = `(Issued on ${tableDay}, ${formattedDate} at ${formattedTime}, Valid for ${timeRange})`
    }

    private convertTime(time: string): string {
        const part = time.split(':')
        let hours = part[0] + part[1]
        hours = hours.padStart(4, '0')
        return hours
    }

    private getRange(range: string): string {
        const part = range.split(':')
        let startRange = `${part[0]}`
        let mid = +part[0] + 1
        let endRange = mid.toString().padStart(2, '0')
        let totalRange = `${startRange}00-${endRange}00`
        return totalRange
    }

    private getDay(date: string): string {
        const apiDate = new Date(date)
        const daysOfWeek = [
            'Sunday',
            'Monday',
            'Tuesday',
            'Wednesday',
            'Thursday',
            'Friday',
            'Saturday',
        ]
        const daysIndex = apiDate.getDay()
        return daysOfWeek[daysIndex]
    }

    showTable(): void {
        this.tableVisible = true
        setTimeout(() => {
            window.scrollTo({ top: 700, left: 0, behavior: 'smooth' })
        }, 0)
    }

    onHideTable(value: boolean): void {
        this.tableVisible = value
    }
}
