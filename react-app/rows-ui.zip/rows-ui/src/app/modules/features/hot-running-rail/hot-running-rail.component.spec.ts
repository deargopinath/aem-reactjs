import { TestBed } from '@angular/core/testing'
import { of } from 'rxjs'

import { HotRunningRailComponent } from './hot-running-rail.component'
import { SubjectService } from 'src/app/services/subject.service'
import { ApiCallService } from 'src/app/services/web-serivces/api-call.service'
import { API_END_POINTS } from '../../../core/configuration/api-endpoints'

describe('HotRunningRailComponent', () => {
    let component: HotRunningRailComponent
    let subjectServiceSpy: jasmine.SpyObj<SubjectService>
    let apiCallServiceSpy: jasmine.SpyObj<ApiCallService>

    beforeEach(() => {
        const subjectServiceSpyObj = jasmine.createSpyObj('SubjectService', [
            'date',
            'organizationalBoundaries',
        ])
        const apiCallServiceSpyObj = jasmine.createSpyObj('ApiCallService', [
            'singleApiCall',
        ])

        TestBed.configureTestingModule({
            providers: [
                HotRunningRailComponent,
                { provide: SubjectService, useValue: subjectServiceSpyObj },
                { provide: ApiCallService, useValue: apiCallServiceSpyObj },
            ],
        })

        component = TestBed.inject(HotRunningRailComponent)
        subjectServiceSpy = TestBed.inject(
            SubjectService,
        ) as jasmine.SpyObj<SubjectService>
        apiCallServiceSpy = TestBed.inject(
            ApiCallService,
        ) as jasmine.SpyObj<ApiCallService>
    })

    describe('hrrTable', () => {
        it('should call API and populate tableData when hrrTable is called', () => {
            const mockedData = [
                {
                    /* mocked data object */
                },
            ]

            apiCallServiceSpy.singleApiCall.and.returnValue(of(mockedData))

            component.hrrTable(['Anglia'])

            expect(apiCallServiceSpy.singleApiCall).toHaveBeenCalledWith(
                'baseURL' + API_END_POINTS.hotRunningRail,
                'GET',
            )
            expect(component.hrr_tableData).toEqual(mockedData)
            expect(component.tableData).toEqual(mockedData)
        })
    })
    describe('tabularContent', () => {
        it('should populate tableData correctly when tabularContent is called', () => {
            const tableData = [
                {
                    MaxAirTemp: '3.36',
                    MaxRailTemp: '42',
                    PeriodAbove46C: 0,
                    RegionName: 'Eastern',
                    RouteName: 'East Coast',
                    MDUName: 'Newcastle MDU - HE8',
                    DateTime: '2023-05-01T11:00:00Z',
                    TimeofMaxRailTemp: '11:00',
                    Date: '2023-05-01',
                    DayOfWeek: 'Monday',
                },
                {
                    MaxAirTemp: '3.36',
                    MaxRailTemp: '42',
                    PeriodAbove46C: 0,
                    RegionName: 'Eastern',
                    RouteName: 'East Coast',
                    MDUName: 'Newcastle MDU - HE8',
                    DateTime: '2023-05-01T11:00:00Z',
                    TimeofMaxRailTemp: '11:00',
                    Date: '2023-05-01',
                    DayOfWeek: 'Monday',
                },
            ]

            component.tabularContent(
                ['Newcastle MDU - HE8', 'Middlesbrough MDU - HF1'],
                tableData,
            )
            expect(component.tableData.length).toBeGreaterThan(0)
        })
    })

    describe('ngOnInit', () => {
        it('should update date', () => {
            component.ngOnInit()
            expect(component.date$).toBeTrue()
        })
    })
    describe('getFilteredTable', () => {
        it('should call  hrrTable', () => {
            const mockFilterDate = {
                name: 'hrr',
                regions: ['region1'],
                routes: ['route1'],
                mdus: ['mdu1'],
                action: 'submit',
            }
            component.getFilteredTable(mockFilterDate)
            expect(component.hrrTable).toHaveBeenCalledWith(['mdu1'])
        })
    })
})
