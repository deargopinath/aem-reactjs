import { Component, OnInit, OnDestroy, AfterViewInit } from '@angular/core'

import { Observable } from 'rxjs'

import { SubjectService } from '../../../services/subject.service'
import { ApiCallService } from '../../../services/web-serivces/api-call.service'
import { IFilters } from '../../../shared/interfaces/interface'
import { API_END_POINTS } from '../../../../environments/environment'

import {
    HOTRUNNINGRAIL_WEATHER_PARAMETERS,
    HRR_TABLE_LEGENDS,
} from '../../../core/constants/app.constants'
import { MapService } from '../../../services/gis/map.service'
import { weatherParameter } from '../../../core/properties/app.properties'

@Component({
    selector: 'app-hot-running-rail',
    templateUrl: './hot-running-rail.component.html',
    styleUrls: ['./hot-running-rail.component.scss'],
})
export class HotRunningRailComponent
    implements OnInit, OnDestroy, AfterViewInit
{
    date$!: Observable<Date>
    hrr_legends = HRR_TABLE_LEGENDS
    tableData: any[] = []
    hrr_tableData: any = []
    isRAG = false
    enableRAG = false
    hrr_type: any
    feature = HOTRUNNINGRAIL_WEATHER_PARAMETERS

    constructor(
        private subjectService: SubjectService,
        private api: ApiCallService,
        private mapService: MapService,
    ) {}

    ngOnInit(): void {
        this.date$ = this.subjectService.date
    }

    ngAfterViewInit(): void {
        //Initialize map here
        const post_options = {
            wpi: [1],
            module: 2,
        }
        this.mapService.getLayerMetadata(post_options)
    }

    /** calling the hot running rail api */
    hrrTable(mduList: string[]) {
        this.api
            .singleApiCall(API_END_POINTS.hotRunningRail, 'GET')
            .subscribe((data) => {
                this.hrr_tableData = data
                this.tabularContent(mduList, this.hrr_tableData)
            })
    }
    /** collecting the selected filter valuse from the filter panel and providinig it to api call */
    getFilteredTable(filterCollection: IFilters) {
        const { mdus } = filterCollection
        if (mdus.length > 0) {
            this.hrrTable(mdus)
        } else {
            this.tableData = []
        }
    }
    /** serching and sorting the table data and refactring it as per the table redering requirement */
    tabularContent(selectedMDUs: string[], hrr_data: any) {
        const arr: any = {}
        const filterMDU = hrr_data.filter((mduobj: any) =>
            selectedMDUs.includes(mduobj['MDUName']),
        )
        filterMDU.forEach((Obj: any) => {
            const tableArray = arr[Obj['MDUName']] ? arr[Obj['MDUName']] : []
            arr[Obj['MDUName']] = [...tableArray, ...[Obj]]
        })
        this.tableData = []
        selectedMDUs.forEach((mdu) => {
            this.tableData.push(arr[mdu])
        })
    }

    selectParameter(selected_hrr_type: any) {
        //alert(hrr_type);
        this.hrr_type = selected_hrr_type.id
        this.mapService.para_details = weatherParameter[this.hrr_type]
        this.enableRAG = this.mapService.para_details.isRag
        this.mapService.isRag = false
        this.mapService.createSubParameterLayers(selected_hrr_type)
        this.mapService.showWeatherData(this.hrr_type)
    }

    ragStatus(component: string) {
        console.log('RAG in HRR')
        this.showRAG()
    }

    selectedWeatherParameters(selectedParam: { id: string; name: string }) {
        // console.log(selectedParam);
        this.selectParameter(selectedParam)
    }

    async showRAG() {
        this.isRAG = true
        this.mapService.isRag = this.isRAG
        let promiseArray
        if (this.isRAG) {
            /*const promiseArray = [
                fetch(
                    API_END_POINTS.gisMicroservices +
                        API_END_POINTS.regionRagStatus,
                ),
                fetch(
                    API_END_POINTS.gisMicroservices +
                        API_END_POINTS.routeRagStatus,
                ),
                fetch(
                    API_END_POINTS.gisMicroservices +
                        API_END_POINTS.mduRagStatus,
                ),
            ]*/
            if (this.hrr_type === '2') {
                promiseArray = [
                    fetch(
                        API_END_POINTS.gisMicroservices +
                            API_END_POINTS.hrrRagStatus,
                    ),
                ]
            } else {
                promiseArray = [
                    fetch(
                        API_END_POINTS.gisMicroservices +
                            API_END_POINTS.hrrAirRagStatus,
                    ),
                ]
            }
            // const promiseArray = [
            //     fetch(
            //         API_END_POINTS.gisMicroservices +
            //             API_END_POINTS.hrrRagStatus,
            //     )
            // ]
            const res = await Promise.all(promiseArray)
            const data = await Promise.all(res.map((r) => r.json()))
            console.log('Rag Status For Region, Route and MDU')
            console.log(data)
            this.mapService.ragStatusData = data
            this.mapService.showWeatherData(this.hrr_type)
        }
    }
    ngOnDestroy() {
        this.mapService.para_details = undefined
        this.mapService.ragStatusData = undefined
    }
}
