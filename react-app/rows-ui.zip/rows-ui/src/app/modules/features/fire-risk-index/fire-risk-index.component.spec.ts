import { TestBed } from '@angular/core/testing'
import { of } from 'rxjs'

import { FireRiskIndexComponent } from './fire-risk-index.component'
import { ApiCallService } from 'src/app/services/web-serivces/api-call.service'
import { API_END_POINTS } from '../../../core/configuration/api-endpoints'
import {
    IDropdownSelectedList,
    IFilters,
    IFireSteamRisk,
    IUser,
    IValue,
} from 'src/app/shared/interfaces/interface'

describe('FireRiskIndexComponent', () => {
    let component: FireRiskIndexComponent
    let apiCallServiceSpy: jasmine.SpyObj<ApiCallService>

    beforeEach(() => {
        const apiCallServiceSpyObj = jasmine.createSpyObj('ApiCallService', [
            'singleApiCall',
        ])

        TestBed.configureTestingModule({
            providers: [
                FireRiskIndexComponent,
                { provide: ApiCallService, useValue: apiCallServiceSpyObj },
            ],
        })

        component = TestBed.inject(FireRiskIndexComponent)
        apiCallServiceSpy = TestBed.inject(
            ApiCallService,
        ) as jasmine.SpyObj<ApiCallService>
    })

    describe('ngOnInit', () => {
        it('should call collectFireRiskData', () => {
            component.ngOnInit()
            expect(component.collectFireRiskData()).toHaveBeenCalled()
            expect(component.collectSteamRiskData()).toHaveBeenCalled()
        })
    })

    describe('onChange', () => {
        it('should assign value to selectedState', () => {
            const state = { val: 0 }
            component.onChange(state)
            expect(component.selectedState).toEqual(0)
        })

        it('should call checkForEmptySelection', () => {
            const state = { val: 0 }
            component.onChange(state)
            expect(component.checkForEmptySelection()).toHaveBeenCalled()
        })
    })

    describe('collectFireRiskData', () => {
        it('should collect the data from api', () => {
            const mockedData = [
                {
                    RouteName: 'Anglia',
                    RegionName: 'Eastern',
                    MDUName: 'Ipswich MDU',
                    WeatherParamName: 'fire-risk',
                    Value: [
                        {
                            Day_Date: 'Mon 01/05',
                            MaxFireTemp: '1.00',
                        },
                        {
                            Day_Date: 'Tue 02/05',
                            MaxFireTemp: '1.00',
                        },
                        {
                            Day_Date: 'Wed 03/05',
                            MaxFireTemp: '1.00',
                        },
                        {
                            Day_Date: 'Thu 04/05',
                            MaxFireTemp: '1.00',
                        },
                        {
                            Day_Date: 'Fri 05/05',
                            MaxFireTemp: '2.00',
                        },
                        {
                            Day_Date: 'Sat 06/05',
                            MaxFireTemp: '4.00',
                        },
                        {
                            Day_Date: 'Sun 07/05',
                            MaxFireTemp: '1.00',
                        },
                        {
                            Day_Date: 'Mon 08/05',
                            MaxFireTemp: '1.00',
                        },
                        {
                            Day_Date: 'Tue 09/05',
                            MaxFireTemp: '5.00',
                        },
                        {
                            Day_Date: 'Wed 10/05',
                            MaxFireTemp: '2.00',
                        },
                    ],
                },
            ]
            apiCallServiceSpy.singleApiCall.and.returnValue(of(mockedData))
            component.collectFireRiskData()
            expect(apiCallServiceSpy.singleApiCall).toHaveBeenCalledWith(
                API_END_POINTS.fireRisk,
                'GET',
            )
            expect(component.collectHeader(mockedData)).toHaveBeenCalled()
        })
    })

    describe('collectSteamRiskData', () => {
        it('should collect the data from api when collectSteamRiskData called', () => {
            const mockedData = [{}]
            apiCallServiceSpy.singleApiCall.and.returnValue(of(mockedData))
            component.collectSteamRiskData()
            expect(apiCallServiceSpy.singleApiCall).toHaveBeenCalledWith(
                API_END_POINTS.steamRisk,
                'GET',
            )
            expect(component.collectHeader(mockedData)).toHaveBeenCalled()
        })
    })

    describe('getFilteredTable', () => {
        it('should filter the tabular data', () => {
            const filteredData: IFilters = {
                name: '0',
                action: 'submit',
                regions: ['Southern'],
                routes: ['Kent'],
                mdus: ['Ashford MDU', 'Lon Bridge MDU', 'Orpington MDU'],
            }

            component.getFilteredTable(filteredData)
            expect(component.FireSteamObj[0].boundries.region).toEqual([
                'Southern',
            ])
        })
        it('should filter the tabular data', () => {
            const filteredData: IFilters = {
                name: '0',
                action: 'reset',
                regions: ['Southern'],
                routes: ['Kent'],
                mdus: ['Ashford MDU', 'Lon Bridge MDU', 'Orpington MDU'],
            }

            component.getFilteredTable(filteredData)
            expect(component.FireSteamObj[0].selectedBoundries.region).toEqual([
                'Southern',
            ])
        })
    })

    describe('checkForEmptySelection', () => {
        it('should check when no selection to region', () => {
            const user: IUser = {
                region: 'Southern',
                route: 'Kent',
                mdu: 'Ashford MDU',
                id: '',
                name: '',
                username: '',
                email: '',
                designation: '',
                firstLogin: false,
            }
            component.checkForEmptySelection()
            component.FireSteamObj[0].boundries.region.length = 0
            expect(component.FireSteamObj[0].boundries.region).toEqual(
                'Southern',
            )
        })
        it('should check when no selection to route', () => {
            const user: IUser = {
                region: 'Southern',
                route: 'Kent',
                mdu: 'Ashford MDU',
                id: '',
                name: '',
                username: '',
                email: '',
                designation: '',
                firstLogin: false,
            }
            component.checkForEmptySelection()
            component.FireSteamObj[1].boundries.route.length = 0
            expect(component.FireSteamObj[1].boundries.region).toEqual(
                user.route,
            )
        })
    })

    describe('filterTable', () => {
        it('should return empty array when no filter selected', () => {
            const mockFilter: IDropdownSelectedList = {
                name: 'mdu',
                selectedItems: ['Eastern'],
            }
            const mockTable: IFireSteamRisk[] = [
                {
                    RouteName: 'Anglia',
                    RegionName: 'Eastern',
                    MDUName: 'Ipswich MDU',
                    WeatherParamName: 'fire-risk',
                    Value: [
                        {
                            Day_Date: 'Mon 01/05',
                            MaxFireTemp: '1.00',
                        },
                    ],
                },
            ]
            component.filterTable(mockFilter, mockTable)
            expect(component.filterTable(mockFilter, mockTable)).toEqual([])
        })
        it('should return region which got selected', () => {
            const mockFilter: IDropdownSelectedList = {
                name: 'region',
                selectedItems: ['Eastern'],
            }
            const mockTable: IFireSteamRisk[] = [
                {
                    RouteName: 'Anglia',
                    RegionName: 'Eastern',
                    MDUName: 'Ipswich MDU',
                    WeatherParamName: 'fire-risk',
                    Value: [
                        {
                            Day_Date: 'Mon 01/05',
                            MaxFireTemp: '1.00',
                        },
                    ],
                },
            ]
            component.filterTable(mockFilter, mockTable)
            expect(
                component.filterTable(mockFilter, mockTable).length,
            ).toBeGreaterThan(0)
        })
    })
})
