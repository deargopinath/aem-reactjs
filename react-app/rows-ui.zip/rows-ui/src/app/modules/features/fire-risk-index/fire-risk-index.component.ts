import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core'
import {
    CAPTION,
    FIRERISK_WEATHER_PARAMETERS,
    FIRE_RISK_LEGENDS,
    STEAM_RISK_LEGENDS,
    TOGGLE_TAB,
} from '../../../core/constants/app.constants'
import { ApiCallService } from 'src/app/services/web-serivces/api-call.service'
import { API_END_POINTS } from 'src/environments/environment'
import { FilterPanelComponent } from 'src/app/components/filter-panel/filter-panel.component'
import { UserAuthService } from 'src/app/services/user-auth.service'
import {
    IBoundaries,
    IDropdownSelectedList,
    IFilters,
    IFireSteam,
    IFireSteamRisk,
    IUser,
} from 'src/app/shared/interfaces/interface'
import { MapService } from '../../../services/gis/map.service'
import { weatherParameter } from '../../../core/properties/app.properties'

@Component({
    selector: 'app-fire-risk-index',
    templateUrl: './fire-risk-index.component.html',
    styleUrls: ['./fire-risk-index.component.scss'],
})
export class FireRiskIndexComponent implements OnInit, AfterViewInit {
    @ViewChild('filter') filterComponent!: FilterPanelComponent
    //toggle between fire and steam tab
    toggleTab = TOGGLE_TAB
    selectedState = this.toggleTab.fire
    //make use the values once you get from DB-backend
    issued_date = 'Thursday 30 Mar'
    issued_time = '02:41 PM'
    valid_date = 'Friday 31 Mar'
    valid_time = '01:41 PM'

    //tabular column headers
    header_date_time: {
        Day_Date: string
        MaxFireTemp?: string
        MaxSteamTemp?: string
    }[] = []

    FireSteamObj: IFireSteam = {
        0: {
            boundries: {
                region: [],
                route: [],
                mdu: [],
            },
            selectedBoundries: {
                region: [],
                route: [],
                mdu: [],
            },
            title: CAPTION[0],
            legends: FIRE_RISK_LEGENDS,
            tableData: [],
            cacheTable: [],
        },
        1: {
            boundries: {
                region: [],
                route: [],
                mdu: [],
            },
            selectedBoundries: {
                region: [],
                route: [],
                mdu: [],
            },
            title: CAPTION[1],
            legends: STEAM_RISK_LEGENDS,
            tableData: [],
            cacheTable: [],
        },
    }

    selectedTabBoundries: IBoundaries = {
        region: [],
        route: [],
        mdu: [],
    }

    user!: IUser

    feature = FIRERISK_WEATHER_PARAMETERS
    enableRAG = false

    constructor(
        private apiCall: ApiCallService,
        private userSvc: UserAuthService,
        private mapService: MapService,
    ) {}

    ngOnInit(): void {
        this.userSvc.getUser().subscribe((user) => {
            this.user = user
            this.FireSteamObj[0].selectedBoundries.route = [user.route]
            this.FireSteamObj[1].selectedBoundries.route = [user.route]
        })
        this.collectFireRiskData()
        this.collectSteamRiskData()
    }
    ngAfterViewInit(): void {
        //Initialize map here
        const post_options = {
            wpi: [2],
            module: 2,
        }
        this.mapService.getLayerMetadata(post_options)
    }

    // trigger the function once tab switched
    onChange(event: any) {
        this.selectedState = event.value
        this.checkForEmptySelection()
        this.getFilteredTable({
            action: 'Submit',
            name: '' + event.value,
            regions: this.FireSteamObj[this.selectedState].boundries.region,
            routes: this.FireSteamObj[this.selectedState].boundries.route,
            mdus: this.FireSteamObj[this.selectedState].boundries.mdu,
        })
    }

    //api integration for fire
    collectFireRiskData() {
        this.apiCall
            .singleApiCall(API_END_POINTS.fireRisk, 'GET')
            .subscribe((fire_tabular_data: Array<IFireSteamRisk>) => {
                this.FireSteamObj[0].cacheTable = fire_tabular_data
                const initSelected = {
                    name: 'route',
                    selectedItems: this.FireSteamObj[0].selectedBoundries.route,
                }
                this.FireSteamObj[0].tableData = this.filterTable(
                    initSelected,
                    fire_tabular_data,
                )
                this.collectHeader(fire_tabular_data)
            })
    }

    //api integration for steam
    collectSteamRiskData() {
        this.apiCall
            .singleApiCall(API_END_POINTS.steamRisk, 'GET')
            .subscribe((steam_tabular_data: Array<IFireSteamRisk>) => {
                this.FireSteamObj[1].cacheTable = steam_tabular_data
                const initSelected = {
                    name: 'route',
                    selectedItems: this.FireSteamObj[1].selectedBoundries.route,
                }
                this.FireSteamObj[1].tableData = this.filterTable(
                    initSelected,
                    steam_tabular_data,
                )
                this.collectHeader(steam_tabular_data)
            })
    }

    //Collect column header (date and time)
    collectHeader(data: any) {
        this.header_date_time = data[0].Value
    }
    /** collect the filterd values from primary filter */
    getFilteredTable(filterData: IFilters) {
        this.FireSteamObj[this.selectedState].boundries.region = [
            ...filterData.regions,
        ]
        this.FireSteamObj[this.selectedState].boundries.route = [
            ...filterData.routes,
        ]
        this.FireSteamObj[this.selectedState].boundries.mdu = [
            ...filterData.mdus,
        ]
        if (filterData.action === 'reset') {
            this.FireSteamObj[this.selectedState].selectedBoundries.region = [
                ...filterData.regions,
            ]
            this.FireSteamObj[this.selectedState].selectedBoundries.route = [
                ...filterData.routes,
            ]
            this.FireSteamObj[this.selectedState].selectedBoundries.mdu = [
                ...filterData.mdus,
            ]
        }
        const initSelected = {
            name: 'route',
            selectedItems: [...filterData.routes],
        }
        this.filterTableBySecondayFilters(initSelected)
    }
    /** check if there is no all filters all empty and set the initials values */
    checkForEmptySelection() {
        if (this.FireSteamObj[this.selectedState].boundries.region.length === 0)
            this.FireSteamObj[this.selectedState].boundries.region = [
                this.user.region,
            ]
        if (this.FireSteamObj[this.selectedState].boundries.route.length === 0)
            this.FireSteamObj[this.selectedState].boundries.route = [
                this.user.route,
            ]
        if (this.FireSteamObj[this.selectedState].boundries.mdu.length === 0)
            this.FireSteamObj[this.selectedState].boundries.mdu = [
                this.user.mdu,
            ]
        this.filterComponent.setRoute(
            this.FireSteamObj[this.selectedState].boundries.region,
        )
    }
    /** collect the filterd values from secondary filter */
    filterTableBySecondayFilters(selectedFilters: IDropdownSelectedList) {
        type nameType = 'region' | 'route' | 'mdu'
        const { name } = selectedFilters
        const emptySelectedFilter = {
            region: [],
            route: [],
            mdu: [],
        }
        this.FireSteamObj[this.selectedState].selectedBoundries =
            emptySelectedFilter
        this.FireSteamObj[this.selectedState].selectedBoundries[
            name as nameType
        ] = selectedFilters.selectedItems
        this.FireSteamObj[this.selectedState].tableData = this.filterTable(
            selectedFilters,
            this.FireSteamObj[this.selectedState].cacheTable,
        )
    }
    /** filter the table based on secondary filters */
    filterTable(
        selectedFilters: IDropdownSelectedList,
        cacheTableData: Array<IFireSteamRisk>,
    ): Array<IFireSteamRisk> {
        const { name } = selectedFilters
        if (name === 'mdu') {
            return cacheTableData.filter((row: IFireSteamRisk) =>
                selectedFilters.selectedItems.includes(row.MDUName),
            )
        }
        if (name === 'route') {
            return cacheTableData.filter((row: IFireSteamRisk) =>
                selectedFilters.selectedItems.includes(row.RouteName),
            )
        }

        if (name === 'region') {
            return cacheTableData.filter(
                (row: IFireSteamRisk) =>
                    selectedFilters.selectedItems.includes(row.RegionName) &&
                    this.FireSteamObj[
                        this.selectedState
                    ].boundries.route.includes(row.RouteName),
            )
        }
        return []
    }

    selectedWeatherParameters(selectedParam: { id: string; name: string }) {
        console.log(selectedParam.id)
        this.selectParameter(selectedParam)
    }

    selectParameter(selected_hrr_type: any) {
        //alert(hrr_type);
        const sub_par_id = selected_hrr_type.id
        console.log('Inside select Parmeter')
        console.log(selected_hrr_type)
        this.mapService.para_details = weatherParameter[sub_par_id]
        this.enableRAG = this.mapService.para_details.isRag
        this.mapService.isRag = false
        this.mapService.createSubParameterLayers(selected_hrr_type)
        this.mapService.showWeatherData(sub_par_id)
    }
}
