import { Component, OnInit, OnDestroy } from '@angular/core'

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, OnDestroy {
    title = 'rows'
    constructor() {}

    ngOnInit(): void {
        console.log("ngOnInit method")
    }

    ngOnDestroy(): void {
        console.log("ngOnDestroy method")
    }
}
