export const OS_MAP_KEY = '6PwXT5TfRafO8Twpg7jppKpPrAGrin8N'
export const mapId = 'mapDiv'
export const zoomToFeatures = 'getzfeature'
export const wmsLayers: any = {
    region: {
        isActive: true,
        workbench: 'NRGISP',
        serviceType: 'wms',
        layer_name: 'Region',
        min_resolution: 1120,
        max_resolution: 2800,
        layer_parameters: {
            ragIndex: 0,
            serviceAttribute: 'region_nam',
            ragAttribute: '1',
            RagValueAttribute: '4',
            geometry_type: 'Polygon',
            default_fill_color: 'rgba(0, 0, 0, 0)',
            default_stroke_style: 'line',
            line_dash: null,
            default_stroke_color: 'rgba(58, 182, 232, 1)',
            default_stroke_width: 2,
        },
    },
    route: {
        isActive: true,
        workbench: 'NRGISP',
        serviceType: 'wms',
        layer_name: 'Route',
        min_resolution: 560,
        max_resolution: 1120,
        layer_parameters: {
            ragIndex: 1,
            serviceAttribute: 'route_name',
            ragAttribute: '1',
            RagValueAttribute: '4',
            geometry_type: 'Polygon',
            default_fill_color: 'rgba(0, 0, 0, 0)',
            default_stroke_style: 'line',
            line_dash: null,
            default_stroke_color: 'rgba(255, 0, 0, 1)',
            default_stroke_width: 0.5,
        },
    },
    mdu: {
        isActive: true,
        workbench: 'NRGISP',
        serviceType: 'wms',
        layer_name: 'MDU',
        min_resolution: 280,
        max_resolution: 560,
        layer_parameters: {
            ragIndex: 2,
            serviceAttribute: 'mdu_name',
            ragAttribute: '1',
            RagValueAttribute: '4',
            geometry_type: 'Polygon',
            default_fill_color: 'rgba(0, 0, 0, 0)',
            default_stroke_style: 'dash',
            line_dash: [10, 10],
            default_stroke_color: 'rgba(0, 0, 255, 1)',
            default_stroke_width: 0.5,
        },
    },
}
export const rasterLayers: any = {
    '10KM_Rag': {
        isActive: true,
        workbench: 'NRGISP',
        serviceType: 'Raster',
        layer_name: '10KM_Rag',
        min_resolution: 85.70161721494897,
        max_resolution: 276.5039080164277,
        layer_parameters: {
            serviceAttribute: 'REGION_NAM',
            ragAttribute: 'Region',
            csvhotRailAttribute: 'MaxTemp',
            geometry_type: 'Polygon',
            default_fill_color: 'rgba(0, 0, 0, 0)',
            default_stroke_style: 'line',
            line_dash: null,
            default_stroke_color: 'rgba(58, 182, 232, 1)',
            default_stroke_width: 2,
        },
    },
    '2KM_Rag': {
        isActive: true,
        workbench: 'NRGISP',
        serviceType: 'Raster',
        layer_name: '2KM_Rag',
        min_resolution: 0,
        max_resolution: 85.70161721494897,
        layer_parameters: {
            serviceAttribute: 'REGION_NAM',
            ragAttribute: 'Region',
            csvhotRailAttribute: 'MaxTemp',
            geometry_type: 'Polygon',
            default_fill_color: 'rgba(0, 0, 0, 0)',
            default_stroke_style: 'line',
            line_dash: null,
            default_stroke_color: 'rgba(58, 182, 232, 1)',
            default_stroke_width: 2,
        },
    },
    '1KM_Color': {
        isActive: true,
        workbench: 'NRGISP',
        serviceType: 'Raster',
        layer_name: '1KM_Color',
        min_resolution: 0,
        max_resolution: 85.70161721494897,
        layer_parameters: {
            serviceAttribute: 'REGION_NAM',
            ragAttribute: 'Region',
            csvhotRailAttribute: 'MaxTemp',
            geometry_type: 'Polygon',
            default_fill_color: 'rgba(0, 0, 0, 0)',
            default_stroke_style: 'line',
            line_dash: null,
            default_stroke_color: 'rgba(58, 182, 232, 1)',
            default_stroke_width: 2,
        },
    },
}
export const weatherParameter: any = {
    '1': {
        weatherParameter: '',
        id: '1',
        isRag: false,
        horizon: '1hour',
        image_path:
            'weatherImages/rail-surface-temp/HotRail_1hr_20230501_10_GeoTif/202305dateThour00Z.tif',
        image_extent: [
            -5.852141, 50.101091999999994, 1.7658589999999998, 58.603092,
        ],
    },
    '2': {
        weatherParameter: '',
        id: '2',
        isRag: true,
        horizon: '24hour',
        image_path:
            'weatherImages/rail-surface-temp/HotRail_24hr_20230501_10_GeoTif/2KmColorGrid/202305dateT0300Z.tif',
        image_path_10KM_RAG:
            'weatherImages/rail-surface-temp/HotRail_24hr_20230501_10_GeoTif/10KmGrid/202305dateT0300Z.tif',
        image_path_2KM_RAG:
            'weatherImages/rail-surface-temp/HotRail_24hr_20230501_10_GeoTif/2KmGrid/202305dateT0300Z.tif',
        image_extent: [
            -5.852141, 50.101091999999994, 1.7658589999999998, 58.603092,
        ],
        image_extent_10: [
            -5.904141, 50.075092, 1.765858999999999, 58.655091999999996,
        ],
        image_extent_2: [
            -5.852141, 50.101091999999994, 1.7658589999999998, 58.603092,
        ],
    },
    '3': {
        weatherParameter: '',
        id: '3',
        isRag: false,
        horizon: '1hour',
        image_path:
            'weatherImages/rail-surface-temp/HotRail_AirTemp_1Hr/2KMGridColor/202305dateThour00Z.tif',
        image_extent: [
            -5.852141, 50.101091999999994, 1.7658589999999998, 58.603092,
        ],
    },
    '4': {
        weatherParameter: '',
        id: '4',
        isRag: true,
        horizon: '24hour',
        image_path:
            // 'rail-surface-temp/HotRail_24hr_20230501_10_GeoTif/2KMColorGrid/202305dateT0300Z.tif',
            'weatherImages/rail-surface-temp/HotRail_AirTemp_24HrMax/2KMGridColor/202305dateT0300Z.tif',
        image_path_10KM_RAG:
            'weatherImages/rail-surface-temp/HotRail_AirTemp_24HrMax/10KMGridRAG/202305dateT0300Z.tif',
        image_path_2KM_RAG:
            'weatherImages/rail-surface-temp/HotRail_AirTemp_24HrMax/2KMGridRAG/202305dateT0300Z.tif',
        image_extent: [
            -5.852141, 50.101091999999994, 1.7658589999999998, 58.603092,
        ],
        image_extent_10: [
            -5.904141, 50.075092, 1.765858999999999, 58.655091999999996,
        ],
        image_extent_2: [
            -5.852141, 50.101091999999994, 1.7658589999999998, 58.603092,
        ],
    },
}
