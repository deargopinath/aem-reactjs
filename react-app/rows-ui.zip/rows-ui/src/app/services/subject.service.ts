import { Injectable } from '@angular/core'
import { BehaviorSubject, Subject } from 'rxjs'
import { IWidgetAlignment } from '../shared/interfaces/interface'

@Injectable({
    providedIn: 'root',
})
export class SubjectService {
    //BehaviorSubject
    public date = new BehaviorSubject<Date>(new Date())
    public organizationalBoundaries = new BehaviorSubject<any>({})
    public updateWidget = new Subject<Array<any>>()
    public adComponents = new Subject<{ component: any; section: number }>()
    public weatherType = new BehaviorSubject<string>('isForecast')
    public adjustWidgetsPosition = new BehaviorSubject<IWidgetAlignment>({
        left: false,
        right: false,
    })
    public isReset = new BehaviorSubject<boolean>(false)
    public tab = new BehaviorSubject<number>(0)
    public tableButton = new BehaviorSubject<boolean>(false)
    public parameterName = new Subject<string>()
    public subParameterName = new Subject<string>()
    public isCapsuleSelected = new BehaviorSubject<boolean>(false)
}
