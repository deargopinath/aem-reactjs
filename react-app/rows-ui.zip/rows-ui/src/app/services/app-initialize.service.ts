import { Injectable } from '@angular/core'
import { SubjectService } from './subject.service'
import { TIME_DELAY } from '../core/properties/application.properties'
import { ApiCallService } from './web-serivces/api-call.service'
import { API_END_POINTS } from 'src/environments/environment'
import { OrganizationBoundaryService } from './organization-boundary.service'
@Injectable({
    providedIn: 'root',
})
export class AppInitializeService {
    constructor(
        private subjectService: SubjectService,
        private apiCall: ApiCallService,
        private orgBoundarySvc: OrganizationBoundaryService,
    ) {}

    onApplicationLoad() {
        this.getOrganizationalBoundaries()
        this.dateTimeCounter(TIME_DELAY)
    }

    // update the time and date though out the application in given time interval
    private dateTimeCounter(timeDelay: number) {
        if (typeof Worker === 'undefined') {
            return
        }
        const worker = new Worker(
            new URL('../workers/app.worker.ts', import.meta.url),
        )
        worker.onmessage = ({ data }) => {
            this.subjectService.date.next(data.data)
        }
        setInterval(() => {
            worker.postMessage(new Date())
        }, timeDelay)
    }

    // calling for organizational boundaries and restrcuturing the data structure
    private getOrganizationalBoundaries() {
        this.apiCall
            .singleApiCall(API_END_POINTS.organizationalBoundry, 'GET')
            .subscribe((filter) => {
                this.subjectService.organizationalBoundaries.next(
                    this.orgBoundarySvc.resructureBoundariesData(filter),
                )
            })
    }

    // getCurrentWindForecast(region: string, route:string): Observable<WindCurrent[]> {
    //     const url = `${API_END_POINTS.windForecast}/${region}/${route}/`;
    //     return this.http.get<WindCurrent[]>(url);
    // }
}
