import { Injectable, EventEmitter } from '@angular/core'
import {
    OS_MAP_KEY,
    wmsLayers,
    rasterLayers,
} from '../../core/properties/app.properties'
import proj4 from 'proj4'
import { register } from 'ol/proj/proj4.js'
import Map from 'ol/Map'
import {
    ScaleLine,
    FullScreen,
    defaults as defaultControls,
    Zoom,
} from 'ol/control'
import {
    Tile as TileLayer,
    Vector as VectorLayer,
    Image as ImageLayer,
} from 'ol/layer'
import { XYZ, Vector as VectorSource, TileWMS, ImageStatic } from 'ol/source'
import { GeoJSON } from 'ol/format'
import TileGrid from 'ol/tilegrid/TileGrid.js'
import View from 'ol/View'
import { Style, Fill, Stroke, Circle, Text } from 'ol/style'
//import { API_END_POINTS } from 'src/app/core/configuration/api-endpoints'
import { API_END_POINTS } from '../../../environments/environment'
//import { polygon } from '@turf/helpers'
import * as turf from '@turf/turf'
import { unByKey } from 'ol/Observable'
import { Point } from 'ol/geom'
import { Feature } from 'ol'
import { fromLonLat } from 'ol/proj'
import { ApiCallService } from 'src/app/services/web-serivces/api-call.service'
//import {WMTSCapabilities} from 'ol/format'
//rows_admin_user/nr#rowsGisdev6001AdminU$er!
@Injectable({ providedIn: 'root' })
export class MapService {
    private map = new Map()
    private baseMapLayer = new TileLayer()
    private tilegrid = new TileGrid({ resolutions: [], origin: [] })
    mapIds = new Array<string>()
    mapScale = new ScaleLine()
    layerMetadata: any
    private MapLayers: any = {
        wms_layers: [],
        rag_layers: [],
        image_layers: [],
    }
    //parser = new WMTSCapabilities();
    selectedRouteParam: any
    routeLayer: any
    isRag = false
    dateRange: any
    ragStatusData: any = null
    ragStyles: any
    gridType: any
    isZoomLocation = false
    highlight_layer: any
    DEFAULT_DPI = 25.4 / 0.28
    inchesPerMeter = 1000 / 25.4
    //scale = resolution * inchesPerMeter * dpi;

    //scale = resolution*(1000/25.4)*(25.4/0.28)
    //resolution = scale * 0.28 / 1000
    module_id: any
    weather_parameter: any
    weather_sub_parameter: any
    para_details: any = null
    hour_count: any
    day_count: any
    image_date: any
    image_hour: any
    wetherParameterChange: EventEmitter<any> = new EventEmitter()
    constructor(private apiCall: ApiCallService) {
        proj4.defs(
            'EPSG:27700',
            '+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +towgs84=446.448,-125.157,542.06,0.15,0.247,0.842,-20.489 +units=m +no_defs',
        )
        register(proj4)
    }

    getLayerMetadata(post_options: any) {
        /*let post_options = {
            wpi:this.mapService.weather_parameter,
            module:this.mapService.module_id
        }*/
        /*let post_options = {
            wpi:2,
            module:2
        }*/
        this.apiCall
            .singleApiCall(
                API_END_POINTS.gisMicroservices + API_END_POINTS.layerMetadata,
                'POST',
                post_options,
            )
            .subscribe((data: any) => {
                console.log('layer metadata', data)
                this.layerMetadata = data
                this.createLayers()
            })
    }

    getWetherParameterChange() {
        return this.wetherParameterChange
    }

    updateSize(moduleType: string, mapContainerId: string): void {
        this.tilegrid = new TileGrid({
            resolutions: [
                896.0, 448.0, 224.0, 112.0, 56.0, 28.0, 14.0, 7.0, 3.5, 1.75,
            ],
            origin: [-238375.0, 1376256.0],
        })
        this.mapScale = new ScaleLine({
            units: 'metric',
            bar: true,
            steps: 4,
            text: true,
            minWidth: 140,
        })
        this.map = new Map({
            controls: defaultControls({
                zoom: false,
            }).extend([
                new Zoom({
                    className: 'ol-zoom custom-zoom-button',
                }),
                this.mapScale,
                new FullScreen({ className: 'custom-fullScreen-button' }),
            ]),
            view: new View({
                center: [336700, 480066], //[356434.20208689803, 518920.231217509],//transformExtent([-10.5432, 49.7212, 2.3767, 58.7380], 'EPSG:4326', 'EPSG:27700'),
                zoom: 6.5,
                projection: 'EPSG:27700',
                //resolutions: tilegrid.getResolutions(),
            }),
        })
        this.map.setTarget(mapContainerId)
        this.map.updateSize()
        //this.createLayers()
        this.createBaseMaps()
        this.map.on('moveend', this.onMoveEnd)
    }
    onMoveEnd = (evt: any) => {
        /*const scaleVal: any =
            document.getElementsByClassName('ol-scale-text')[0]
        console.log(scaleVal.innerText)
        const scaleNum = scaleVal.innerText
            .split(':')[1]
            .replaceAll(' ', '')
            .replaceAll(',', '')
        console.log(scaleNum)
        const scN = Number(scaleNum)
        console.log(this.MapLayers.wms_layers)*/
        const mapResol: any = this.map.getView().getResolution()
        if(this.isRag && mapResol <= 78){
            this.loadWeatherData_Labels();
        }
        else{
            if(this.dataVectorLayer != null){
                this.dataVectorLayer.setVisible(false)
            }
        }
        if (this.isRag && mapResol <= 280) {
            this.loadTiffImage()
        }else if (this.isRag) {
            for (let l = 0; l < this.MapLayers.image_layers.length; l++) {
                if (this.isRag) {
                    this.MapLayers.image_layers[l].layer.setVisible(false)
                }
            }
            this.loadRagWMS()
        }
        
    }

    createLayers() {
        if (this.layerMetadata.weather_parameter_layer_metadata.length > 0) {
            const wplm = this.layerMetadata.weather_parameter_layer_metadata
            for (let l = 0; l < wplm.length; l++) {
                const l_details = wplm[l]
                this.create_WMS_Maps(l_details)
            }
        }
        this.create_highlight_layer()
    }
    start_time: any
    end_time1: any
    end_time2: any

    createSubParameterLayers(s_p_details: any) {
        console.log('Adding Sub Parameter Layers')
        console.log(this.para_details)
        this.weather_sub_parameter = s_p_details
        let wplm = this.layerMetadata.weather_sub_parameter_layer_metadata
        for (var s = 0; s < wplm.length; s++) {
            if (wplm[s].wsi == s_p_details.p_details.id) {
                let l_details = wplm[s]
                this.create_WMS_Maps(l_details)
            }
        }
        this.start_time = new Date()
        console.log('start Time')
        console.log(this.start_time)
        if (false) {
            /*let hr_p_url = 'https://was-uks-nprd-waf-rowsdev6001.azurewebsites.net/geoserver/SQLServer/wms?service=WMS&version=1.1.0&request=GetMap&layers=SQLServer%3AHRR_POC_SQL&bbox=-5.839141008811627%2C50.12161917579025%2C-8.035109916187E-4%2C58.5900928771241&width=529&height=768&srs=EPSG%3A4326&styles=&format=application/openlayers#toggle';
            let dataVectorLayer = new VectorLayer();
            let dataVectorSource = new VectorSource({
                url: hr_p_url
            });
            dataVectorLayer.setSource(dataVectorSource)*/
            //let layer_p = 'SQLServer:HRR_POC_SQL'
            let layer_p = 'SQLServer:WIND_SPEED_POC'
            let layer = new TileLayer({
                source: new TileWMS({
                    url: API_END_POINTS.geoServer + '/wms',
                    params: { LAYERS: layer_p, TILED: true },
                    serverType: 'geoserver',
                    // Countries have transparency, so do not fade tiles:
                    transition: 0,
                }),
            })
            this.map.addLayer(layer)
        }
        if (false) {
            console.log('Calling data points')

            this.apiCall
                .singleApiCall(
                    API_END_POINTS.gisMicroservices +
                        API_END_POINTS.getDataPointsDataBricks,
                    'GET',
                )
                .subscribe((response) => {
                    this.end_time1 = new Date()
                    console.log('Data load Time')
                    console.log(this.end_time1)
                    console.log(this.end_time1 - this.start_time)
                    console.log('Data Points Response')
                    console.log(response)

                    let i
                    const aFeatures = []
                    const oStyle = new Style({
                        image: new Circle({
                            radius: 8,
                            stroke: new Stroke({ color: 'rgba(0, 0, 0, 1)' }),
                            //fill: new Fill({ color: 'rgba(0, 0, 0, 0.6)'}),
                        }),
                    })

                    const dataVectorLayer = new VectorLayer({
                        style: oStyle,
                    })
                    const dataVectorSource = new VectorSource()
                    for (i = 0; i < response.data.length; i++) {
                        const oStore = response.data[i]
                        /*var oFeature = new Feature({
                        geometry: new Point(
                            fromLonLat([oStore.longitude, oStore.latitude], 'EPSG:27700')
                        )
                    });*/
                        const latval = oStore[1]
                        const lonVal = oStore[2]
                        const oFeature = new Feature({
                            geometry: new Point(
                                fromLonLat([lonVal, latval], 'EPSG:27700'),
                            ),
                        })
                        aFeatures.push(oFeature)
                    }
                    dataVectorSource.addFeatures(aFeatures)
                    dataVectorLayer.setSource(dataVectorSource)
                    this.map.addLayer(dataVectorLayer)
                    this.end_time2 = new Date()
                    console.log('Data Projection Time')
                    console.log(this.end_time2)
                    console.log(this.end_time2 - this.end_time1)
                })
        }
    }

    createBaseMaps() {
        this.baseMapLayer = new TileLayer({
            source: new XYZ({
                url: API_END_POINTS.osBaseMapLight_27700 + OS_MAP_KEY,
                projection: 'EPSG:27700',
                tileGrid: this.tilegrid,
            }),
        })
        this.baseMapLayer.setBackground('rgba(170, 211, 223, 1)')
        this.baseMapLayer.on('error', (err) => {
            console.log('Base Map Error')
            console.log(err)
        })
        this.map.addLayer(this.baseMapLayer)
    }
    load_WMS_Maps() {
        const layers: any = wmsLayers
        for (const key in layers) {
            const value = layers[key]
            this.create_WMS_Maps(value)
        }
    }

    load_Raster_Layers() {
        const layers = rasterLayers
        for (const key in layers) {
            const value = layers[key]
            this.create_WMS_Maps(value)
        }
    }

    create_WMS_Maps(layer_details: any) {
        let layer_style: any = this.generateLayerStyle(layer_details)
        let layer: any

        if (
            layer_details['service_type'] == 'wms' &&
            layer_details['data_format'] == 'geojson'
        ) {
            layer = new VectorLayer({
                source: new VectorSource({
                    url: function (extent) {
                        return (
                            API_END_POINTS.geoServer +
                            layer_details['workbench'] +
                            '/' +
                            layer_details['service_type'] +
                            '?service=WFS&' +
                            'version=1.1.0&request=GetFeature&typename=' +
                            layer_details['workbench'] +
                            '%3A' +
                            layer_details['geoserver_layer_name'] +
                            '&' +
                            'outputFormat=application/json'
                        )
                    },
                    format: new GeoJSON(),
                }),
                minResolution: layer_details['min_resolution'],
                maxResolution: layer_details['max_resolution'],
                //style: layer_style,
                style: (feature) => {
                    //var type = feature.get('layer')
                    layer_style
                        .getText()
                        .setText(
                            feature.get(layer_details['service_attribute']),
                        )
                    return layer_style
                },
            })
        } else if (
            layer_details['service_type'] == 'wms' ||
            layer_details['data_format'] == 'TiledWMS'
        ) {
            layer = new TileLayer({
                source: new TileWMS({
                    url: API_END_POINTS.geoServer + '/wms',
                    params: {
                        LAYERS:
                            layer_details['workbench'] +
                            ':' +
                            layer_details['geoserver_layer_name'],
                        TILED: true,
                    },
                    serverType: 'geoserver',
                    // Countries have transparency, so do not fade tiles:
                    transition: 0,
                }),
            })
        } else if (layer_details['data_source'] == 'micro-service') {
            layer = new VectorLayer({
                source: new VectorSource(),
            })
        } else if (layer_details['geometry_type'] == 'Raster') {
            /* else if (
            layer_details['layer_name'] != 'mduoutline' &&
            layer_details['geometry_type'] != 'Raster'
        ) {
            layer = new VectorLayer({
                source: new VectorSource({
                    url: function (extent) {
                        return (
                            API_END_POINTS.geoServer +
                            layer_details['workbench'] +
                            '/' +
                            layer_details['service_type'] +
                            '?service=WFS&' +
                            'version=1.1.0&request=GetFeature&typename=' +
                            layer_details['workbench'] +
                            '%3A' +
                            layer_details['layer_name'] +
                            '&' +
                            'outputFormat=application/json'
                        )
                    },
                    format: new GeoJSON(),
                }),
                style: layer_style,
            })
        }*/
            //this.tiffLayer10KM = new ImageLayer();
            /*layer = new ImageLayer({
                minResolution: layer_details["min_resolution"],
                maxResolution: layer_details["max_resolution"]
            });*/
            layer = new ImageLayer({
                opacity: 0.7,
            })
            layer.setVisible(false)
        }
        if (layer_details['geometry_type'] == 'Raster') {
            this.MapLayers.image_layers.push({
                layer_details: layer_details,
                layer: layer,
            })
        } else {
            layer
                .getSource()
                .on('featuresloadend', this.vector_layer_post_rendered)
            this.MapLayers.wms_layers.push({
                layer_details: layer_details,
                layer: layer,
            })
        }
        this.map.addLayer(layer)
    }

    create_highlight_layer() {
        const layer_stroke = new Stroke({
            color: 'rgba(50, 168, 82, 1)',
            width: 4,
        })
        const highlight_style = new Style({
            fill: new Fill({
                color: 'rgba(50, 168, 82, 0)',
            }),
            stroke: layer_stroke,
        })
        this.highlight_layer = new VectorLayer({
            source: new VectorSource(),
            style: highlight_style,
        })
        this.map.addLayer(this.highlight_layer)
    }

    vector_layer_post_rendered = (evt: any) => {
        //
        if (this.isZoomLocation) {
            this.isZoomLocation = false
            this.clearHighlight()
            let highlight_feature: any
            const regFeatures = this.routeLayer.getSource().getFeatures()
            for (let r = 0; r < regFeatures.length; r++) {
                if (
                    regFeatures[r].get('route_name') ==
                    this.selectedRouteParam.f_name
                ) {
                    this.map
                        .getView()
                        .fit(regFeatures[r].getGeometry().getExtent())
                    highlight_feature = regFeatures[r]
                    this.highlight_layer
                        .getSource()
                        .addFeature(highlight_feature)
                }
            }
            this.routeLayer.setMaxResolution(
                wmsLayers['route']['max_resolution'],
            )
            this.routeLayer.setMinResolution(
                wmsLayers['route']['min_resolution'],
            )
            evt.target.un('featuresloadend', this.vector_layer_post_rendered)
            return
        }
        if (!this.isRag) {
            return
        }
        /*let currentdate: any
        if (this.day_count > 0) {
            currentdate = new Date(this.dateRange.from)
        } else {
            currentdate = new Date()
        }*/
        /*const hour = this.getChangeHour(
            currentdate.getHours() + this.hour_count,
        )
        let date
        if (this.para_details.id == '4') {
            date = this.getChangeDateAir(currentdate.getDate() + this.day_count)
        } else {
            date = this.getChangeDate(currentdate.getDate() + this.day_count)
        }*/
        // const date = this.getChangeDate(currentdate.getDate() + this.day_count)
        this.loadRagWMS()
        evt.target.un('featuresloadend', this.vector_layer_post_rendered)
    }

    generateLayerStyle(layer_details: any) {
        let layer_style
        let layer_stroke
        const width = 3
        if (layer_details['line_dash'] === 'dash') {
            layer_stroke = new Stroke({
                color: layer_details['default_stroke_color'],
                width: layer_details['default_stroke_width'],
                lineDash: layer_details['line_dash'],
            })
        } else {
            layer_stroke = new Stroke({
                color: layer_details['default_stroke_color'],
                width: layer_details['default_stroke_width'],
            })
        }
        if (layer_details['geometry_type'] === 'Polygon') {
            layer_style = new Style({
                fill: new Fill({
                    color: layer_details['default_fill_color'],
                }),
                stroke: layer_stroke,
                text: new Text({
                    font: '14px Calibri,sans-serif',
                    overflow: true,
                    fill: new Fill({
                        color: '#000',
                    }),
                    stroke: new Stroke({
                        color: '#fff',
                        width: 3,
                    }),
                }),
            })
        } else if (layer_details['geometry_type'] === 'Line') {
            layer_style = new Style({
                stroke: layer_stroke,
            })
        } else if (layer_details['geometry_type'] === 'Point') {
            /*layer_style = new Style({
            stroke: layer_stroke
          });*/
            layer_style = new Style({
                image: new Circle({
                    radius: width,
                    fill: new Fill({
                        color: layer_details['default_fill_color'],
                    }),
                    stroke: new Stroke({
                        color: layer_details['default_stroke_color'],
                        width: 1,
                    }),
                }),
                zIndex: Infinity,
            })
        }
        return layer_style
    }

    showLocation(locParam: any) {
        //this.isLocationSelected = true;
        //alert(locParam);
        let highlight_feature: any
        this.clearHighlight()

        if (locParam.t_name == 'National') {
            this.map.setView(
                new View({
                    center: [336700, 480066], //[356434.20208689803, 518920.231217509],//transformExtent([-10.5432, 49.7212, 2.3767, 58.7380], 'EPSG:4326', 'EPSG:27700'),
                    zoom: 6.3,
                    projection: 'EPSG:27700',
                    //resolutions: tilegrid.getResolutions(),
                }),
            )
        } else if (locParam.t_name == 'region_dissolved') {
            let regFeatures
            for (var l = 0; l < this.MapLayers.wms_layers.length; l++) {
                if (
                    this.MapLayers.wms_layers[l].layer_details.layer_name ==
                    'Region'
                ) {
                    regFeatures = this.MapLayers.wms_layers[l].layer
                        .getSource()
                        .getFeatures()
                }
            }
            const trfPol: any = []
            let f_ext
            let funion: any = null
            //const formt = new GeoJSON()
            for (var r = 0; r < regFeatures.length; r++) {
                if (regFeatures[r].get('region_nam') == locParam.f_name) {
                    trfPol.push(
                        turf.multiPolygon(
                            regFeatures[r].getGeometry().getCoordinates(),
                        ),
                    )
                    highlight_feature = regFeatures[r]
                    this.highlight_layer
                        .getSource()
                        .addFeature(highlight_feature)
                    f_ext = regFeatures[r].getGeometry().getExtent() // one ploy
                }
            }
            if (regFeatures.length == 0) {
                this.isZoomLocation = true
                this.routeLayer.setMaxResolution(5000)
                this.routeLayer.setMinResolution(0)
            } else {
                if (trfPol.length > 1) {
                    for (let u = 1; u < trfPol.length; u++) {
                        if (u == 1) {
                            funion = turf.union(trfPol[0], trfPol[1])
                        } else {
                            funion = turf.union(funion, trfPol[u])
                        }
                    }
                    console.log('Polygon Combined')
                    console.log(funion)
                    const bboxPolygon = turf.bbox(funion)
                    this.map.getView().fit(bboxPolygon)
                    //highlight_feature = new Feature(new MultiPolygon(funion.geometry.coordinates));
                    //this.highlight_layer.getSource().addFeatures(highlight_feature);
                } else {
                    this.map.getView().fit(f_ext)
                    //highlight_feature = new Feature(new MultiPolygon(trfPol[0].geometry.coordinates));
                    //this.highlight_layer.getSource().addFeatures(highlight_feature);
                }
            }
        } else if (locParam.t_name == 'route_dissolved') {
            this.selectedRouteParam = locParam
            let regFeatures
            let route_Layer
            //let route_layer_details
            for (var l = 0; l < this.MapLayers.wms_layers.length; l++) {
                if (
                    this.MapLayers.wms_layers[l].layer_details.layer_name ==
                    'Route'
                ) {
                    //route_layer_details = this.MapLayers.wms_layers[l].layer_details
                    route_Layer = this.MapLayers.wms_layers[l].layer
                    this.routeLayer = route_Layer
                    regFeatures = this.MapLayers.wms_layers[l].layer
                        .getSource()
                        .getFeatures()
                }
            }
            if (regFeatures.length == 0) {
                this.isZoomLocation = true
                this.routeLayer.setMaxResolution(5000)
                this.routeLayer.setMinResolution(0)
            } else {
                //let selFeature

                //route loaded
                const trfPolRoute: any = []
                let f_ext_Route
                let funion_Route: any = null
                //const formt__Route = new GeoJSON()
                for (var r = 0; r < regFeatures.length; r++) {
                    if (
                        regFeatures[r].get('route_name') ==
                        this.selectedRouteParam.f_name
                    ) {
                        trfPolRoute.push(
                            turf.multiPolygon(
                                regFeatures[r].getGeometry().getCoordinates(),
                            ),
                        )
                        highlight_feature = regFeatures[r]
                        this.highlight_layer
                            .getSource()
                            .addFeature(highlight_feature)
                        f_ext_Route = regFeatures[r].getGeometry().getExtent() // one ploy
                        // this.map
                        //     .getView()
                        //     .fit(regFeatures[r].getGeometry().getExtent())
                        // highlight_feature = regFeatures[r]
                        // this.highlight_layer
                        //     .getSource()
                        //     .addFeature(highlight_feature)
                    }
                }

                if (trfPolRoute.length > 1) {
                    for (let u = 1; u < trfPolRoute.length; u++) {
                        if (u == 1) {
                            funion_Route = turf.union(
                                trfPolRoute[0],
                                trfPolRoute[1],
                            )
                        } else {
                            funion_Route = turf.union(
                                funion_Route,
                                trfPolRoute[u],
                            )
                        }
                    }
                    console.log('Polygon Combined')
                    console.log(funion_Route)
                    const bboxPolygon = turf.bbox(funion_Route)
                    this.map.getView().fit(bboxPolygon)
                } else {
                    this.map.getView().fit(f_ext_Route)
                }
            }
        }
    }

    clearHighlight() {
        this.highlight_layer.getSource().clear()
    }

    showWeatherData(wParameter: string) {
        this.resetMapLayers()
        this.hour_count = 0
        this.day_count = 0
        const currentdate = new Date()
        let date
        if (wParameter == '4') {
            date = this.getChangeDateAir(currentdate.getDate())
        } else {
            date = this.getChangeDate(currentdate.getDate())
        }
        // const date = this.getChangeDate(currentdate.getDate())
        const hour = this.getChangeHour(currentdate.getHours())
        this.image_date = date
        this.image_hour = hour
        //let para = weatherParameter;
        //this.para_details = para[wParameter];
        console.log(this.para_details)
        const mapResol: any = this.map.getView().getResolution()
        if (this.isRag && mapResol > 280) {
            let layer: any
            for (let l = 0; l < this.MapLayers.image_layers.length; l++) {
                if (
                    this.MapLayers.image_layers[l].layer_details.layer_name ==
                    '1KM_Color'
                ) {
                    layer = this.MapLayers.image_layers[l]
                }
            }
            layer.layer.setVisible(false)
            this.loadRagWMS()
        } else {
            this.loadTiffImage()
        }
        this.wetherParameterChange.emit({
            index: 0,
            parameterChange: true,
            image: '',
        })
    }
    getChangeDate(givenDate: any) {
        if (givenDate % 10 == 0) {
            return '10'
        } else {
            return '0' + (givenDate % 10)
        }
    }

    getChangeDateAir(givenDate: any) {
        if (givenDate % 10 == 0) {
            return '10'
        } else {
            let localdate = givenDate % 10
            let availableDateInDB_1day_prior = 6
            if (localdate < 7) {
                availableDateInDB_1day_prior += localdate
                if (availableDateInDB_1day_prior > 10) {
                    return availableDateInDB_1day_prior
                } else {
                    return '0' + availableDateInDB_1day_prior
                }
            } else {
                return '0' + (givenDate % 10)
            }
        }
    }

    getChangeHour(givenTime: any) {
        if (givenTime != 0 && givenTime % 24 == 0) {
            this.day_count++
            return '00'
        } else {
            return givenTime % 24 < 10 ? '0' + (givenTime % 24) : givenTime % 24
        }
    }
    resetMapLayers() {
        for (let l = 0; l < this.MapLayers.wms_layers.length; l++) {
            const layer = this.MapLayers.wms_layers[l]['layer']
            layer.getSource().refresh()
        }
        for (let l = 0; l < this.MapLayers.image_layers.length; l++) {
            const layer = this.MapLayers.image_layers[l]['layer']
            layer.setSource(null)
        }
        if(this.dataVectorLayer != null){
            this.dataVectorLayer.setSource(null);
        }
    }
    loadNextData(dd: string, hh: string) {
        console.log(this.dateRange)
        if (this.layerMetadata != null) {
            const lmd = this.layerMetadata.weather_sub_parameter
            for (let l = 0; l < lmd.length; l++) {
                if (
                    lmd[l].weather_sub_parameter_id ==
                    this.weather_sub_parameter.p_details.id
                ) {
                    if (lmd[l].horizon == '24hour') {
                        this.day_count++
                    } else {
                        this.hour_count++
                    }
                }
            }
        }
        /*if (this.para_details.horizon == '24hour') {
            this.day_count++
        } else {
            this.hour_count++
        }*/
        //const currentdate = new Date(this.dateRange.from)
        /*const hour = this.getChangeHour(
            currentdate.getHours() + this.hour_count,
        )*/
        //var n = +"1";
        //const date = this.getChangeDate(+dd)
        let date
        if (this.para_details.id == '4') {
            date = this.getChangeDateAir(+dd)
        } else {
            date = this.getChangeDate(+dd)
        }
        // const date = this.getChangeDate(currentdate.getDate() + this.day_count)
        this.image_date = date
        this.image_hour = hh
        console.log(this.para_details)
        const mapResol: any = this.map.getView().getResolution()
        if (this.isRag && mapResol > 280) {
            let layer: any
            for (let l = 0; l < this.MapLayers.image_layers.length; l++) {
                if (
                    this.MapLayers.image_layers[l].layer_details.layer_name ==
                    '1KM_Color'
                ) {
                    layer = this.MapLayers.image_layers[l]
                }
            }
            layer.layer.setVisible(false)
            this.loadRagWMS()
        } else {
            this.loadTiffImage()
        }
    }
    loadRagWMS() {
        if (this.ragStatusData == null) {
            return
        }

        let data_date = '2023-05-' + this.image_date
        if (this.para_details.id === '4') {
            data_date = '2023-09-' + this.image_date
        }
        // data_date='2023-09-09'
        console.log(this.para_details)
        this.ragStyles = this.getRagStyles(null)
        const mapResol: any = this.map.getView().getResolution()
        if (mapResol > 280) {
            for (let l = 0; l < this.MapLayers.wms_layers.length; l++) {
                const layer_details =
                    this.MapLayers.wms_layers[l]['layer_details']
                if (layer_details['show_rag'] == false) {
                    continue
                }
                const layer = this.MapLayers.wms_layers[l]['layer']
                const ragIndex = layer_details['rag_index']
                const csv_field = layer_details['rag_attribute']
                const layer_field = layer_details['service_attribute']
                let csv_value_attribute
                csv_value_attribute = layer_details['rag_value_attribute']

                const layer_source = layer.getSource().getFeatures()
                //console.log("Layer Visibility");
                //console.log(layer.getVisible());
                //console.log(layer_source);
                const rData = this.ragStatusData[0][ragIndex - 1]
                const csvDataArray = rData.filter((data: any) => {
                    if (data['date'] == data_date) {
                        return true
                    } else {
                        return false
                    }
                })
                console.log(csvDataArray)
                for (let f = 0; f < layer_source.length; f++) {
                    //console.log(layer_source[f]);
                    const feature_name = layer_source[f].get(layer_field)
                    for (let c = 0; c < csvDataArray.length; c++) {
                        if (feature_name == csvDataArray[c][csv_field]) {
                            const feature = layer_source[f]
                            const max = csvDataArray[c][csv_value_attribute]
                            /*for (var i=0 ; i<numArry.length ; i++) {
                            if (max == "" || Number(numArry[i][csv_value_attribute]) > Number(max[csv_value_attribute]))
                                max = numArry[i];
                        }*/
                            if (max != '') {
                                //const max_val = Number(max)
                                const regionFill = this.generateRagStyles(
                                    csvDataArray[c].rag,
                                )
                                const layer_stroke = new Stroke({
                                    color: layer_details[
                                        'default_stroke_color'
                                    ],
                                    width: layer_details[
                                        'default_stroke_width'
                                    ],
                                })
                                const sty = new Style({
                                    fill: new Fill({
                                        color: regionFill,
                                    }),
                                    stroke: layer_stroke,
                                })
                                feature.setStyle(sty)
                            }
                        }
                    }
                }
                console.log('This is a layer')
                if (
                    this.MapLayers.wms_layers[l]['layer_post_render_event'] !=
                    null
                ) {
                    unByKey(
                        this.MapLayers.wms_layers[l]['layer_post_render_event'],
                    )
                    this.MapLayers.wms_layers[l]['layer_post_render_event'] =
                        null
                }
            }
            /*this.wetherParameterChange.emit({
                "index":0,
                "parameterChange":true,
                "image": ""
            });*/
        }
        /*else if(mapResol <= 276.5039080164277 && mapResol > 85.70161721494897){
            this.gridType = "10KM";
            this.showNextImage(this.tiffImageIndex);
        }
        else if(mapResol <= 85.70161721494897 && mapResol > 0){
            this.gridType = "2KM";
            this.showNextImage(this.tiffImageIndex);
        }*/
    }
    loadTiffImage() {
        const image_details = this.para_details
        let layer: any
        let imagePath = ''
        let imageDefaultExtent: any
        let img_type = 'COLOR'
        if (this.isRag) {
            //Show Rag Status
            const mapResol: any = this.map.getView().getResolution()
            if (mapResol <= 276.5039080164277 && mapResol > 85.70161721494897) {
                this.gridType = '10KM'
                img_type = '10KM'
                imagePath = image_details.image_path_10KM_RAG
                imageDefaultExtent = image_details.image_extent_10
            } else if (mapResol <= 85.70161721494897 && mapResol > 0) {
                this.gridType = '2KM'
                img_type = '2KM'
                imagePath = image_details.image_path_2KM_RAG
                imageDefaultExtent = image_details.image_extent_2
            }
            imagePath = imagePath.replace('date', this.image_date)
        } else {
            imagePath = image_details.image_path
            if (image_details.horizon == '1hour') {
                imagePath = imagePath.replace('hour', this.image_hour)
            }
            imagePath = imagePath.replace('date', this.image_date)
            imageDefaultExtent = image_details.image_extent
            console.log(imagePath)
            /*for(var l=0; l< this.MapLayers.image_layers.length; l++){
                if(this.MapLayers.image_layers[l].layer_details.layer_name == "1KM_Color"){
                    layer = this.MapLayers.image_layers[l];
                }
            }*/
        }
        for (let l = 0; l < this.MapLayers.image_layers.length; l++) {
            if (
                this.MapLayers.image_layers[l].layer_details.layer_name ==
                '1hrColor'
            ) {
                layer = this.MapLayers.image_layers[l]
            }
        }

        type ObjectKey = keyof typeof API_END_POINTS
        const image_API = this.layerMetadata.weather_parameter[0]
            .img_api as ObjectKey
        console.log(image_API)
        console.log(API_END_POINTS[image_API])
        const imgUrl =
            API_END_POINTS.gisMicroservices +
            API_END_POINTS[image_API] +
            '?wsp=' +
            this.weather_sub_parameter.p_details.id +
            '&dd=' +
            this.image_date +
            '&mm=' +
            '05' +
            '&yyyy=' +
            '2023' +
            '&hh=' +
            this.image_hour +
            '&mn=' +
            '00' +
            '&imageType=' +
            img_type
        console.log(imgUrl)
        const imgSource = new ImageStatic({
            url: imgUrl,
            projection: 'EPSG:4326',
            imageExtent: imageDefaultExtent,
            interpolate: false,
        })
        layer.layer.setVisible(true)
        layer.layer.setSource(imgSource)
    }
    dataVectorLayer:any = null;
    loadWeatherData_Labels(){
        if(true){
            console.log("Calling data points");
            
            this.apiCall
                .singleApiCall(
                    API_END_POINTS.gisMicroservices +
                    API_END_POINTS.getDataPoints+
                    '?dd=' + this.image_date,
                    'GET',
                )
                .subscribe((response) => {
                    this.end_time1 = new Date()
                    console.log('Data load Time')
                    console.log(this.end_time1)
                    console.log(this.end_time1 - this.start_time)
                    console.log('Data Points Response')
                    console.log(response)

                    let i
                    const aFeatures = []
                    const oStyle = new Style({
                        image: new Circle({
                            radius: 8,
                            stroke: new Stroke({ color: 'rgba(0, 0, 0, 1)' }),
                            //fill: new Fill({ color: 'rgba(0, 0, 0, 0.6)'}),
                        }),
                        text: new Text({
                            font: '10px Calibri,sans-serif',
                            overflow: true,
                            fill: new Fill({
                              color: '#000',
                            }),
                            stroke: new Stroke({
                              color: '#fff',
                              width: 3,
                            }),
                          })
                    })
                    if(this.dataVectorLayer== null){
                        this.dataVectorLayer = new VectorLayer({
                            style: (feature) => {
                                //var type = feature.get('layer');
                                oStyle.getText().setText(feature.get('maxVal'));
                                return oStyle;
                              }
                        })
                        this.map.addLayer(this.dataVectorLayer)
                    }
                    else{
                        this.dataVectorLayer.setSource(null);
                    }
                    const dataVectorSource = new VectorSource()
                    for (i = 0; i < response.length; i++) {
                        const oStore = response[i]
                        var oFeature = new Feature({
                        geometry: new Point(
                            fromLonLat([oStore.longitude, oStore.latitude], 'EPSG:27700')
                        ),
                        maxVal: oStore.rail_surfa,
                    });
                        /*const latval = oStore[0]
                        const lonVal = oStore[1]
                        const oFeature = new Feature({
                            geometry: new Point(
                                fromLonLat([lonVal, latval], 'EPSG:27700'),
                            ),
                            maxVal: oStore[2],
                        })*/
                        aFeatures.push(oFeature)
                    }
                    dataVectorSource.addFeatures(aFeatures)
                    this.dataVectorLayer.setSource(dataVectorSource)
                    this.dataVectorLayer.setVisible(true)
                    this.end_time2 = new Date()
                    console.log('Data Projection Time')
                    console.log(this.end_time2)
                    console.log(this.end_time2 - this.end_time1)
                })
        }
    }

    // generateRagStyles(val: any) {
    //     let regionFill
    //     //if(this.selectedParameter == "HotRailTemperature"){
    //     if (true) {
    //         if (val >= -50 && val < 40) {
    //             regionFill = this.ragStyles['rag-50-40']
    //         } else if (val >= 40 && val < 43) {
    //             regionFill = this.ragStyles['rag40-43']
    //         } else if (val >= 43 && val < 46) {
    //             regionFill = this.ragStyles['rag43-46']
    //         } else if (val >= 46) {
    //             regionFill = this.ragStyles['rag46-']
    //         } else {
    //             regionFill = this.ragStyles['default']
    //         }
    //     } else {
    //         if (val < 0) {
    //             regionFill = this.ragStyles['rag-less0']
    //         } else if (val >= 0 && val < 20) {
    //             regionFill = this.ragStyles['rag0-20']
    //         } else if (val >= 20 && val < 30) {
    //             regionFill = this.ragStyles['rag20-30']
    //         } else if (val >= 30 && val < 40) {
    //             regionFill = this.ragStyles['rag30-40']
    //         } else if (val >= 40) {
    //             regionFill = this.ragStyles['rag40-50']
    //         } else {
    //             regionFill = this.ragStyles['default']
    //         }
    //     }
    //     return regionFill
    // }
    generateRagStyles(val: any) {
        let regionFill
        if (val === 'G') {
            regionFill = 'rgba(0,255,0,0.5)'
        } else if (val === 'A') {
            regionFill = 'rgba(255,191,0,0.5)'
        } else if (val === 'Y') {
            regionFill = 'rgba(255,255,0,0.5)'
        } else if (val === 'R') {
            regionFill = 'rgba(255,0,0,0.5)'
        } else {
            regionFill = this.ragStyles['default']
        }
        return regionFill
    }
    getRagStyles(param: any) {
        const fillAlpha = 0.5
        let styles
        //if(param == "HotRailTemperature"){
        if (true) {
            styles = {
                default: 'rgba(0, 0, 0, 0)',
                default_rag: 'rgba(255, 0, 0, ' + fillAlpha + ')',
                'rag-50-40': 'rgba(0, 255, 0, ' + fillAlpha + ')',
                'rag40-43': 'rgba(255, 255, 0, ' + fillAlpha + ')',
                'rag43-46': 'rgba(255, 191, 0, ' + fillAlpha + ')',
                'rag46-': 'rgba(255, 0, 0, ' + fillAlpha + ')',
            }
        } else {
            styles = {
                default: 'rgba(0, 0, 0, 0)',
                default_rag: 'rgba(255, 0, 0, ' + fillAlpha + ')',
                'rag0-20': 'rgba(0, 255, 0, ' + fillAlpha + ')',
                'rag20-30': 'rgba(0, 255, 0 , ' + fillAlpha + ')',
                'rag30-40': 'rgba(255, 191, 0, ' + fillAlpha + ')',
                'rag40-50': 'rgba(255, 0, 0, ' + fillAlpha + ')',
            }
        }
        return styles
    }

    navigateRoute(routName: string, routesValue: any) {
        let regFeatures
        regFeatures = routesValue.features
        //const trfPolRoute: any = []
        let f_ext_Route: any
        let funion_Route: any = null
        for (let r = 0; r < regFeatures.length; r++) {
            if (regFeatures[r].properties.route_name == routName) {
                // trfPolRoute.push(
                //     turf.multiPolygon(regFeatures[r].geometry.coordinates),
                // )
                // trfPolRoute.push()
                funion_Route = regFeatures[r]
                const vectorSource = new VectorSource({
                    // features: new GeoJSON().readFeatures(regFeatures[r]),
                    features: new GeoJSON().readFeatures(funion_Route),
                })

                const vectorLayer = new VectorLayer({
                    source: vectorSource,
                    style: {
                        'stroke-color': 'rgba(50, 168, 82, 1)',
                        'stroke-width': 2,
                    },
                })
                if (vectorSource.getState() === 'ready') {
                    f_ext_Route = vectorSource.getExtent()
                    this.map.getView().fit(f_ext_Route)
                }
                this.map.addLayer(vectorLayer)
            }
            // const vectorSource = new VectorSource({
            //     // features: new GeoJSON().readFeatures(regFeatures[r]),
            //     features: new GeoJSON().readFeatures(funion_Route),
            // })
            // if (vectorSource.getState() === 'ready') {
            //     f_ext_Route = vectorSource.getExtent()
            //     this.map.getView().fit(f_ext_Route)
            // }
        }
    }
}
