import { Injectable } from '@angular/core'
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs'
@Injectable({
    providedIn: 'root',
})
export class ApiCallService {
    constructor(private http: HttpClient) {}

    public singleApiCall(
        url: string,
        method: string,
        params?: any,
        headers?: any,
        isPath?: boolean | false,
        responseType?: string,
        listenUrl?: string,
    ): Observable<any> {
        let header: any
        if (headers !== undefined || headers !== null) {
            header = new HttpHeaders(headers)
        }

        switch (method) {
            case 'GET':
                if (isPath) {
                    url = url + params
                    const options: any = {
                        headers: header,
                    }
                    if (responseType !== undefined) {
                        options.responseType = responseType
                    }

                    return this.http.get(url, options)
                } else {
                    const options: any = {
                        headers: header,
                        params: params,
                    }
                    if (responseType !== undefined) {
                        options.responseType = responseType
                    }
                    return this.http.get(url, options)
                }

            case 'POST':
                return this.http.post(url, params)
            default:
                return this.http.get(url)
        }
    }
}
