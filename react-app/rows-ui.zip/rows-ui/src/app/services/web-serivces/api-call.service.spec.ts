import { TestBed } from '@angular/core/testing'
import {
    HttpClientTestingModule,
    HttpTestingController,
} from '@angular/common/http/testing'
import { ApiCallService } from './api-call.service'

describe('ApiCallService', () => {
    let service: ApiCallService
    let httpMock: HttpTestingController

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [ApiCallService],
        })

        service = TestBed.inject(ApiCallService)
        httpMock = TestBed.inject(HttpTestingController)
    })

    afterEach(() => {
        httpMock.verify()
    })

    it('should send a GET request with params when isPath is false', () => {
        const url = 'https://example.com/api'
        const method = 'GET'
        const params = { id: 1 }
        const headers = { 'Content-Type': 'application/json' }
        const isPath = false
        const responseType = 'json'

        service
            .singleApiCall(url, method, params, headers, isPath, responseType)
            .subscribe((response) => {
                expect(response).toBeTruthy()
            })

        const req = httpMock.expectOne(`${url}?id=1`)
        expect(req.request.method).toBe('GET')
        expect(req.request.params.get('id')).toBe('1')
        expect(req.request.headers.get('Content-Type')).toBe('application/json')
        req.flush({})
    })

    it('should send a GET request with path when isPath is true', () => {
        const url = 'https://example.com/api/'
        const method = 'GET'
        const params = '1'
        const headers = { 'Content-Type': 'application/json' }
        const isPath = true
        const responseType = 'json'

        service
            .singleApiCall(url, method, params, headers, isPath, responseType)
            .subscribe((response) => {
                expect(response).toBeTruthy()
            })

        const req = httpMock.expectOne(`${url}1`)
        expect(req.request.method).toBe('GET')
        expect(req.request.headers.get('Content-Type')).toBe('application/json')
        req.flush({})
    })

    it('should send a POST request', () => {
        const url = 'https://example.com/api'
        const method = 'POST'
        const params = { name: 'John' }
        const headers = { 'Content-Type': 'application/json' }
        const responseType = 'json'

        service
            .singleApiCall(url, method, params, headers, false, responseType)
            .subscribe((response) => {
                expect(response).toBeTruthy()
            })

        const req = httpMock.expectOne(url)
        expect(req.request.method).toBe('POST')
        expect(req.request.body).toEqual({ name: 'John' })
        expect(req.request.headers.get('Content-Type')).toBe('application/json')
        req.flush({})
    })

    it('should send a GET request with default options', () => {
        const url = 'https://example.com/api'
        const method = ''
        const responseType = ''

        service.singleApiCall(url, method, null).subscribe((response) => {
            expect(response).toBeTruthy()
        })

        const req = httpMock.expectOne(url)
        expect(req.request.method).toBe('GET')
        req.flush({})
    })

    it('should make a GET request with the given URL and parameters', () => {
        const url = 'https://example.com/api/v1/users'
        const params = {
            name: 'John Doe',
        }

        service.singleApiCall(url, 'GET', params).subscribe((data) => {
            expect(data).toEqual({
                name: 'John Doe',
            })
        })
    })

    it('should make a POST request with the given URL and parameters', () => {
        const url = 'https://example.com/api/v1/users'
        const params = {
            name: 'John Doe',
        }

        service.singleApiCall(url, 'POST', params).subscribe((data) => {
            expect(data).toEqual({
                name: 'John Doe',
            })
        })
    })
})
