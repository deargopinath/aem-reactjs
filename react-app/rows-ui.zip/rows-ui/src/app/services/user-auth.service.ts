import { Injectable } from '@angular/core'
import { BehaviorSubject } from 'rxjs'
import { IUser } from '../shared/interfaces/interface'

@Injectable({
    providedIn: 'root',
})
export class UserAuthService {
    public isUserLoggedIn$ = new BehaviorSubject<boolean>(false)
    private user: IUser = {
        id: '1234',
        name: 'Srinivas Gopinath Parimi',
        username: 'deargopinath',
        email: 'deargopinath@gmail.com',
        region: 'Eastern',
        route: 'Anglia',
        mdu: 'Ipswitch MDU',
        designation: 'Enterprise Architect',
        firstLogin: false,
    }
    private user$ = new BehaviorSubject<IUser>(this.user)
    constructor() {}

    /** returning the user object */
    getUser() {
        return this.user$.asObservable()
    }

    getUserDetails(userdetail: {
        id: string
        name: string
        username: string
        email: string
        designation: string
    }) {

        this.user$.next(this.user)
    }
}
