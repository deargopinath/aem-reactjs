import { Injectable } from '@angular/core'

@Injectable({
    providedIn: 'root',
})
export class FilterService {
    filterTable(
        tableArray: Array<any>,
        filterParameters: string[],
        filterName: string,
    ) {
        return tableArray.filter((tableRow) => {
            return filterParameters.includes(tableRow[filterName])
        })
    }
}
