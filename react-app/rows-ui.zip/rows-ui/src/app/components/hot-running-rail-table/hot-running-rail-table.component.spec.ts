import { ComponentFixture, TestBed } from '@angular/core/testing'

import { HotRunningRailTableComponent } from './hot-running-rail-table.component'

describe('HotRunningRailTableComponent', () => {
    let component: HotRunningRailTableComponent
    let fixture: ComponentFixture<HotRunningRailTableComponent>

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [HotRunningRailTableComponent],
        })
        fixture = TestBed.createComponent(HotRunningRailTableComponent)
        component = fixture.componentInstance
        fixture.detectChanges()
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })
})
