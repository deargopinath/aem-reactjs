import { Component, OnInit } from '@angular/core'
import { Router } from '@angular/router'
import { combineLatest } from 'rxjs'
import { SubjectService } from '../../../services/subject.service'
import { ApiCallService } from '../../../services/web-serivces/api-call.service'
import { API_END_POINTS } from '../../../../environments/environment'
import { UserAuthService } from '../../../services/user-auth.service'
import {
    IDropdownSelectedList,
    IUser,
    IWidgetAlignment,
} from '../../../shared/interfaces/interface'
import { FilterService } from '../../../services/filter.service'
import { WEATHERPARAMETERS_LIST } from '../../../core/constants/app.constants'

interface IHazardForecast24Hours {
    RegionName: string
    RouteName: string
    MDUName: string
    WeatherParamName: string
    Value: Array<IHazardForecastRagStatus>
}

interface IHazardForecastRagStatus {
    DateTime: string
    MaxVal: string
    RAG: string
}

interface IFilter {
    mdu: Array<string>
    weatherParameter: Array<string>
}

@Component({
    selector: 'app-forecast24-hours',
    templateUrl: './forecast24-hours.component.html',
    styleUrls: ['./forecast24-hours.component.scss'],
})
export class Forecast24HoursComponent implements OnInit {
    minimizeTable = false
    leftAdjustment = false
    forecastDetails: Array<IHazardForecast24Hours> = []
    cacheForeCastDetails: Array<IHazardForecast24Hours> = []
    hours: Array<string> = []
    mdu: Array<string> = []
    weatherParameter: Array<string> = WEATHERPARAMETERS_LIST
    date: Date = new Date()
    user!: IUser
    selecetdFilters: IFilter = {
        mdu: [],
        weatherParameter: [],
    }
    constructor(
        private route: Router,
        private SubSvc: SubjectService,
        private api: ApiCallService,
        private userSvc: UserAuthService,
        private filterSvc: FilterService,
    ) {}

    ngOnInit(): void {
        this.SubSvc.adjustWidgetsPosition.subscribe(
            ({ left }: IWidgetAlignment) => {
                this.leftAdjustment = left
            },
        )

        combineLatest([
            this.userSvc.getUser(),

            this.SubSvc.organizationalBoundaries,
        ]).subscribe(([user, organizationBorder]) => {
            if (
                user.region.length > 0 &&
                Object.keys(organizationBorder).length > 0
            ) {
                this.user = user

                this.mdu = organizationBorder[this.user.region][this.user.route]

                this.getForecastDetails()
            }
        })
    }
    /** minimize widget */
    toggleTable() {
        this.minimizeTable = !this.minimizeTable
    }

    /** route to detail forecast page */
    open24HazardDetails() {
        this.route.navigateByUrl('dashboard/forecast')
    }

    /** get forecast detail table data */
    getForecastDetails() {
        this.api
            .singleApiCall(
                API_END_POINTS.getForecast24 +
                    this.user.region +
                    '/' +
                    this.user.route,
                'GET',
            )
            .subscribe((foreInfo: Array<IHazardForecast24Hours>) => {
                this.forecastDetails = foreInfo
                this.getHours()
                this.cacheForeCastDetails = foreInfo
            })
    }

    getHours() {
        this.hours = []
        this.forecastDetails[0].Value.forEach(
            ({ DateTime }: IHazardForecastRagStatus) => {
                const timeParts = DateTime.split(' ')[1].split(':')
                const formattedTime = timeParts[0] + timeParts[1]
                // const formattedTime = `${String(Number(timeParts[0]) * 100 + Number(timeParts[1]))}`.padStart(4, '0');
                this.hours.push(formattedTime)
            },
        )
    }

    /** filter table using filter service */
    filterByParam(selectedList: IDropdownSelectedList) {
        if (selectedList.selectedItems.length === 0) {
            this.forecastDetails = this.cacheForeCastDetails
            return
        }
        if (selectedList.name === 'mdu-hazard-24') {
            this.selecetdFilters.weatherParameter = []
            this.forecastDetails = this.filterSvc.filterTable(
                this.cacheForeCastDetails,
                selectedList.selectedItems,
                'MDUName',
            )
        }
        if (selectedList.name === 'weatherParameter-hazard-24') {
            this.selecetdFilters.mdu = []
            this.forecastDetails = this.filterSvc.filterTable(
                this.cacheForeCastDetails,
                selectedList.selectedItems,
                'WeatherParamName',
            )
        }
    }
}
