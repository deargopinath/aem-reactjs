import { ComponentFixture, TestBed } from '@angular/core/testing'

import { Forecast24HoursComponent } from './forecast24-hours.component'

describe('Forecast24HoursComponent', () => {
    let component: Forecast24HoursComponent
    let fixture: ComponentFixture<Forecast24HoursComponent>

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [Forecast24HoursComponent],
        })
        fixture = TestBed.createComponent(Forecast24HoursComponent)
        component = fixture.componentInstance
        fixture.detectChanges()
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })
})
