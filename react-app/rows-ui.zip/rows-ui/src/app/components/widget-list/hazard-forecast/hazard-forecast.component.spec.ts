import { SubjectService } from '../../../services/subject.service'
import { HazardForecastComponent } from './hazard-forecast.component'
import { Router } from '@angular/router'
import { UserAuthService } from '../../../services/user-auth.service'
import { ApiCallService } from '../../../services/web-serivces/api-call.service'

describe('HazardForecastComponent', () => {
    let component: HazardForecastComponent
    let subjectSvc: SubjectService
    let route: Router
    let api: ApiCallService
    let userSvc: UserAuthService
    beforeEach(() => {
        component = new HazardForecastComponent(route, api, subjectSvc, userSvc)
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })

    it('should toggel the table', () => {
        component.minimizeTable = false
        component.toggleTable()
        expect(component.minimizeTable).toBeTrue()
    })
})
