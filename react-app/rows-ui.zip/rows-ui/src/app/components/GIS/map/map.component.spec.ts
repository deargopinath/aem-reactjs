import { ComponentFixture, TestBed } from '@angular/core/testing'

import { MapComponent } from './map.component'
import { MapService } from 'src/app/services/gis/map.service'
import { ApiCallService } from 'src/app/services/web-serivces/api-call.service'
describe('MapComponent', () => {
    let component: MapComponent
    let fixture: ComponentFixture<MapComponent>
    let mapservice: MapService
    let apicallservice: ApiCallService
    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [MapComponent],
        })
        fixture = TestBed.createComponent(MapComponent)
        component = fixture.componentInstance
        fixture.detectChanges()
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })

    // describe('MapComponent ngAfterViewInit', () => {
    it('should call ngAfterViewInit after ngonit', (done) => {
        expect(component.ngOnInit()).toHaveBeenCalled()
        setTimeout(() => {
            done()
        }, 200)
    })
    // })

    describe('changeWeatherType', () => {
        it('should check the type value', () => {
            component.type = 'forecast'
            component.changeWeatherType()
            expect(component.type).toEqual('observered')
        })

        it('should check the type value', () => {
            component.type = 'observered'
            component.changeWeatherType()
            expect(component.type).toEqual('forecast')
        })

        it('should emit value', () => {
            spyOn(component.selectedType, 'emit')
            expect(component.changeWeatherType()).toHaveBeenCalled()
        })
    })

    describe('showRAG', () => {
        it('should emit value', () => {
            spyOn(component.RAG, 'emit')
            component.isRag = true
            expect(component.showRAG()).toHaveBeenCalled()
        })
    })

    describe('selectedParam', () => {
        it('should emit value', () => {
            spyOn(component.selectedWeatherParameters, 'emit')
            component.capsuleName = 'Fire Risk Index'
            component.isCapsuleSelected = true
            expect(
                component.selectedParam({
                    id: '1',
                    name: 'Real/near-real time rail temperature data (°C)',
                    selectedCapsule: true,
                }),
            ).toHaveBeenCalled()
        })
    })

    it('should toggle color piker icon, on calling changepickerType', () => {
        component.capsuleName = 'Fire Risk Index'
        component.isCapsuleSelected = true

        component.displayColorPicker = true
        component.changepickerType()
        expect(component.displayColorPicker).toBeFalse

        component.displayColorPicker = false
        component.changepickerType()
        expect(component.displayColorPicker).toBeTrue
    })
})
