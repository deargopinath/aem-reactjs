import {
    Component,
    ElementRef,
    OnInit,
    ViewChild,
} from '@angular/core'
import { FilterPanelComponent } from '../filter-panel/filter-panel.component'
import { CommonModule } from '@angular/common'
import { UserAuthService } from 'src/app/services/user-auth.service'
import { IFilters, IUser } from '../../shared/interfaces/interface'
import { API_END_POINTS } from '../../../environments/environment'
import { ApiCallService } from 'src/app/services/web-serivces/api-call.service'
import { NgbModal } from '@ng-bootstrap/ng-bootstrap'
import { SharedModule } from 'src/app/shared/shared.module'
import {
    PROFILE_STATUS_ADD_SUCCESS_MESSAGE,
    PROFILE_STATUS_UPDATE_SUCCESS_MESSAGE,
} from '../../core/properties/application.properties'
import { Router } from '@angular/router'
@Component({
    selector: 'app-user-profile',
    templateUrl: './user-profile.component.html',
    styleUrls: ['./user-profile.component.scss'],
    standalone: true,
    imports: [CommonModule, FilterPanelComponent, SharedModule],
})
export class UserProfileComponent implements OnInit {
    @ViewChild('pModal') pModal!: ElementRef

    user: IUser = {
        id: '',
        name: '',
        username: '',
        email: '',
        region: '',
        route: '',
        mdu: '',
        designation: '',
        firstLogin: false,
    }

    success = false
    fail = false
    firstLogin = false
    constructor(
        private userAuthSvc: UserAuthService,
        private api: ApiCallService,
        private modalService: NgbModal,
        private route: Router,
    ) {}

    ngOnInit(): void {
        this.userAuthSvc.getUser().subscribe((user: IUser) => {
            this.user = user
            if (this.user.firstLogin) {
                this.firstLogin = this.user.firstLogin
            }
        })
    }

    getSelectedRegionRoute(selectedList: IFilters) {
        this.user.region = selectedList.regions[0]
        this.user.route = selectedList.routes[0]
        if (selectedList.action === 'submit') {
            this.modalService.open(this.pModal, {
                centered: true,
                size: 'lg',
                backdrop: 'static',
                keyboard: false,
            })
        }
    }

    updateUserProfile() {
        const userPayLoad = {
            UPNID: this.user.id,
            User_Name: this.user.username,
            Name: this.user.name,
            EmailId: this.user.email,
            Designation: this.user.designation,
            Region_Name: this.user.region,
            Route_Name: this.user.route,
            MDU_Name: '',
            Updated_Date: new Date().toISOString().split('T')[0],
        }
        this.closeModal()
        this.api
            .singleApiCall(API_END_POINTS.setUserDetails, 'POST', userPayLoad)
            .subscribe((response) => {
                if (
                    response === PROFILE_STATUS_ADD_SUCCESS_MESSAGE ||
                    response === PROFILE_STATUS_UPDATE_SUCCESS_MESSAGE
                ) {
                    this.success = true
                    this.fail = false
                    if (this.user.firstLogin) {
                    }
                    this.userAuthSvc.getUserDetails({
                        id: this.user.id,
                        name: this.user.name,
                        username: this.user.username,
                        email: this.user.email,
                        designation: this.user.designation,
                    })
                    setTimeout(() => {
                        this.success = false
                        this.route.navigateByUrl('dashboard')
                    }, 3000)
                } else {
                    this.fail = true
                }
            })
    }

    closeModal() {
        this.modalService.dismissAll()
    }
}
