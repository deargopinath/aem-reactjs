import { ComponentFixture, TestBed } from '@angular/core/testing'

import { WindTableComponent } from './wind-table.component'

describe('WindTableComponent', () => {
    let component: WindTableComponent
    let fixture: ComponentFixture<WindTableComponent>

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [WindTableComponent],
        })
        fixture = TestBed.createComponent(WindTableComponent)
        component = fixture.componentInstance
        fixture.detectChanges()
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })
})
