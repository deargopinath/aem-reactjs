import { CommonModule } from '@angular/common'
import {
    Component,
    EventEmitter,
    Input,
    Output,
    ViewEncapsulation,
} from '@angular/core'
import { MatTooltipModule } from '@angular/material/tooltip'
import {
    IBoundaries,
    IDropdownSelectedList,
    ILegend,
    IValue,
    IFireSteamRisk,
} from 'src/app/shared/interfaces/interface'
import { SharedModule } from 'src/app/shared/shared.module'

@Component({
    selector: 'app-fire-steam-risk',
    templateUrl: './fire-steam-risk.component.html',
    styleUrls: ['./fire-steam-risk.component.scss'],
    encapsulation: ViewEncapsulation.None,
    standalone: true,
    imports: [MatTooltipModule, CommonModule, SharedModule],
})
export class FireSteamRiskComponent {
    @Input() captionTitle = ''
    @Input() legends = new Array<ILegend>()
    @Input() header_date = new Array<IValue>()
    @Input() tablularData = new Array<IFireSteamRisk>()
    @Input() secondaryFilter!: IBoundaries
    @Input() secondarySelectedFilter: IBoundaries = {
        region: [],
        route: [],
        mdu: [],
    }
    @Output() selectedFilters = new EventEmitter<IDropdownSelectedList>()

    /** emit the selected fiilter values */
    filterTable(selectedList: IDropdownSelectedList) {
        this.selectedFilters.emit(selectedList)
    }
}
