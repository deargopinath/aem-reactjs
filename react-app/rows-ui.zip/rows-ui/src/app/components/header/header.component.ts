import { Component, OnInit } from '@angular/core'
import { FormsModule } from '@angular/forms'
import { Router } from '@angular/router'
import { IUser } from '../../shared/interfaces/interface'
import { SharedModule } from '../../shared/shared.module'

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss'],
    standalone: true,
    imports: [FormsModule, SharedModule],
})
export class HeaderComponent implements OnInit {
    searchInput = ''
    showMenu = false
    public user: IUser = {
        id: '',
        name: '',
        username: '',
        email: '',
        region: '',
        route: '',
        mdu: '',
        designation: '',
        firstLogin: false,
    }
    constructor(

        private route: Router,
    ) {}
    ngOnInit(): void {
        this.user = {
            id: 'deargopinath123',
            name: 'Srinivas Gopinath Parimi',
            username: 'deargopinath',
            email: 'deargopinath@gmail.com',
            region: 'Eastern',
            route: 'Anglia',
            mdu: 'Ipswitch MDU',
            designation: 'Enterprise Architect',
            firstLogin: false,
        }
    }
    search() {}

    myProfile() {
        this.route.navigateByUrl('myProfile')
        this.showMenu = false
    }
    logout() {
        console.log("Logging out ...")
    }
}
