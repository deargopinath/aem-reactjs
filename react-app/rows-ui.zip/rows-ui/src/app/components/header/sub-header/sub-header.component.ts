import { Component } from '@angular/core'
import { Observable } from 'rxjs'
import { SubjectService } from 'src/app/services/subject.service'

@Component({
    selector: 'app-sub-header',
    templateUrl: './sub-header.component.html',
    styleUrls: ['./sub-header.component.scss'],
})
export class SubHeaderComponent {
    routePath = new Array<string>()
    date$!: Observable<Date>
    showWidgetContainer = false
    constructor(private subjectSvc: SubjectService) {}
    ngOnInit(): void {
        this.date$ = this.subjectSvc.date
    }
    hideWidgetConxtainer(e: boolean) {
        this.showWidgetContainer = false
    }
}
