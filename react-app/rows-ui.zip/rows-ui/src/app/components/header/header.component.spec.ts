import { HeaderComponent } from './header.component'
import { AuthService } from '../../services/auth.service'
import { UserAuthService } from '../../services/user-auth.service'
import { IUser } from '../../shared/interfaces/interface'
import { SharedModule } from '../../shared/shared.module'
import { Router } from '@angular/router'
describe('FireSteamRiskComponent', () => {
    let component: HeaderComponent
    let authSvc: AuthService
    let userSvc: UserAuthService
    let route: Router
    beforeEach(() => {
        component = new HeaderComponent(authSvc, userSvc, route)
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })

    it('should call search', () => {
        expect(component.search()).toHaveBeenCalled()
    })
})
