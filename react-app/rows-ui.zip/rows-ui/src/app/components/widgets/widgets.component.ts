import { CommonModule } from '@angular/common'
import { Component, EventEmitter, Output } from '@angular/core'
import { WIDGET_LIST } from '../../core/constants/app.constants'
import { SubjectService } from '../../services/subject.service'
import { IWidget } from '../../shared/interfaces/interface'
@Component({
    selector: 'app-widgets',
    templateUrl: './widgets.component.html',
    styleUrls: ['./widgets.component.scss'],
    standalone: true,
    imports: [CommonModule],
})
export class WidgetsComponent {
    widgetList: Array<IWidget> = WIDGET_LIST
    selectedWidget: Array<IWidget> = []
    @Output() removeWidgetContainer = new EventEmitter<boolean>()
    constructor(private subjectSvc: SubjectService) {}

    ngOnInit(): void {
        this.subjectSvc.updateWidget.subscribe((updateValue) => {
            this.selectedWidget = []
        })
    }

    /** opening and closing the widget */
    updateWidget(widget: IWidget) {
        if (!widget.component) return
        if (this.selectedWidget.includes(widget)) {
            this.selectedWidget.splice(this.selectedWidget.indexOf(widget), 1)
        } else {
            this.selectedWidget.push(widget)
        }
        this.subjectSvc.adComponents.next({
            component: widget.component,
            section: widget.section,
        })
        this.removeWidgetContainer.emit(true)
    }
}
