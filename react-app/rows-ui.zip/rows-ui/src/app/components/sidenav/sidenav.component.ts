import { Component } from '@angular/core'
import { Router } from '@angular/router'
import { APP_NAVIGATION } from '../../core/constants/app.constants'
import { CommonModule } from '@angular/common'
import {
    IAppNavigation,
    IPageNavigation,
} from '../../shared/interfaces/interface'
@Component({
    selector: 'app-sidenav',
    templateUrl: './sidenav.component.html',
    styleUrls: ['./sidenav.component.scss'],
    standalone: true,
    imports: [CommonModule],
})
export class SidenavComponent {
    navigationList: Array<IAppNavigation> = APP_NAVIGATION
    selectedNavIcon!: IPageNavigation
    subNavShowIndex = 0
    constructor(private router: Router) {}

    navigateTo(page: IPageNavigation) {
        this.selectedNavIcon = page
        if (page.routeTo) {
            this.router.navigateByUrl(page.routeTo)
        }
    }
}
