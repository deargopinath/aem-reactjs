# rows-gateway 
UI hosting and access control

## Component overview
```
[rows-ui]       [SSO]
    |             |
    +--+       +--+
       |       |
+------+-------+------+
|    rows-gateway     |
+----------+----------+
           |
           |
[Micro services & Data]
```

## Development

### Install dependencies
```
> npm install
```

### Compile and verify locally
```
> npm start
> npm start -- {local | dev | uat}
```

### Code style and formatting
```
> npm run lint
> npm run lint:fix
```

### Testing and Code coverage
```
> npm test
> npm test --code-coverage
```

### Production build
```
> npm run build
```

### Docker container
```
> npm run docker:build
> npm run docker:run
```

### Help
```
> npm start -- {dev | local}
```
Open http://localhost:3000/help
