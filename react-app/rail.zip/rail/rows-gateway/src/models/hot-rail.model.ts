import {Model, model, property} from '@loopback/repository'

@model()
export class HotRail extends Model {
  @property({
    type: 'number',
    required: true,
  })
  MaxAirTemp: number

  @property({
    type: 'number',
    required: true,
  })
  MaxRailTemp: number

  @property({
    type: 'number',
    required: true,
  })
  PeriodAbove46C: number

  @property({
    type: 'string',
    required: true,
  })
  RegionName: string

  @property({
    type: 'string',
    required: true,
  })
  RouteName: string

  @property({
    type: 'string',
    required: true,
  })
  MDUName: string

  @property({
    type: 'string',
    required: true,
  })
  DateTime: string

  @property({
    type: 'string',
    required: true,
  })
  TimeofMaxRailTemp: string

  @property({
    type: 'string',
    required: true,
  })
  Date: string

  @property({
    type: 'string',
    required: true,
  })
  DayOfWeek: string

  constructor(data?: Partial<HotRail>) {
    super(data)
  }
}

export interface HotRailRelations {
  // describe navigational properties here
}

export type HotRailWithRelations = HotRail & HotRailRelations
