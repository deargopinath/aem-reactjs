import {Model, model, property} from '@loopback/repository'

@model()
export class MaintenanceUnit extends Model {
  @property({
    type: 'string',
    required: true,
  })
  RegionName: string

  @property({
    type: 'string',
    required: true,
  })
  RouteName: string

  @property({
    type: 'string',
    required: true,
  })
  MDUName: string

  constructor(data?: Partial<MaintenanceUnit>) {
    super(data)
  }
}

export interface MaintenanceUnitRelations {
  // describe navigational properties here
}

export type MaintenanceUnitWithRelations = MaintenanceUnit & MaintenanceUnitRelations
