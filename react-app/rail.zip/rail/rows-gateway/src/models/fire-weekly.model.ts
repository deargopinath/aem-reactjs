import {Model, model, property} from '@loopback/repository'

@model()
export class FireWeekly extends Model {
  @property({
    type: 'string',
    required: true,
  })
  RegionName: string

  @property({
    type: 'string',
    required: true,
  })
  RouteName: string

  @property({
    type: 'string',
    required: true,
  })
  MDUName: string

  @property({
    type: 'string',
    required: true,
  })
  WeatherParamName: string

  @property({
    type: 'array',
    itemType: 'object',
    required: true,
  })
  Value: object[]

  constructor(data?: Partial<FireWeekly>) {
    super(data)
  }
}

export interface FireWeeklyRelations {
  // describe navigational properties here
}

export type FireWeeklyWithRelations = FireWeekly & FireWeeklyRelations
