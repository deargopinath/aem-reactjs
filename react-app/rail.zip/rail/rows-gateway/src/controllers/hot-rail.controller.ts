import {get, getModelSchemaRef, param, response} from '@loopback/rest'
import {Config} from '../config'
import {HotRailService} from '../services'
import {inject} from '@loopback/core'
import {HotRail} from '../models'

const hotRailSchema = {
  description: 'Hot Rail forecast',
  content: {
    'application/json': {
      schema: {
        type: 'array',
        items: getModelSchemaRef(HotRail),
      },
    },
  },
}

export class HotRailController {
  constructor(
    @inject('services.HotRailService')
    protected restApi: HotRailService,
  ) {}
  @get('/api/hotRail')
  @response(200, hotRailSchema)
  async getAllData(): Promise<HotRail[]> {
    return this.restApi.get(Config.hotrailApi)
  }

  @get('/api/hotRail/{region}')
  @response(200, hotRailSchema)
  async getRegionData(
    @param.path.string('region') region: string,
  ): Promise<HotRail[]> {
    return this.restApi.get(Config.hotrailApi + '?RegionName=' + region)
  }

  @get('/api/hotRail/{region}/{route}')
  @response(200, hotRailSchema)
  async getRouteData(
    @param.path.string('region') region: string,
    @param.path.string('route') route: string,
  ): Promise<HotRail[]> {
    return this.restApi.get(
      Config.hotrailApi + '?RegionName=' + region + '&RouteName=' + route,
    )
  }

  @get('/api/hotRail/{region}/{route}/{mdu}')
  @response(200, hotRailSchema)
  async getMduData(
    @param.path.string('region') region: string,
    @param.path.string('route') route: string,
    @param.path.string('mdu') mdu: string,
  ): Promise<HotRail[]> {
    return this.restApi.get(
      Config.hotrailApi +
        '?RegionName=' +
        region +
        '&RouteName=' +
        route +
        '&MDUName=' +
        mdu,
    )
  }
}
