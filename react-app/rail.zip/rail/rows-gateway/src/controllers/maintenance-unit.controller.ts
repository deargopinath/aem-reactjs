import {get, getModelSchemaRef, param, response} from '@loopback/rest'
import {Config} from '../config'
import {MaintenanceUnitService} from '../services'
import {inject} from '@loopback/core'
import {MaintenanceUnit} from '../models'

const mduSchema = {
  description: 'Maintenance Delivery Units (MDUs)',
  content: {
    'application/json': {
      schema: {
        type: 'array',
        items: getModelSchemaRef(MaintenanceUnit),
      },
    },
  },
}

export class MaintenanceUnitController {
  constructor(
    @inject('services.MaintenanceUnitService')
    protected restApi: MaintenanceUnitService,
  ) {}
  @get('/api/mdus')
  @response(200, mduSchema)
  async getAllData(): Promise<MaintenanceUnit[]> {
    return this.restApi.get(Config.mduApi)
  }

  @get('/api/mdus/{region}')
  @response(200, mduSchema)
  async getRegionData(
    @param.path.string('region') region: string,
  ): Promise<MaintenanceUnit[]> {
    return this.restApi.get(Config.mduApi + '?RegionName=' + region)
  }

  @get('/api/mdus/{region}/{route}')
  @response(200, mduSchema)
  async getRouteData(
    @param.path.string('region') region: string,
    @param.path.string('route') route: string,
  ): Promise<MaintenanceUnit[]> {
    return this.restApi.get(
      Config.mduApi + '?RegionName=' + region + '&RouteName=' + route,
    )
  }

}
