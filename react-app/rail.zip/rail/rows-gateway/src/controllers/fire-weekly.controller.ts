import {get, getModelSchemaRef, param, response} from '@loopback/rest'
import {Config} from '../config'
import {FireWeeklyService} from '../services'
import {inject} from '@loopback/core'
import {FireWeekly} from '../models'

const fireSchema = {
  description: '7 day fire forecast',
  content: {
    'application/json': {
      schema: {
        type: 'array',
        items: getModelSchemaRef(FireWeekly),
      },
    },
  },
}

export class FireWeeklyController {
  constructor(
    @inject('services.FireWeeklyService')
    protected restApi: FireWeeklyService,
  ) {}
  @get('/api/fireRiskIndex')
  @response(200, fireSchema)
  async getAllData(): Promise<FireWeekly[]> {
    return this.restApi.get(Config.fireApi)
  }

  @get('/api/fireRiskIndex/{region}')
  @response(200, fireSchema)
  async getRegionData(
    @param.path.string('region') region: string,
  ): Promise<FireWeekly[]> {
    return this.restApi.get(Config.fireApi + '?RegionName=' + region)
  }

  @get('/api/fireRiskIndex/{region}/{route}')
  @response(200, fireSchema)
  async getRouteData(
    @param.path.string('region') region: string,
    @param.path.string('route') route: string,
  ): Promise<FireWeekly[]> {
    return this.restApi.get(
      Config.fireApi + '?RegionName=' + region + '&RouteName=' + route,
    )
  }

  @get('/api/fireRiskIndex/{region}/{route}/{mdu}')
  @response(200, fireSchema)
  async getMduData(
    @param.path.string('region') region: string,
    @param.path.string('route') route: string,
    @param.path.string('mdu') mdu: string,
  ): Promise<FireWeekly[]> {
    return this.restApi.get(
      Config.fireApi +
        '?RegionName=' +
        region +
        '&RouteName=' +
        route +
        '&MDUName=' +
        mdu,
    )
  }
}
