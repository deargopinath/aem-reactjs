import {get, getModelSchemaRef, param, response} from '@loopback/rest'
import {Config} from '../config'
import {SteamWeeklyService} from '../services'
import {inject} from '@loopback/core'
import {SteamWeekly} from '../models'

const steamSchema = {
  description: '7 day steam forecast',
  content: {
    'application/json': {
      schema: {
        type: 'array',
        items: getModelSchemaRef(SteamWeekly),
      },
    },
  },
}

export class SteamWeeklyController {
  constructor(
    @inject('services.SteamWeeklyService')
    protected restApi: SteamWeeklyService,
  ) {}
  @get('/api/steamRiskIndex')
  @response(200, steamSchema)
  async getAllData(): Promise<SteamWeekly[]> {
    return this.restApi.get(Config.steamApi)
  }

  @get('/api/steamRiskIndex/{region}')
  @response(200, steamSchema)
  async getRegionData(
    @param.path.string('region') region: string,
  ): Promise<SteamWeekly[]> {
    return this.restApi.get(Config.steamApi + '?RegionName=' + region)
  }

  @get('/api/steamRiskIndex/{region}/{route}')
  @response(200, steamSchema)
  async getRouteData(
    @param.path.string('region') region: string,
    @param.path.string('route') route: string,
  ): Promise<SteamWeekly[]> {
    return this.restApi.get(
      Config.steamApi + '?RegionName=' + region + '&RouteName=' + route,
    )
  }

  @get('/api/steamRiskIndex/{region}/{route}/{mdu}')
  @response(200, steamSchema)
  async getMduData(
    @param.path.string('region') region: string,
    @param.path.string('route') route: string,
    @param.path.string('mdu') mdu: string,
  ): Promise<SteamWeekly[]> {
    return this.restApi.get(
      Config.steamApi +
        '?RegionName=' +
        region +
        '&RouteName=' +
        route +
        '&MDUName=' +
        mdu,
    )
  }
}
