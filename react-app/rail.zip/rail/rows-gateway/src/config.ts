export class Config {
  public static port = 3000
  public static help = false
  public static fireApi =
    'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/fireRiskIndex'
  public static steamApi =
    'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/steamRiskIndex'
  public static hotrailApi =
    'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/hotRunningRail'
  public static mduApi =
    'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/organizationalBoundryAssoc'

  public static setEnv(env: string): void {
    switch (env) {
      case 'local':
        Config.fireApi = 'http://127.0.0.1:8000/api/fireRiskIndex'
        Config.steamApi = 'http://127.0.0.1:8000/api/steamRiskIndex'
        Config.hotrailApi = 'http://127.0.0.1:8000/api/hotRunningRail'
        Config.mduApi = 'http://127.0.0.1:8000/api/organizationalBoundryAssoc'
        Config.help = true
        break
      case 'dev':
        Config.fireApi =
          'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/fireRiskIndex'
        Config.steamApi =
          'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/steamRiskIndex'
        Config.hotrailApi =
          'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/hotRunningRail'
        Config.help = true
        break
      case 'uat':
        console.log('UAT environment')
        break
      default:
        console.log('Production environment')
        break
    }
  }
}
