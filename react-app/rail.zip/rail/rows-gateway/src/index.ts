import {ApplicationConfig, RowsGatewayApplication} from './application'
import {Config} from './config'
export * from './application'

export async function main(options: ApplicationConfig = {}) {
  const app = new RowsGatewayApplication(options)
  await app.boot()
  await app.start()
  console.log('Gateway Service started at ' + app.restServer.url)
  return app
}

// Set App config
if (process.argv.length > 2 && process.argv[2] != null) {
  Config.setEnv(process.argv[2].trim().toLowerCase())
}

if (require.main === module) {
  // Run the application
  const config = {
    rest: {
      port: Config.port,
      gracePeriodForClose: 5000, // 5 seconds
    },
  }
  main(config).catch(err => {
    console.error('Cannot start the application.', err)
    process.exit(1)
  })
}
