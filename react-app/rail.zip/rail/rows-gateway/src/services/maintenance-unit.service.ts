import {injectable, BindingScope} from '@loopback/core'
import axios from 'axios'
import {MaintenanceUnit} from '../models'

@injectable({scope: BindingScope.TRANSIENT})
export class MaintenanceUnitService {
  options = {}
  constructor() {
    this.options = {
      headers: {
        accept: 'application/json',
        'content-type': 'application/json',
      },
    }
  }

  public async get(url: string): Promise<MaintenanceUnit[]> {
    try {
      const apiResponse = await axios.get(url, this.options)
      return apiResponse.data
    } catch (error) {
      return []
    }
  }
}
