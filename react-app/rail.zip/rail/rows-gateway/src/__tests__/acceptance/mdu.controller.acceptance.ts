import {Client} from '@loopback/testlab'
import {RowsGatewayApplication} from '../..'
import {setupApplication} from './test-helper'

describe('MduController', () => {
  let app: RowsGatewayApplication
  let client: Client

  before('setupApplication', async () => {
    ;({app, client} = await setupApplication())
  })

  after(async () => {
    await app.stop()
  })

  it('invokes GET /mdus', async () => {
    const res = await client.get('/mdus').expect(200)
    console.log(res)
  })
})
