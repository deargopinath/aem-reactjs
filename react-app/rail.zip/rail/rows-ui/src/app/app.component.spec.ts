import { AppComponent } from './app.component'
import { AuthService } from './services/auth.service'

describe('AppComponent', () => {
    let component: AppComponent
    let authSvc: AuthService
    beforeEach(() => {
        component = new AppComponent(authSvc)
    })

    it('should create the compoent', () => {
        expect(component).toBeTruthy()
    })

    it('should call ngOnint', () => {
        expect(component.ngOnInit()).toBeUndefined()
    })

    it('should call ondestroy', () => {
        expect(component.ngOnDestroy()).toBeUndefined()
    })
})
