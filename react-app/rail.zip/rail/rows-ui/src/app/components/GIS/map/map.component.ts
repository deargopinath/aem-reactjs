import {
    Component,
    AfterViewInit,
    OnInit,
    Input,
    EventEmitter,
    Output,
} from '@angular/core'
import { CommonModule } from '@angular/common'
import { MapService } from 'src/app/services/gis/map.service'
import { ApiCallService } from 'src/app/services/web-serivces/api-call.service'
//import { API_END_POINTS } from 'src/app/core/configuration/api-endpoints'
import { API_END_POINTS } from '../../../../environments/environment'
import { SubjectService } from 'src/app/services/subject.service'
import { Observable } from 'rxjs'
import { WeatherParametersComponent } from '../weather-parameters/weather-parameters.component'
import { ColorPickerComponent } from '../../color-picker/color-picker.component'
import { combineLatest } from 'rxjs'
import { UserAuthService } from '../../../services/user-auth.service'
import { IUser } from '../../../shared/interfaces/interface'
@Component({
    selector: 'app-map',
    templateUrl: './map.component.html',
    styleUrls: ['./map.component.scss'],
    standalone: true,
    imports: [CommonModule, WeatherParametersComponent, ColorPickerComponent],
})
export class MapComponent implements AfterViewInit, OnInit {
    @Input() feature: any
    @Input() component: any
    @Output() selectedType = new EventEmitter<string>()
    @Output() RAG = new EventEmitter<string>()
    @Output() selectedWeatherParameters = new EventEmitter<{
        id: string
        name: string
    }>()

    map_Id = ''
    isLocate = false
    locateParameters: any
    date$!: Observable<Date>
    type = 'forecast'
    isRag = false
    displayColorPicker = false
    capsuleName = ''
    isCapsuleSelected = false
    disableRagButton = false
    boundries: any = {}
    user!: IUser
    regions: string[] = []
    routes: string[] = []
    RoutesData: any
    constructor(
        private mapService: MapService,
        private apiCall: ApiCallService,
        private subjectService: SubjectService,
        private userAuth: UserAuthService,
    ) {}

    ngOnInit() {
        const mapNumber = this.mapService.mapIds.length + 1
        this.map_Id = 'map' + mapNumber
        this.mapService.mapIds.push(this.map_Id)
        this.date$ = this.subjectService.date
    }

    ngAfterViewInit(): void {
        //Initialize map here
        this.mapService.updateSize('hrr', this.map_Id)
        this.getZoomToFeatures()
        if (this.component == 'hotRunningRail') {
            this.disableRagButton = true
        }
        this.getRouteFeature()
        this.init()
    }

    hideLocationBlock() {
        setTimeout(() => {
            if (this.isLocate) this.isLocate = !this.isLocate
        }, 100)
    }
    showLocationTool() {
        this.isLocate = !this.isLocate
        this.mapService.clearHighlight()
    }
    showLocationSelection(locParam: any) {
        //console.log('I am in click event of zoom feature')
        this.mapService.showLocation(locParam)
    }
    getZoomToFeatures() {
        this.apiCall
            .singleApiCall(
                API_END_POINTS.gisMicroservices + API_END_POINTS.zoomToFeatures,
                'GET',
            )
            .subscribe((response) => {
                console.log('Zoom To Features')
                console.log(response)
                let n = {
                    f_code: null,
                    f_name: 'National',
                    oid: '6415.000000000000000',
                    s_order: 1,
                    t_name: 'National',
                }
                this.locateParameters = new Array()
                this.locateParameters.push(n)
                for (let i = 0; i < response.length; i++) {
                    this.locateParameters.push(response[i])
                }
            })
    }

    changeWeatherType() {
        if (this.type === 'forecast') {
            this.type = 'observered'
        } else {
            this.type = 'forecast'
        }
        this.selectedType.emit(this.type)
    }

    showRAG() {
        this.isRag = !this.isRag
        this.RAG.emit(this.component)
    }

    selectedParam(selectedParam: any) {
        this.isRag = false
        this.capsuleName = selectedParam.name
        this.isCapsuleSelected = selectedParam.selectedCapsule
        if (this.component == 'hotRunningRail') {
            if (
                this.capsuleName === 'Max rail temperature (°C)' ||
                this.capsuleName === 'Max air temperature (°C)'
            ) {
                this.disableRagButton = false
            } else {
                this.disableRagButton = true
            }
        }

        if (this.capsuleName !== '' && this.isCapsuleSelected) {
            this.displayColorPicker = true
        } else {
            this.displayColorPicker = false
        }
        this.selectedWeatherParameters.emit(selectedParam)
    }

    changepickerType() {
        if (this.capsuleName !== '' && this.isCapsuleSelected) {
            this.displayColorPicker = !this.displayColorPicker
        }
    }

    getRouteFeature() {
        this.apiCall
            .singleApiCall(
                API_END_POINTS.geoServer +
                    'NRGISP/wms?service=WFS&version=1.1.0&request=GetFeature&typename=NRGISP%3ARoute&outputFormat=application/json',
                'GET',
            )
            .subscribe((response) => {
                console.log('Zoom To Features')
                console.log(response)
                this.RoutesData = response
            })
    }

    private init() {
        const subs = combineLatest([
            this.userAuth.getUser(),
            this.subjectService.organizationalBoundaries,
        ]).subscribe(([user, boundries]) => {
            if (user.region.length > 0 && Object.keys(boundries).length > 0) {
                this.boundries = boundries
                this.user = user
                this.regions = Object.keys(boundries)
                setTimeout(() => {
                    // alert("Hello")
                    this.mapService.navigateRoute(
                        this.user.route,
                        this.RoutesData,
                    )
                }, 1000)
                subs.unsubscribe()
            }
        })
    }
}
