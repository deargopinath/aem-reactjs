import { CommonModule } from '@angular/common'
import {
    Component,
    EventEmitter,
    Input,
    Output,
    OnChanges,
    SimpleChanges,
} from '@angular/core'
import { SubjectService } from '../../../services/subject.service'

@Component({
    selector: 'app-weather-parameters',
    templateUrl: './weather-parameters.component.html',
    styleUrls: ['./weather-parameters.component.scss'],
    standalone: true,
    imports: [CommonModule],
})
export class WeatherParametersComponent implements OnChanges {
    @Input() feature: any
    @Input() component: any
    @Input() type = 'forecast'
    @Output() selectedParam = new EventEmitter<{
        id: string
        name: string
        selectedCapsule: boolean
        p_details: any
    }>()
    weatherList: any
    parameterName = ''
    subParamName = ''
    selectedCapsule = false
    paramName = ''
    constructor(private subjectService: SubjectService) {}
    ngOnChanges(changes: SimpleChanges): void {
        if (this.type === 'forecast') {
            this.parameterName = ''
            this.subParamName = ''
        } else {
            this.parameterName = ''
            this.subParamName = ''
        }
    }

    openSubParameters(param: string, index: number) {
        this.paramName = param
        this.subjectService.parameterName.next(param)
        if (this.parameterName === param) {
            this.parameterName = ''
            this.selectedCapsule = false
        } else {
            this.parameterName = param
            this.selectedCapsule = true
        }

        if (
            this.component === 'hotRunningRail' ||
            this.component === 'fireRisk'
        ) {
            let para_details: any
            for (let i = 0; i < this.feature.length; i++) {
                if (this.feature[i].weatherName == param) {
                    para_details = this.feature[i]
                }
            }
            this.selectedParam.emit({
                id: '' + index,
                name: param,
                selectedCapsule: this.selectedCapsule,
                p_details: para_details,
            })
        }
    }

    selectSubParam(subParam: string, index: number) {
        this.subjectService.subParameterName.next(subParam)
        if (this.subParamName === subParam) {
            this.subParamName = ''
            this.selectedCapsule = false
        } else {
            this.subParamName = subParam
            this.selectedCapsule = true
        }

        this.subjectService.isCapsuleSelected.next(this.selectedCapsule)
    }
}
