import { WeatherParametersComponent } from './weather-parameters.component'
import { SubjectService } from '../../../services/subject.service'
describe('FireSteamRiskComponent', () => {
    let component: WeatherParametersComponent
    let subjectService: SubjectService
    beforeEach(() => {
        component = new WeatherParametersComponent(subjectService)
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })

    it('should emit the selected filter', () => {
        spyOn(component.selectedParam, 'emit')
        const param = 'Real/near-real time rail temperature data (\u00B0C)'
        const index = 1
        component.openSubParameters(param, index)
        expect(component.openSubParameters).toHaveBeenCalled()
    })

    describe('openSubParameters', () => {
        it('should check parameterName value', () => {
            const param = 'Real/near-real time rail temperature data (\u00B0C)'
            const index = 1
            component.openSubParameters(param, index)
            expect(component.parameterName).toEqual(param)
        })

        it('should check parameterName value', () => {
            const param = 'Real/near-real time rail temperature data (\u00B0C)'
            const index = 1
            component.openSubParameters(param, index)
            expect(component.parameterName).toEqual('')
        })
    })

    describe('selectSubParam', () => {
        it('should check subParamName value', () => {
            const param = 'Precipitation'
            const index = 1
            component.openSubParameters(param, index)
            expect(component.parameterName).toEqual(param)
        })

        it('should check parameterName value', () => {
            const param = 'Precipitation'
            const index = 1
            component.openSubParameters(param, index)
            expect(component.parameterName).toEqual('')
        })
    })
})
