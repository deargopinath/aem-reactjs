import { FireSteamRiskComponent } from './fire-steam-risk.component'

describe('FireSteamRiskComponent', () => {
    let component: FireSteamRiskComponent

    beforeEach(() => {
        component = new FireSteamRiskComponent()
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })

    it('should emit the selected filter', () => {
        spyOn(component.selectedFilters, 'emit')
        component.filterTable({ name: 'region', selectedItems: ['region1'] })
        expect(component.selectedFilters).toHaveBeenCalled()
    })
})
