import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core'
import { CommonModule } from '@angular/common'
import { MatTooltipModule } from '@angular/material/tooltip'

import { SharedModule } from 'src/app/shared/shared.module'
import {
    IDropdownSelectedList,
    IUser,
} from 'src/app/shared/interfaces/interface'
import { SubjectService } from 'src/app/services/subject.service'
import { UserAuthService } from 'src/app/services/user-auth.service'
import { combineLatest } from 'rxjs'
import { FilterService } from 'src/app/services/filter.service'

@Component({
    selector: 'app-wind-table',
    standalone: true,
    imports: [CommonModule, MatTooltipModule, SharedModule],
    templateUrl: './wind-table.component.html',
    styleUrls: ['./wind-table.component.scss'],
})
export class WindTableComponent implements OnInit {
    @Output() closeTable = new EventEmitter<boolean>()
    @Output() selectedFilters = new EventEmitter<IDropdownSelectedList>()

    @Input() tableData: any
    @Input() tableTitle = ''
    @Input() tableHeaders: string[] = []
    @Input() details = ''
    @Input() selectedRoutes: string[] = []
    @Input() selectedRegions: string[] = []
    @Input() selectedMdu: string[] = []
    @Input() cachefilter: any
    @Input() transformedData: any

    user!: IUser
    boundries: any = {}
    regions: string[] = []
    routes: string[] = []
    mdu: string[] = []
    showTable = true
    userRegion = ''
    userRoute = ''
    showTooltip = false

    constructor(
        private subjectSvc: SubjectService,
        private userAuth: UserAuthService,
        private filterService: FilterService,
    ) {}

    ngOnInit(): void {
        combineLatest([
            this.userAuth.getUser(),
            this.subjectSvc.organizationalBoundaries,
        ]).subscribe(([user, boundries]) => {
            if (user.region.length > 0 && Object.keys(boundries).length > 0) {
                this.boundries = boundries
                this.user = user
                this.regions = Object.keys(boundries)
                this.setInitialsValue()
            }
        })
    }

    private setInitialsValue() {
        this.selectedRegions = [this.user.region]
        this.selectedRoutes = [this.user.route]
        this.routes = this.filterRoutes(this.selectedRegions)
        this.mdu = this.filterMdus()
    }

    selectedCheckedList(selectedList: IDropdownSelectedList) {
        this.mdu = this.filterMdus()
        if (selectedList.selectedItems.length === 0) {
            this.tableData = this.cachefilter
            return
        }
        if (selectedList.name === 'region') {
            this.selectedRegions = [...selectedList.selectedItems]
            this.tableData = this.filterService.filterTable(
                this.cachefilter,
                this.selectedRegions,
                'RegionName',
            )
            this.routes = this.filterRoutes(this.selectedRegions)
        }
        if (selectedList.name === 'route') {
            this.selectedRoutes = [...selectedList.selectedItems]
            this.tableData = this.filterService.filterTable(
                this.cachefilter,
                this.selectedRoutes,
                'RouteName',
            )
        }
        if (selectedList.name === 'mdu') {
            this.selectedMdu = [...selectedList.selectedItems]
            this.tableData = this.filterService.filterTable(
                this.cachefilter,
                this.selectedMdu,
                'MDUName',
            )
        }
    }

    hideTable(): void {
        this.showTable = false
        this.closeTable.emit(false)
    }

    private filterRoutes(selectedRegions: string[]) {
        return selectedRegions.reduce(
            (routesCollection: Array<string>, region: string) => {
                routesCollection.push(...Object.keys(this.boundries[region]))
                return routesCollection
            },
            [],
        )
    }

    private filterMdus() {
        const allRoutesObj: any = Object.values(this.boundries).reduce(
            (allRoutes: any, routeCollection: any) => ({
                ...allRoutes,
                ...routeCollection,
            }),
            {},
        )
        const filteredMdus: Array<string> = []

        this.selectedRoutes.forEach((route) =>
            filteredMdus.push(...allRoutesObj[route].sort()),
        )
        return filteredMdus
    }
}
