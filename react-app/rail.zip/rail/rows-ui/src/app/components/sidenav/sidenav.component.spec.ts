import { ComponentFixture } from '@angular/core/testing'
import { SidenavComponent } from './sidenav.component'
import { Router } from '@angular/router'
import { IPageNavigation } from '../../shared/interfaces/interface'

describe('SidenavComponent', () => {
    let component: SidenavComponent
    let router: Router
    beforeEach(() => {
        component = new SidenavComponent(router)
    })

    describe('SidenavComponent', () => {
        it('should create', () => {
            expect(component).toBeTruthy()
        })
    })

    describe('navigation function', () => {
        it('navigate to hot-running-rail page', () => {
            const navigationObj: IPageNavigation = {
                name: 'Hot running rail',
                path: 'hot-running-rail',
                routeTo: 'products/hot-running-rail',
            }
            component.navigateTo(navigationObj)
            expect(component.selectedNavIcon).toEqual(navigationObj)
        })
    })
})
