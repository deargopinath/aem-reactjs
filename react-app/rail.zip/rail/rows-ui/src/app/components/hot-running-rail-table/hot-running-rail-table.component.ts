import { ChangeDetectionStrategy, Component, Input } from '@angular/core'

type RailTableType = {
    RouteName: string
    MDUName: string
    DayOfWeek: string
    MaxAirTemp: number
    MaxRailTemp: number
    TimeofMaxRailTemp: number
    PeriodAbove46C: number
}

type LegendType = {
    color: string
    name: string
}

@Component({
    selector: 'app-hot-running-rail-table',
    templateUrl: './hot-running-rail-table.component.html',
    styleUrls: ['./hot-running-rail-table.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HotRunningRailTableComponent {
    @Input() tableData = new Array<RailTableType[]>()
    @Input() hrr_legends = new Array<LegendType>()
}
