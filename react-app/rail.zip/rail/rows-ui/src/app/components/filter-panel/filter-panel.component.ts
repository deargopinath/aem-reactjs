import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core'
import { CommonModule } from '@angular/common'

import { combineLatest } from 'rxjs'

import { SharedModule } from '../../shared/shared.module'
import {
    IDropdownSelectedList,
    IFilters,
    IUser,
} from '../../shared/interfaces/interface'
import { SubjectService } from '../../services/subject.service'
import { UserAuthService } from '../../services/user-auth.service'
@Component({
    selector: 'app-filter-panel',
    templateUrl: './filter-panel.component.html',
    styleUrls: ['./filter-panel.component.scss'],
    standalone: true,
    imports: [SharedModule, CommonModule],
})
export class FilterPanelComponent implements OnInit {
    @Input() name = ''
    @Input() selectedRoutes: string[] = []
    @Input() isMultiple = true
    @Input() selectedRegions: string[] = []
    @Input() weatherParameterNeeded = false
    @Output() selectedFilterCollection = new EventEmitter<IFilters>()
    boundries: any = {}
    user!: IUser
    regions: string[] = []
    routes: string[] = []
    openRegion = false
    openRoute = false
    isError_region = false
    isError_route = false
    n = 0
    weatherList = []

    constructor(
        private subjectService: SubjectService,
        private userAuth: UserAuthService,
    ) {}

    ngOnInit(): void {
        this.init()
    }

    /* collecting filtred selected values and updating dependent filtered dropdown values */
    selectedCheckedList(selectedList: IDropdownSelectedList) {
        if (selectedList.name === 'region') {
            this.selectedRegions = [...selectedList.selectedItems]
            this.routes = this.filterRoutes(this.selectedRegions)
            this.checkForSelectedRouteOverflow()
            if (!this.isMultiple) this.selectedRoutes = []
        }
        if (selectedList.name === 'route') {
            this.selectedRoutes = [...selectedList.selectedItems]
        }
    }

    /* triggering all filtered selection from selection panel for api call */
    selectedFilters(action = 'submit') {
        this.checkForErrors()
        if(this.name === 'userProfile'){
            if (this.selectedRegions.length > 0 && this.selectedRoutes.length > 0) {
                const selectedFilters: IFilters = {
                    name: this.name,
                    action: action,
                    regions: this.selectedRegions,
                    routes: this.selectedRoutes,
                    mdus:
                        this.selectedRegions.length > 0 &&
                        this.selectedRoutes.length > 0
                            ? this.filterMdus()
                            : [],
                }
                this.selectedFilterCollection.emit(selectedFilters)
                } 
        }
         else{
            const selectedFilters: IFilters = {
                name: this.name,
                action: action,
                regions: this.selectedRegions,
                routes: this.selectedRoutes,
                mdus:
                    this.selectedRegions.length > 0 &&
                    this.selectedRoutes.length > 0
                        ? this.filterMdus()
                        : [],
            }
            this.selectedFilterCollection.emit(selectedFilters)
        }
    }

    /* reseting the filters to its inital state*/
    resetToInitials() {
        if (this.user && this.user.region) {
            this.setInitialsValue()
        } else {
            this.selectedRegions = []
            this.selectedRoutes = []
        }
        this.selectedFilters('reset')
    }

    /* checking in selected values are greater to the original filter dropdown values */
    checkForSelectedRouteOverflow() {
        if (this.selectedRoutes.length > this.routes.length) {
            this.selectedRoutes = [...this.routes]
        }
    }

    /*checking for no dropdown selection*/
    checkForErrors() {
        if (this.selectedRegions.length > 0) this.isError_region = false
        else this.isError_region = true

        if (this.selectedRoutes.length > 0) this.isError_route = false
        else this.isError_route = true
    }

    setRoute(selectedRegions: string[]) {
        this.routes = this.filterRoutes(selectedRegions)
    }

    /*initializing the boundries and user values*/
    private init() {
        this.subjectService.organizationalBoundaries.subscribe((boundries) => {
            this.boundries = boundries

            this.regions = Object.keys(boundries)
        })
        combineLatest([
            this.userAuth.getUser(),
            this.subjectService.organizationalBoundaries,
        ]).subscribe(([user, boundries]) => {
            // if (user.region.length > 0 && Object.keys(boundries).length > 0) {
            this.boundries = boundries

            this.regions = Object.keys(boundries)

            if (user.region) {
                this.user = user
                this.setInitialsValue()

                if (this.name !== 'userProfile') {
                    this.selectedFilters()
                }
            }

            // subs.unsubscribe()
            // }
        })
    }

    /* filtering the routes based on selection regions */
    private filterRoutes(selectedRegions: string[]) {
        return selectedRegions.reduce(
            (routesCollection: Array<string>, region: string) => {
                routesCollection.push(...Object.keys(this.boundries[region]))
                return routesCollection
            },
            [],
        )
    }
    /* filtering the MUDs based on selection regions and routes */
    private filterMdus() {
        const allRoutesObj: any = Object.values(this.boundries).reduce(
            (allRoutes: any, routeCollection: any) => ({
                ...allRoutes,
                ...routeCollection,
            }),
            {},
        )
        const filteredMdus: Array<string> = []

        this.selectedRoutes.forEach((route) =>
            filteredMdus.push(...allRoutesObj[route].sort()),
        )
        return filteredMdus
    }

    /* initializing initial state as per the user information */
    private setInitialsValue() {
        this.selectedRegions = [this.user.region]
        this.selectedRoutes = [this.user.route]
        this.routes = this.filterRoutes(this.selectedRegions)
    }
}
