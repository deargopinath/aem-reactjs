import { FilterPanelComponent } from './filter-panel.component'
import { UserAuthService } from '../../services/user-auth.service'
import { SubjectService } from '../../services/subject.service'
import { IFilters } from '../../shared/interfaces/interface'

describe('FilterPanelComponent', () => {
    let component: FilterPanelComponent
    let user: UserAuthService
    let subjectSvc: SubjectService

    beforeEach(() => {
        component = new FilterPanelComponent(subjectSvc, user)
        component.regions = ['region1', 'region2']
        component.boundries = {
            region1: {
                route1: ['mdu1', 'mdu2'],
                route2: ['mdu3', 'mdu4'],
            },
            region2: {
                route3: ['mdu5', 'mdu6'],
                route4: ['mdu7', 'mdu8'],
            },
        }
        component.user = {
            region: 'region1',
            route: 'route1',
            mdu: 'mdu1',
            id: '',
            name: '',
            username: '',
            email: '',
            designation: '',
            firstLogin: false,
        }
        component.name = 'filter1'
    })

    describe('selectedCheckedList', () => {
        const selectedList = {
            name: 'region',
            selectedItems: ['region2'],
        }
        it('should select the correct region', () => {
            component.selectedCheckedList(selectedList)
            expect(component.selectedRegions).toEqual(['region2'])
            expect(component.routes).toEqual(['route3', 'route4'])
        })

        it('should select the correct route', () => {
            const selectedList = {
                name: 'route',
                selectedItems: ['route2'],
            }
            component.selectedCheckedList(selectedList)
            expect(component.selectedRoutes).toEqual(['route2'])
        })
    })

    describe('checkForErrors for empty selectedRegion and selected ROutes', () => {
        beforeEach(() => {
            component.selectedRegions = []
            component.selectedRoutes = []
        })
        it('should check for errors', () => {
            component.checkForErrors()
            expect(component.isError_region).toBeTrue()
            expect(component.isError_route).toBeTrue()
        })
    })

    describe('checkForErrors for selectedRegion and selected ROutes', () => {
        beforeEach(() => {
            component.selectedRegions = []
            component.selectedRoutes = []
        })
        it('should change variabel to true', () => {
            component.checkForErrors()
            expect(component.isError_region).toBeTrue()
            expect(component.isError_route).toBeTrue()
        })
    })

    describe('checkForErrors for selectedRegion and selected ROutes', () => {
        beforeEach(() => {
            component.selectedRegions = ['region']
            component.selectedRoutes = ['routes']
        })
        it('should change variabel to true', () => {
            component.checkForErrors()
            expect(component.isError_region).toBeFalse()
            expect(component.isError_route).toBeFalse()
        })
        afterEach(() => {
            component.selectedRegions = []
            component.selectedRoutes = []
        })
    })

    describe('selectedFilters', () => {
        beforeEach(() => {
            component.selectedRegions = ['region1']
            component.selectedRoutes = ['routes1']
        })
        it('should change variabel to true', () => {
            component.checkForErrors()
            expect(component.isError_region).toBeFalse()
            expect(component.isError_route).toBeFalse()
        })
    })

    describe('selectedFilters', () => {
        beforeEach(() => {
            spyOn(component.selectedFilterCollection, 'emit')
            component.selectedRegions = ['region1']
            component.selectedRoutes = ['routes1']
        })
        it('should emit the filter object', () => {
            const selectedFilters: IFilters = {
                name: 'HRR',
                regions: ['region1'],
                routes: ['routes1'],
                mdus: ['mdu'],
                action: 'submit',
            }
            component.selectedFilters()
            expect(
                component.selectedFilterCollection.emit(selectedFilters),
            ).toHaveBeenCalledWith(selectedFilters)
        })
    })

    describe('resetToInitials', () => {
        it('should call setInitialsValue and selectedFilters funcitons', () => {
            component.resetToInitials()
            expect(component.selectedFilters).toHaveBeenCalled()
        })

        it('should reset selectedRegions and selectedRoutes ', () => {
            component.user.region = ''
            component.resetToInitials()
            expect(component.selectedRegions.length).toBe(0)
            expect(component.selectedRoutes.length).toBe(0)
        })
    })

    describe('ngAfterViewInit', () => {
        it('should call ngAfterViewInit setInitialsValue', (done) => {
            // expect(setTimeout).toHaveBeenCalledWith(jasmine.any(Function), 200);
            expect(component.ngOnInit()).toHaveBeenCalled()
            setTimeout(() => {
                done()
            }, 200)
        })
    })

    describe('checkForSelectedRouteOverflow', () => {
        beforeEach(() => {
            component.selectedRoutes = ['route1', 'route2']
            component.routes = ['route1']
        })
        it('should set the selectedroutes as per routes', () => {
            component.checkForSelectedRouteOverflow()
            expect(component.selectedRoutes).toEqual(component.routes)
        })
        afterEach(() => {
            component.selectedRoutes = []
            component.routes = []
        })
    })
    describe('setRoute', () => {
        beforeEach(() => {
            component.boundries = {
                region1: {
                    route1: ['mdu1'],
                },
            }
        })

        it('should update the routes', () => {
            component.setRoute(['region1'])
            expect(component.routes.length).toBeTrue()
        })

        afterEach(() => {
            component.boundries = {}
        })
    })
})
