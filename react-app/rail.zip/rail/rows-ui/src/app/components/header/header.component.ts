import { Component, OnInit } from '@angular/core'
import { FormsModule } from '@angular/forms'
import { Router } from '@angular/router'
import { AuthService } from '../../services/auth.service'
import { UserAuthService } from '../../services/user-auth.service'
import { IUser } from '../../shared/interfaces/interface'
import { SharedModule } from '../../shared/shared.module'

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss'],
    standalone: true,
    imports: [FormsModule, SharedModule],
})
export class HeaderComponent implements OnInit {
    searchInput = ''
    showMenu = false
    public user: IUser = {
        id: '',
        name: '',
        username: '',
        email: '',
        region: '',
        route: '',
        mdu: '',
        designation: '',
        firstLogin: false,
    }
    constructor(
        private authSvc: AuthService,
        private userSvc: UserAuthService,
        private route: Router,
    ) {}
    ngOnInit(): void {
        this.userSvc.getUser().subscribe((user) => (this.user = user))
    }
    search() {}

    myProfile() {
        this.route.navigateByUrl('myProfile')
        this.showMenu = false
    }
    logout() {
        this.authSvc.logout()
    }
}
