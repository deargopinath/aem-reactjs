import { ComponentFixture, TestBed, async } from '@angular/core/testing'

import { AlertSummaryCountComponent } from './alert-summary-count.component'
import { SubjectService } from 'src/app/services/subject.service'
import { UserAuthService } from 'src/app/services/user-auth.service'
import { ApiCallService } from 'src/app/services/web-serivces/api-call.service'
import { IUser } from 'src/app/shared/interfaces/interface'
import { of } from 'rxjs'

describe('AlertSummaryCountComponent', () => {
    let component: AlertSummaryCountComponent
    let userSvc: UserAuthService
    let api: ApiCallService
    let subjectService: SubjectService

    beforeEach(() => {
        component = new AlertSummaryCountComponent(userSvc, api, subjectService)
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })

    it('should call ngAfterViewInit', async(() => {
        const response: any = []
        spyOn(userSvc, 'getUser').and.returnValue(of(response))
        component.ngAfterViewInit()
    }))
})
