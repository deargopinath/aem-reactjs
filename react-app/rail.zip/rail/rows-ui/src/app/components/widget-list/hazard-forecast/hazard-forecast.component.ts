import { Component } from '@angular/core'
import { Router } from '@angular/router'
import { map } from 'rxjs'
import { SubjectService } from '../../../services/subject.service'
import { UserAuthService } from '../../../services/user-auth.service'
import { ApiCallService } from '../../../services/web-serivces/api-call.service'
import { IUser } from '../../../shared/interfaces/interface'
import { API_END_POINTS } from '../../../../environments/environment'
import { SEVEN_DAY_HAZARD } from '../../../core/properties/application.properties'
import { SEVEN_DAY_HAZARD_PARAMETER } from '../../../core/constants/app.constants'

export interface IHazardParameter {
    weatherParameter: string
    name: string
    icon: string
    enabled: boolean
}
export interface ISevenDaysHazard {
    [wind: string]: ISevenDaysWeatherParameter
}
export interface ISevenDaysWeatherParameter {
    RegionName: string
    RouteName: string
    WeatherParamName: weatherParameter
    Value: Array<ISevenDaysWeatherRagStatus>
}
type weatherParameter = 'wind'
export interface ISevenDaysWeatherRagStatus {
    DayOfWeek: string
    RAG: string
}
@Component({
    selector: 'app-hazard-forecast',
    templateUrl: './hazard-forecast.component.html',
    styleUrls: ['./hazard-forecast.component.scss'],
})
export class HazardForecastComponent {
    sevenDayHazardText = SEVEN_DAY_HAZARD
    Hazards: Array<IHazardParameter> = SEVEN_DAY_HAZARD_PARAMETER
    minimizeTable = false
    sevenDaysData: ISevenDaysHazard = {}
    weekDays: Array<string> = []
    user!: IUser
    constructor(
        private router: Router,
        private api: ApiCallService,
        private subSvc: SubjectService,
        private userSvc: UserAuthService,
    ) {}

    leftAdjustment = false
    ngOnInit(): void {
        this.subSvc.adjustWidgetsPosition.subscribe(
            ({ left }: { left: boolean; right: boolean }) => {
                this.leftAdjustment = left
            },
        )
        this.userSvc.getUser().subscribe((user: IUser) => {
            this.user = user
            this.getHazardForecast()
        })
    }
    /** geting seven days hazard details */
    getHazardForecast() {
        this.api
            .singleApiCall(
                API_END_POINTS.getHazardForeCast +
                    this.user.region +
                    '/' +
                    this.user.route,
                'GET',
            )
            .pipe(
                map((hazardData: Array<ISevenDaysWeatherParameter>) => {
                    const modifiedParameter: ISevenDaysHazard = {}
                    hazardData.forEach((param: ISevenDaysWeatherParameter) => {
                        modifiedParameter[param.WeatherParamName] = param
                    })
                    return modifiedParameter
                }),
            )
            .subscribe((hazardTable) => {
                this.sevenDaysData = hazardTable
                this.getWeekDays()
                console.log(hazardTable)
            })
    }

    /** collecting week day order as per the recieving data */
    getWeekDays() {
        const days: Array<string> = []
        Object.values(this.sevenDaysData)[0].Value.forEach(
            ({ DayOfWeek }: ISevenDaysWeatherRagStatus) => {
                days.push(DayOfWeek.substring(0, 3))
            },
        )
        this.weekDays = days
    }
    /** minimize and maximizing the widget */
    toggleTable() {
        this.minimizeTable = !this.minimizeTable
    }

    routeTo() {
        console.log('route to')
    }

    openDetailedHazard() {
        this.router.navigateByUrl('dashboard/forecast')
    }
}
