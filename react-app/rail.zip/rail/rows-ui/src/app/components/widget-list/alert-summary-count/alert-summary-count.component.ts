import { Component, ElementRef, ViewChild, AfterViewInit } from '@angular/core'
import { Chart } from 'chart.js/auto'
import { map } from 'rxjs'
import {
    ALERT_SUMMARY_DATA,
} from 'src/app/core/constants/app.constants'
import { SubjectService } from 'src/app/services/subject.service'
import { UserAuthService } from 'src/app/services/user-auth.service'
import { ApiCallService } from 'src/app/services/web-serivces/api-call.service'
import { IUser } from 'src/app/shared/interfaces/interface'
import { API_END_POINTS } from 'src/environments/environment.dev'

export interface ISummaryCount {
    Date: string
    RegionName: string
    RouteName: string
    MDUName: string
    WeatherParamName: string
    RAG: string
}

@Component({
    selector: 'app-alert-summary-count',
    templateUrl: './alert-summary-count.component.html',
    styleUrls: ['./alert-summary-count.component.scss'],
})
export class AlertSummaryCountComponent implements AfterViewInit {
    @ViewChild('alertSummary', { static: false })
    alertSummary!: ElementRef<HTMLCanvasElement>
    minimizeTable = false
    leftAdjustment = false
    private ctxChart!: CanvasRenderingContext2D
    myChart: any
    dataset: any = ALERT_SUMMARY_DATA
    user!: IUser
    organizationalBoundries: any = {}
    labels: string[] = []
    summaryApiData: any = []

    constructor(
        private userSvc: UserAuthService,
        private api: ApiCallService,
        private subjectService: SubjectService,
    ) {}
    ngAfterViewInit(): void {
        this.userSvc.getUser().subscribe((user: IUser) => {
            this.user = user
            this.subjectService.organizationalBoundaries.subscribe(
                (boundries: any) => {
                    this.organizationalBoundries = boundries
                    this.getAlertSummaryCount()
                },
            )
        })
    }

    /** api integration */
    getAlertSummaryCount() {
        this.api
            .singleApiCall(
                API_END_POINTS.getAlertSummaryCount +
                    this.user.region +
                    '/' +
                    this.user.route,
                'GET',
            )
            .pipe(
                map((summaryData: Array<any>) => {
                    const paramObj: any = {}
                    summaryData.forEach((param: ISummaryCount) => {
                        paramObj[param.WeatherParamName] = param
                    })
                    return paramObj
                }),
            )
            .subscribe((summaryCounts: any) => {
                this.formatSummaryCount(summaryCounts)
            })
    }

    /**finding the labels and calling the plot function */
    formatSummaryCount(summaryData: any) {
        Object.keys(summaryData).forEach((element: any) => {
            this.labels.push(element)
        })
        this.setRagParams(summaryData)

        this.ctxChart = this.alertSummary.nativeElement.getContext('2d')!
        this.plotMap()
    }

    /**generate the count for each RAG(Y,A,R) and push to dataset for plotting the bar chart */
    setRagParams(data: any) {
        const mduCount =
            this.organizationalBoundries[this.user.region][this.user.route]
                .length
        Object.values(data).forEach((element: any, index: any) => {
            if (this.labels[index] === element.WeatherParamName) {
                let redCount = 0
                let yellowCount = 0
                let amberCount = 0
                for (let i = 0; i < mduCount; i++) {
                    if (element.Value[i]?.RAG === 'R') {
                        redCount++
                    }
                    if (element.Value[i]?.RAG === 'Y') {
                        yellowCount++
                    }
                    if (element.Value[i]?.RAG === 'A') {
                        amberCount++
                    }
                }
                this.dataset.forEach((element: any) => {
                    if (element.label === 'DU Count Red') {
                        element.data.push(redCount + 1)
                    }
                    if (element.label === 'DU Count Amber') {
                        element.data.push(amberCount + 1)
                    }
                    if (element.label === 'DU Count Yellow') {
                        element.data.push(yellowCount + 1)
                    }
                    if (element.label === '') {
                        element.data.push(
                            this.organizationalBoundries[this.user.region][
                                this.user.route
                            ].length,
                        )
                    }
                })
            }
        })
    }

    /** minimize widget */
    toggleTable() {
        this.minimizeTable = !this.minimizeTable
        if (!this.minimizeTable) {
            this.myChart.destroy()
            setTimeout(() => {
                this.ctxChart =
                    this.alertSummary.nativeElement.getContext('2d')!
                this.plotMap()
            }, 200)
        }
    }

    /**function which set the config and data for the chart */
    plotMap() {
        this.myChart = new Chart(this.ctxChart, {
            type: 'bar',
            data: {
                labels: this.labels,
                datasets: this.dataset,
            },
            options: {
                responsive: false,
                indexAxis: 'y',
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        enabled: true,
                        mode: 'point',
                        callbacks: {},
                    },
                    legend: {
                        display: true,
                        onClick: () => {
                            return
                        },
                    },
                },
                layout: {
                    padding: {
                        left: 0,
                        right: 0,
                    },
                },
                scales: {
                    x: {
                        grid: {
                            display: false,
                        },
                        ticks: {
                            display: true,
                            stepSize: 1,
                        },
                        title: {
                            display: true,
                            text: 'Number of DU',
                            color: '#525252',
                            font: {
                                size: 14,
                            },
                        },
                    },
                    y: {
                        grid: {
                            display: true,
                        },
                        ticks: {
                            display: true,
                        },
                        title: {
                            display: true,
                            text: 'Weather Parameter',
                            color: '#525252',
                            font: {
                                size: 14,
                            },
                        },
                    },
                },
            },
        })
    }
}
