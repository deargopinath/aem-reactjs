import { Subject, of } from 'rxjs'
import { WidgetsComponent } from './widgets.component'
import { SubjectService } from 'src/app/services/subject.service'
import { HazardForecastComponent } from '../widget-list/hazard-forecast/hazard-forecast.component'
import { IWidget } from '../../shared/interfaces/interface'
import { Forecast24HoursComponent } from '../widget-list/forecast24-hours/forecast24-hours.component'

describe('WidgetsComponent', () => {
    let component: WidgetsComponent
    let SubjectService: SubjectService
    beforeEach(() => {
        component = new WidgetsComponent(SubjectService)
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })

    it('should clear the selected widget when the updateWidget event is triggered', () => {
        component.ngOnInit()
        expect(component.selectedWidget).toEqual([])
    })

    describe('updateWidget', () => {
        const widget: IWidget = {
            img_src: 'assets/icons/widget_hazard.png',
            heading: 'Hazard forecast 7 days',
            description:
                '"Hazard forecast 7 days" widget displays the 7 day hazard for the route for specific weather conditions such as wind, air temperature, snow etc. for the forecast to be analyzed for the next 7 days with the smarties displaying the RAG statuses.',
            component: HazardForecastComponent,
            section: 0,
        }

        it('should return empty', () => {
            widget.component = null
            expect(component.updateWidget(widget)).toBeFalse()
        })
        it('should remove widget', () => {
            widget.component = HazardForecastComponent
            component.selectedWidget = [widget]
            component.updateWidget(widget)
            expect(component.selectedWidget.length).toBeFalse()
        })
        it('should add widget', () => {
            const widget_new = {
                img_src: 'assets/icons/forecast-24-widget.png',
                heading: 'Forecast 24 hour',
                description:
                    '"Forecast 24 hour" widget displays the route specific 24 hour forecast data for different weather parameters such as wind speed, wind gust, air temperature, snow etc.',
                component: Forecast24HoursComponent,
                section: 0,
            }
            component.selectedWidget = []
            component.updateWidget(widget_new)
            expect(component.selectedWidget.includes(widget_new)).toBeTrue()
        })
        it('should transmit next value', () => {
            widget.component = HazardForecastComponent
            component.updateWidget(widget)
            expect(SubjectService.adComponents.next).toHaveBeenCalledWith({
                component: HazardForecastComponent,
                section: 0,
            })
        })
    })
})
