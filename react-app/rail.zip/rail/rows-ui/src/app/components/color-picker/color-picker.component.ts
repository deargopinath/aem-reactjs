import { Component, Input } from '@angular/core'
import { CommonModule } from '@angular/common'
import { MatTooltipModule } from '@angular/material/tooltip'

@Component({
    selector: 'app-color-picker',
    standalone: true,
    imports: [CommonModule, MatTooltipModule],
    templateUrl: './color-picker.component.html',
    styleUrls: ['./color-picker.component.scss'],
})
export class ColorPickerComponent {
    @Input() component!: string
    // @Input() isRAG!: boolean
    @Input() selectedCapsuleName!: string

    isRAG = false
}
