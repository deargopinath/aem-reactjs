import { BrowserModule } from '@angular/platform-browser'
import { NoopAnimationsModule } from '@angular/platform-browser/animations'
import { NgModule } from '@angular/core'

import { AppRoutingModule } from './app-routing.module'
import { AppComponent } from './app.component'
import { HeaderComponent } from './components/header/header.component'

import { HttpClientModule } from '@angular/common/http'

import {
    MsalGuard,
    MsalBroadcastService,
    MsalModule,
    MsalService,
    MsalRedirectComponent,
} from '@azure/msal-angular'
import { FeatureModule } from './modules/features/feature.module'
import { MapComponent } from './components/GIS/map/map.component'
import { AppInitializeService } from './services/app-initialize.service'
import { SidenavComponent } from './components/sidenav/sidenav.component'
import { UserProfileComponent } from './components/user-profile/user-profile.component'

import * as authConfig from './core/auth/auth-config'

@NgModule({
    declarations: [AppComponent],
    imports: [
        BrowserModule,
        NoopAnimationsModule, // Animations cause delay which interfere with E2E tests
        AppRoutingModule,
        HttpClientModule,
        MsalModule,
        HeaderComponent,
        SidenavComponent,
        FeatureModule,
        MapComponent,
        UserProfileComponent,
    ],
    providers: [
        ...authConfig.providers,
        AppInitializeService,
        MsalService,
        MsalGuard,
        MsalBroadcastService,
    ],
    bootstrap: [AppComponent, MsalRedirectComponent],
})
export class AppModule {}
