import { NgModule } from '@angular/core'
import { Routes, RouterModule } from '@angular/router'
import { MsalGuard } from '@azure/msal-angular'
import { BrowserUtils } from '@azure/msal-browser'
import { UserProfileComponent } from './components/user-profile/user-profile.component'

const routes: Routes = [
    {
        path: '',
        loadChildren: () =>
            import('./modules/dashboard/dashboard.module').then(
                (m) => m.DashboardModule,
            ),
        canActivate: [MsalGuard],
    },
    {
        path: 'dashboard',
        loadChildren: () =>
            import('./modules/dashboard/dashboard.module').then(
                (m) => m.DashboardModule,
            ),
    },
    {
        path: 'feature',
        loadChildren: () =>
            import('./modules/features/feature.module').then(
                (m) => m.FeatureModule,
            ),
    },

    {
        path: 'myProfile',
        component: UserProfileComponent,
        canActivate: [MsalGuard],
    },
]

@NgModule({
    imports: [
        RouterModule.forRoot(routes, {
            initialNavigation:
                !BrowserUtils.isInIframe() && !BrowserUtils.isInPopup()
                    ? 'enabledNonBlocking'
                    : 'disabled',
            useHash: true,
        }),
    ],
    exports: [RouterModule],
})
export class AppRoutingModule {}
