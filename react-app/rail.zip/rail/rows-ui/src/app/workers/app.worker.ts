/// <reference lib="webworker" />

addEventListener('message', ({ data }) => {
    const response = { data } //`worker response to ${data}`;
    postMessage(response)
})
