import { Pipe, PipeTransform } from '@angular/core'

@Pipe({
    name: 'ragStatus',
})
export class RagStatusPipe implements PipeTransform {
    transform(value: string): string {
        if (value === 'G') {
            return 'rag-green'
        }
        if (value === 'R') {
            return 'rag-red'
        }
        if (value === 'A') {
            return 'rag-amber'
        }
        if (value === 'Y') {
            return 'rag-yellow'
        }
        return ''
    }
}
