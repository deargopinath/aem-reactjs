import { RagStatusPipe } from './rag-status.pipe'

describe('RagStatusPipe', () => {
    let pipe: RagStatusPipe
    pipe = new RagStatusPipe()
    it('create an instance', () => {
        expect(pipe).toBeTruthy()
    })

    it('should return rag-green', () => {
        expect(pipe.transform('G')).toBe('rag-green')
    })

    it('should return rag-red', () => {
        expect(pipe.transform('R')).toBe('rag-red')
    })

    it('should return rag-amber', () => {
        expect(pipe.transform('A')).toBe('rag-amber')
    })

    it('should return rag-yellow', () => {
        expect(pipe.transform('Y')).toBe('rag-yellow')
    })

    it('should return empty', () => {
        expect(pipe.transform('')).toBe('')
    })
})
