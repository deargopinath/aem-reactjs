import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { DropDownComponent } from './components/drop-down/drop-down.component'
import { FormsModule } from '@angular/forms'
import { MapComponent } from '../components/GIS/map/map.component'
import { SubHeaderComponent } from '../components/header/sub-header/sub-header.component'

import {
    NgbDatepickerModule,
    NgbTimepickerModule,
    NgbModule,
} from '@ng-bootstrap/ng-bootstrap'

import { MatButtonModule } from '@angular/material/button'
import { MatInputModule } from '@angular/material/input'
import { MatFormFieldModule } from '@angular/material/form-field'
import { MatIconModule } from '@angular/material/icon'
import { MatToolbarModule } from '@angular/material/toolbar'
import { MatCardModule } from '@angular/material/card'
import { MatTooltipModule } from '@angular/material/tooltip'
import { RangeCalenderComponent } from './components/range-calender/range-calender.component'
import { TimeSliderComponent } from './components/time-slider/time-slider.component'
import { WidgetsComponent } from '../components/widgets/widgets.component'
//import { AdDirective } from './directives/ad.directive'
//import { RagStatusPipe } from './pipes/rag-status.pipe'
@NgModule({
    declarations: [
        DropDownComponent,
        SubHeaderComponent,
        RangeCalenderComponent,
        TimeSliderComponent,
    ],
    imports: [
        CommonModule,
        FormsModule,
        MapComponent,
        MatIconModule,
        MatButtonModule,
        MatInputModule,
        MatFormFieldModule,
        MatToolbarModule,
        MatCardModule,
        MatTooltipModule,
        NgbDatepickerModule,
        NgbTimepickerModule,
        NgbModule,
        WidgetsComponent,
    ],
    exports: [
        DropDownComponent,
        MapComponent,
        SubHeaderComponent,
        TimeSliderComponent,
        CommonModule,
        MatIconModule,
        MatButtonModule,
        MatInputModule,
        MatFormFieldModule,
        MatToolbarModule,
        MatCardModule,
        MatTooltipModule,
        NgbDatepickerModule,
        NgbTimepickerModule,
        NgbModule,
        WidgetsComponent,
    ],
})
export class SharedModule {}
