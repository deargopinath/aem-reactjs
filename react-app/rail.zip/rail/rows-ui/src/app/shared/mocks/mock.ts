import { AirTempCurrent } from '../interfaces/interface'

export const MOCK_WIND_CURRENT = [
    {
        RegionName: 'Southern',
        RouteName: 'Kent',
        MDUName: 'Ashford MDU',
        Value: [
            {
                DateTime: '2023-09-07 11:00:00',
                'Wind Speed': '14.30',
                'Wind Gusts': '24.30',
                RAG: 'G',
                'Wind Direction': 'SW',
            },
            {
                DateTime: '2023-09-08 11:00:00',
                'Wind Speed': '8.58',
                'Wind Gusts': '18.58',
                RAG: 'G',
                'Wind Direction': 'SW',
            },
            {
                DateTime: '2023-09-13 11:00:00',
                'Wind Speed': '8.58',
                'Wind Gusts': '18.58',
                RAG: 'G',
                'Wind Direction': 'SW',
            },
        ],
    },
    {
        RegionName: 'Southern',
        RouteName: 'Kent',
        MDUName: 'Lon Bridge MDU',
        Value: [
            {
                DateTime: '2023-09-07 11:00:00',
                'Wind Speed': '5.90',
                'Wind Gusts': '15.90',
                RAG: 'G',
                'Wind Direction': 'SW',
            },
            {
                DateTime: '2023-09-12 11:00:00',
                'Wind Speed': '6.46',
                'Wind Gusts': '16.46',
                RAG: 'G',
                'Wind Direction': 'SW',
            },
            {
                DateTime: '2023-09-13 11:00:00',
                'Wind Speed': '6.46',
                'Wind Gusts': '16.46',
                RAG: 'G',
                'Wind Direction': 'SW',
            },
        ],
    },
]

export const MOCK_AIR_TEMP: AirTempCurrent[] = [
    {
        route: 'Anglia',
        region: 'Eastern',
        mdu: 'Ipswich MDU',
        value: [
            {
                time: '2023-09-07 16:00:00',
                celcius: '22.3',
                dewPoint: '52.62',
            },
        ],
    },
    {
        route: 'Anglia',
        region: 'Eastern',
        mdu: 'Romford MDU',
        value: [
            {
                time: '2023-09-07 16:00:00',
                celcius: '22.3',
                dewPoint: '44.78',
            },
        ],
    },
]

export const MOCK_DAILY_AIR = [
    {
        "RegionName": "Eastern",
        "RouteName": "Anglia",
        "MDUName": "Ipswich MDU",
        "Value": [
            {
                "Date": "2023-09-09",
                "WeatherParameter": "Air Temp Max (Daily)",
                "value": "17.02",
                "RAG": "G"
            },
            {
                "Date": "2023-09-09",
                "WeatherParameter": "Air Temp Min (Daily)",
                "value": "7.57",
                "RAG": "G"
            }
        ]
    },
    {
        "RegionName": "Eastern",
        "RouteName": "Anglia",
        "MDUName": "Romford MDU",
        "Value": [
            {
                "Date": "2023-09-09",
                "WeatherParameter": "Air Temp Max (Daily)",
                "value": "11.26",
                "RAG": "G"
            },
            {
                "Date": "2023-09-09",
                "WeatherParameter": "Air Temp Min (Daily)",
                "value": "5.29",
                "RAG": "G"
            }
        ]
    },
    {
        "RegionName": "Eastern",
        "RouteName": "Anglia",
        "MDUName": "Tottenham MDU",
        "Value": [
            {
                "Date": "2023-09-09",
                "WeatherParameter": "Air Temp Max (Daily)",
                "value": "10.51",
                "RAG": "G"
            },
            {
                "Date": "2023-09-09",
                "WeatherParameter": "Air Temp Min (Daily)",
                "value": "7.48",
                "RAG": "G"
            }
        ]
    }
]
