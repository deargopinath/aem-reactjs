import {
    Component,
    AfterViewInit,
    OnDestroy,
    Input,
    OnChanges,
    SimpleChanges,
} from '@angular/core'
import { Observable } from 'rxjs'
import moment from 'moment/moment'
import { SubjectService } from 'src/app/services/subject.service'
import { MapService } from '../../../services/gis/map.service'

@Component({
    selector: 'app-time-slider',
    templateUrl: './time-slider.component.html',
    styleUrls: ['./time-slider.component.scss'],
})
export class TimeSliderComponent
    implements OnDestroy, AfterViewInit, OnChanges
{
    @Input({ required: true }) component!: string
    @Input() type = 'forcast'
    @Input() tabSelected = 0
    date: Date = new Date()
    timeSliderValue = 0
    imageDateTime = ''
    timeSliderStep = 1
    id: any = undefined
    isplay = false
    hours = 0
    hoursArr: Array<number> = []
    dateRange = { from: '', to: '', startTime: '', endTime: '' }
    tooltip = 0
    date$!: Observable<Date>
    dateArr: Array<string> = []
    noOfHours = 0
    defaultFrom = new Date()
    defaultTo = null
    sliderRange!: any
    tooltipVal!: any
    from!: Date

    constructor(
        private subjectService: SubjectService,
        private mapService: MapService,
    ) {}
    ngOnChanges(changes: SimpleChanges): void {
        this.sliderRange = document.getElementById('customRange3')!
        this.tooltipVal = document.getElementById('tooltip')!
        this.type === 'forecast' ? this.resetDateRange() : this.resetDateRange()
        this.tabSelected === 0 ? this.resetDateRange() : this.resetDateRange()
    }

    ngAfterViewInit(): void {
        this.sliderRange = document.getElementById('customRange3')!
        this.tooltipVal = document.getElementById('tooltip')!
        this.mapService.getWetherParameterChange().subscribe((item) => {
            this.resetDateRange()
        })
    }

    /** date picker provides the range of dates selected from calender */
    public onDateRangeSelection(range: { from: Date; to: Date }) {
        this.mapService.dateRange = range
        this.from = range.from
        this.resetDateTime()
        const start = this.setDateTime(range.from)
        const from = start.toDate()
        const end = this.setDateTime(range.to)
        const to = end.toDate()
        const fromDate = from.getTime()! / (1000 * 3600 * 24)
        const toDate = to.getTime()! / (1000 * 3600 * 24)
        const noOfDays = toDate - fromDate
        this.hours = noOfDays * 24
        this.noOfHours = noOfDays * 24
        while (this.noOfHours > 0) {
            this.hoursArr.push(Math.trunc(this.noOfHours))
            this.noOfHours--
        }
        this.hoursArr.reverse()
        const rangeCol = this.getDates(from, to)
        this.dateArr = this.simpleFormat(rangeCol)
        this.dateRange.from = moment(range.from).format('DD/MM/YYYY')
        this.dateRange.to = moment(range.to).format('DD/MM/YYYY')
        this.dateRange.startTime = moment(this.date).format('HH00')
        this.dateRange.endTime = '0600'
    }
    /** change the format of date */
    simpleFormat(dates: Array<Date>) {
        const newDates: Array<string> = []
        dates.forEach((element: Date) => {
            newDates.push(moment(element).format('DD/MM/YYYY HH00'))
        })
        return newDates
    }

    /** create array of dates between start and end date */
    getDates = (startDate: Date, endDate: Date) => {
        const dates: Array<Date> = []
        const start = this.setDateTime(startDate)
        let currentDate = start.toDate()
        const addDays = (currentDate: Date, hrs: number) => {
            const date = new Date(currentDate)
            date.setHours(date.getHours() + hrs)
            const dateValue = this.setDateTime(date)
            return dateValue.toDate()
        }
        while (currentDate <= endDate) {
            dates.push(currentDate)
            currentDate = addDays(currentDate, 24)
        }
        return dates
    }

    /** set the time and date for a specified date */
    setDateTime(date: any) {
        const dateValue = moment(date, undefined, false)
        return dateValue.set({ h: 6, m: 0 })
    }

    /** reset the calender and time-slider functionality */
    resetDateTime() {
        //this.mapService.dateRange = null;
        this.defaultFrom = null!
        this.defaultTo = null
        this.hours = 0
        this.hoursArr = []
        this.dateArr = []
        this.noOfHours = 0
        this.timeSliderValue = 0
        this.sliderRange!.style.background = '#96BAC5'
        clearInterval(this.id)
        this.isplay = false
        this.tooltipVal!.style.left = 0
        this.tooltipVal!.innerHTML = ``
    }

    /** reset invoked */
    resetDateRange() {
        this.resetDateTime()
        this.subjectService.isReset.next(true)
    }

    /** Time Slider
     *  play button functionalities */
    playTimeSeries() {
        this.sliderRange = document.getElementById('customRange3')!
        this.tooltipVal = document.getElementById('tooltip')!
        this.isplay = true
        if (
            this.timeSliderValue === 0 &&
            moment(this.from).format('DD/MM/YYYY') ===
                moment(new Date()).format('DD/MM/YYYY')
        ) {
            this.timeSliderValue = this.date.getHours() - 6
        }
        this.id = setInterval(() => {
            if (this.timeSliderValue >= this.hours) {
                clearInterval(this.id)
                this.timeSliderValue = 0
                this.sliderRange!.style.background = '#96BAC5'
                this.id = undefined
                this.isplay = false
            } else {
                if (this.mapService.layerMetadata != null) {
                    const lmd =
                        this.mapService.layerMetadata.weather_sub_parameter
                    for (let l = 0; l < lmd.length; l++) {
                        if (
                            lmd[l].weather_sub_parameter_id ==
                            this.mapService.weather_sub_parameter.p_details.id
                        ) {
                            if (lmd[l].horizon == '24hour') {
                                this.timeSliderValue += 24
                                this.timeSliderStep = 24
                            } else {
                                this.timeSliderValue++
                                this.timeSliderStep = 1
                            }
                        }
                    }
                } else {
                    this.timeSliderValue = this.timeSliderValue + 1
                }

                this.sliderRange!.style.background = `linear-gradient(90deg,#70B397 ${
                    (this.timeSliderValue / this.hours) * 100
                }%, #96BAC5 0%)`
                let newDatetime = this.generateDateTime(
                    this.timeSliderValue,
                    this.dateArr[0],
                )
                this.tooltipVal!.innerHTML = `<span class="spanEl">${newDatetime}</span>`
                this.tooltipVal!.style.left = `${
                    (this.timeSliderValue / this.hours) * 100
                }%`

                let sliderDt = newDatetime
                console.log(sliderDt)
                let str1 = sliderDt.toString().split(' ', 2)
                console.log(str1)
                let str2 = str1[0].split('/', 3)
                console.log(str2)
                let str3 = str1[1].split(':', 2)
                console.log(str3)
                console.log(this.timeSliderValue)
                try {
                    this.mapService?.loadNextData(str2[0], str3[0])
                } catch (error) {
                    console.warn('mapservice loadnextdata error ' + error)
                }
                if (this.timeSliderValue >= this.hours) {
                    this.tooltipVal!.style.left = 0
                    const startAt = this.setDateTime(this.from)
                    this.tooltipVal!.innerHTML = `<span class="spanEl">${moment(
                        startAt,
                    ).format('DD/MM/YYYY HH00')}</span>`
                }
            }
        }, 2000)
    }

    /** pause button functionalities */
    pauseTimeSeries() {
        this.isplay = false
        if (this.timeSliderValue >= this.hours) {
            clearInterval(this.id)
            this.id = undefined
        } else {
            this.timeSliderValue
            clearInterval(this.id)
            this.id = undefined
        }
    }

    /**  previous button functionalities */
    previousTimeSeries() {
        if (this.timeSliderValue > 0) {
            //this.timeSliderValue--
            if (this.mapService.layerMetadata != null) {
                const lmd =
                    this.mapService.layerMetadata.weather_sub_parameter
                for (let l = 0; l < lmd.length; l++) {
                    if (
                        lmd[l].weather_sub_parameter_id ==
                        this.mapService.weather_sub_parameter.p_details.id
                    ) {
                        if (lmd[l].horizon == '24hour') {
                            this.timeSliderValue -= 24
                            this.timeSliderStep = 24
                        } else {
                            this.timeSliderValue--
                            this.timeSliderStep = 1
                        }
                    }
                }
            } else {
                this.timeSliderValue = this.timeSliderValue - 1
            }
            this.sliderRange!.style.background = `linear-gradient(90deg,#70B397 ${
                (this.timeSliderValue / this.hours) * 100
            }%, #96BAC5 0%)`
            this.tooltipVal!.innerHTML = `<span class="spanEl">${this.generateDateTime(
                this.timeSliderValue,
                this.dateArr[0],
            )}</span>`
            this.tooltipVal!.style.left = `${
                (this.timeSliderValue / this.hours) * 100
            }%`
            let sliderDt = this.generateDateTime(this.timeSliderValue, this.dateArr[0])
            console.log(sliderDt)
            let str1 = sliderDt.toString().split(" ", 2);
            console.log(str1)
            let str2 = str1[0].split("/", 3);
            console.log(str2)
            let str3 = str1[1].split(":", 2);
            console.log(str3)
            try {
                this.mapService?.loadNextData(str2[0], str3[0])
            } catch (error) {
                console.warn('mapservice loadnextdata error ' + error)
            }
        }
    }

    /** next button functionalities */
    nextTimeSeries() {
        if (this.timeSliderValue < this.hours) {
            //this.timeSliderValue++
            if (this.mapService.layerMetadata != null) {
                const lmd =
                    this.mapService.layerMetadata.weather_sub_parameter
                for (let l = 0; l < lmd.length; l++) {
                    if (
                        lmd[l].weather_sub_parameter_id ==
                        this.mapService.weather_sub_parameter.p_details.id
                    ) {
                        if (lmd[l].horizon == '24hour') {
                            this.timeSliderValue += 24
                            this.timeSliderStep = 24
                        } else {
                            this.timeSliderValue++
                            this.timeSliderStep = 1
                        }
                    }
                }
            } else {
                this.timeSliderValue = this.timeSliderValue + 1
            }
            this.sliderRange!.style.background = `linear-gradient(90deg,#70B397 ${
                (this.timeSliderValue / this.hours) * 100
            }%, #96BAC5 0%)`
            this.tooltipVal!.innerHTML = `<span class="spanEl">${this.generateDateTime(
                this.timeSliderValue,
                this.dateArr[0],
            )}</span>`
            this.tooltipVal!.style.left = `${
                (this.timeSliderValue / this.hours) * 100
            }%`
            let sliderDt = this.generateDateTime(this.timeSliderValue, this.dateArr[0])
            console.log(sliderDt)
            let str1 = sliderDt.toString().split(" ", 2);
            console.log(str1)
            let str2 = str1[0].split("/", 3);
            console.log(str2)
            let str3 = str1[1].split(":", 2);
            console.log(str3)
            try {
                this.mapService?.loadNextData(str2[0], str3[0])
            } catch (error) {
                console.warn('mapservice loadnextdata error ' + error)
            }
        }
        if (this.timeSliderValue >= this.hours) {
            this.tooltipVal!.style.left = 0
            this.timeSliderValue = 0
            this.sliderRange!.style.background = '#96BAC5'
            const startAt = this.setDateTime(this.from)
            this.tooltipVal!.innerHTML = `<span class="spanEl">${moment(
                startAt,
            ).format('DD/MM/YYYY HH00')}</span>`
        }
    }
    /** event triggered when slider-pointer dragged to specified point */
    changed(evt: any) {
        //console.log('Inside Change function')
        //console.log('Slider Change Function')
        if (this.timeSliderValue < this.hours) {
            this.sliderRange!.style.background = `linear-gradient(90deg,#70B397 ${
                (evt.target.value / this.hours) * 100
            }%, #96BAC5 0%)`
            console.log('Inside Change Function')
            console.log(evt)
            this.timeSliderValue = +evt.target.value
            console.log(this.timeSliderValue)
            this.tooltipVal!.innerHTML = `<span class="spanEl">${this.generateDateTime(
                evt.target.value,
                this.dateArr[0],
            )}</span>`
            console.log(
                this.generateDateTime(evt.target.value, this.dateArr[0]),
            )
            this.tooltipVal!.style.left = `${
                (evt.target.value / this.hours) * 100
            }%`
        }
        if (this.timeSliderValue >= this.hours) {
            this.tooltipVal!.style.left = 0
            this.tooltipVal!.innerHTML = `<span class="spanEl">${moment(
                this.from,
            ).format('DD/MM/YYYY HH00')}</span>`
        }
    }

    /** create new date and time with each step slider moves back and fourth */
    generateDateTime(hour: number, startDate: string) {
        const day = startDate.split('/')[0]
        const month = startDate.split('/')[1]
        const year = startDate.split('/')[2].split(' ')[0]

        if (this.timeSliderValue <= this.hours) {
            const date = new Date(`${month}/${day}/${year}`)
            const dateTime = this.setDateTime(date).toDate()
            while (hour != 0) {
                dateTime.setHours(dateTime.getHours() + 1)
                hour = hour - 1
            }
            return moment(dateTime).format('DD/MM/YYYY hh:mm')
        } else {
            return new Date(`${month}/${day}/${year}`)
        }
    }

    timeSliderDragStop(evt: any) {
        console.log('Drag complete function')
        console.log(evt)
        let sliderDt = this.generateDateTime(evt.target.value, this.dateArr[0])
        console.log(sliderDt)
        let str1 = sliderDt.toString().split(' ', 2)
        console.log(str1)
        let str2 = str1[0].split('/', 3)
        console.log(str2)
        let str3 = str1[1].split(':', 2)
        console.log(str3)
        try {
            this.mapService?.loadNextData(str2[0], str3[0])
        } catch (error) {
            console.warn('mapservice loadnextdata error ' + error)
        }
    }

    /**  clear the interval value when component gets closed */
    ngOnDestroy() {
        if (this.id) {
            clearInterval(this.id)
        }
    }
}
