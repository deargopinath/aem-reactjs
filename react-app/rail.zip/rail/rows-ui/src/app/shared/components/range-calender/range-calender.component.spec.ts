import { ComponentFixture, TestBed } from '@angular/core/testing'

import { RangeCalenderComponent } from './range-calender.component'
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap'
import { SubjectService } from 'src/app/services/subject.service'

describe('RangeCalenderComponent', () => {
    let component: RangeCalenderComponent
    // let fixture: ComponentFixture<RangeCalenderComponent>
    let subjectServiceSpy: jasmine.SpyObj<SubjectService>

    beforeEach(() => {
        const subjectServiceSpyObj = jasmine.createSpyObj('SubjectService', [
            'isReset',
        ])

        TestBed.configureTestingModule({
            providers: [
                RangeCalenderComponent,
                { provide: SubjectService, useValue: subjectServiceSpyObj },
            ],
        })

        component = TestBed.inject(RangeCalenderComponent)
        subjectServiceSpy = TestBed.inject(
            SubjectService,
        ) as jasmine.SpyObj<SubjectService>
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })

    describe('ngOnInit', () => {
        it('should call forecastMinMax', () => {
            component.ngOnInit()
            expect(component.forecastMinMax()).toHaveBeenCalled()
        })
    })

    describe('setDates', () => {
        it('should call setDates', () => {
            const date = new Date()
            component.setDates(date)
            expect(component.setDates(date)).toHaveBeenCalled()
        })
    })

    describe('forecastMinMax', () => {
        it('should set minDate', () => {
            const date = new Date()
            component.forecastMinMax()
            expect(component.minDate).toEqual({
                day: date.getDate(),
                month: date.getMonth() + 1,
                year: date.getFullYear(),
            })
        })
        it('should set maxDate', () => {
            const date = new Date()
            component.forecastMinMax()
            expect(component.maxDate).toEqual({
                day: date.getDate() + 15,
                month: date.getMonth() + 1,
                year: date.getFullYear(),
            })
        })
    })

    describe('observedMinMax', () => {
        it('should set minDate', () => {
            const date = new Date()
            component.observedMinMax()
            expect(component.minDate).toEqual({
                day: date.getDate(),
                month: date.getMonth(),
                year: date.getFullYear(),
            })
        })
        it('should set maxDate', () => {
            const date = new Date()
            component.observedMinMax()
            expect(component.maxDate).toEqual({
                day: date.getDate() + 15,
                month: date.getMonth() + 1,
                year: date.getFullYear(),
            })
        })
    })

    describe('myClass', () => {
        it('should check for sunday', () => {
            const date: NgbDateStruct = {
                day: 27,
                month: 8,
                year: 2023,
            }
            const date1: NgbDateStruct = {
                day: 28,
                month: 8,
                year: 2023,
            }
            expect(component.myClass(date)).toEqual('weekend-color')
            expect(component.myClass(date1)).toEqual('classNormal')
        })
    })

    describe('formattedDateRange', () => {
        it('should call formattedDateRange', () => {
            const date = new Date()
            component.formattedDateRange()
        })
    })

    describe('toDate', () => {
        it('should call toDate', () => {
            let date!: NgbDateStruct
            expect(component.toDate(date)).toEqual(null)
        })
    })

    describe('onDateSelection', () => {
        it('should check from when from and to are null', () => {
            const date: NgbDateStruct = {
                day: 27,
                month: 8,
                year: 2023,
            }
            component.from = null
            component.to = null
            component.onDateSelection(date)
            expect(component.from).toBeTrue()
        })

        it('should check to when to is null', () => {
            const date: NgbDateStruct = {
                day: 27,
                month: 8,
                year: 2023,
            }
            component.from = component.toDate(date)
            component.to = null
            component.onDateSelection(date)
            expect(component.to).toBeTrue()
        })

        it('should call checkMaxDateRange ', () => {
            const date: NgbDateStruct = {
                day: 27,
                month: 8,
                year: 2023,
            }
            const startDate = 20
            const endDate = 5
            const compo = 'hotRunningRail'
            component.onDateSelection(date)
            expect(
                component.checkMaxDateRange(startDate, endDate, compo),
            ).toBeTrue()
            expect(component.exceeded).toBeTrue()
            expect(component.to).toEqual(null)
            expect(component.from).toEqual(null)
        })

        it('should check when hotRunningRail', () => {
            const date: NgbDateStruct = {
                day: 27,
                month: 8,
                year: 2023,
            }
            const startDate = 14
            const endDate = 4
            const compo = 'hotRunningRail'
            component.onDateSelection(date)
            expect(
                component.checkMaxDateRange(startDate, endDate, compo),
            ).toHaveBeenCalled()
            expect(component.exceeded).toEqual(true)
        })

        it('should check when hotRunningRail', () => {
            const date: NgbDateStruct = {
                day: 27,
                month: 8,
                year: 2023,
            }
            const startDate = 12
            const endDate = 8
            const compo = 'hotRunningRail'
            component.onDateSelection(date)
            expect(
                component.checkMaxDateRange(startDate, endDate, compo),
            ).toHaveBeenCalled()
        })

        it('should check when fireRisk', () => {
            const date: NgbDateStruct = {
                day: 27,
                month: 8,
                year: 2023,
            }
            const startDate = 20
            const endDate = 9
            const compo = 'fireRisk'
            component.onDateSelection(date)

            expect(
                component.checkMaxDateRange(startDate, endDate, compo),
            ).toHaveBeenCalled()
            expect(component.exceeded).toEqual(true)
        })

        it('should check when fireRisk', () => {
            const date: NgbDateStruct = {
                day: 27,
                month: 8,
                year: 2023,
            }
            const startDate = 12
            const endDate = 9
            const compo = 'fireRisk'
            component.onDateSelection(date)

            expect(
                component.checkMaxDateRange(startDate, endDate, compo),
            ).toHaveBeenCalled()
        })

        it('should check when dashboard', () => {
            const date: NgbDateStruct = {
                day: 27,
                month: 8,
                year: 2023,
            }
            const startDate = 19
            const endDate = 1
            const compo = 'dashboard'
            component.onDateSelection(date)
            expect(
                component.checkMaxDateRange(startDate, endDate, compo),
            ).toHaveBeenCalled()
            expect(component.exceeded).toEqual(true)
        })

        it('should check when dashboard', () => {
            const date: NgbDateStruct = {
                day: 27,
                month: 8,
                year: 2023,
            }
            const startDate = 14
            const endDate = 1
            const compo = 'dashboard'
            component.onDateSelection(date)
            expect(
                component.checkMaxDateRange(startDate, endDate, compo),
            ).toHaveBeenCalled()
            //  expect(component.exceeded).toBeTrue()
        })
    })

    describe('toMoment', () => {
        it('should call toMoment', () => {
            const date: NgbDateStruct = {
                day: 27,
                month: 8,
                year: 2023,
            }
            expect(component.toMoment(date)).toHaveBeenCalled()
        })
    })

    describe('isHovered', () => {
        it('should call isHovered', () => {
            const date: NgbDateStruct = {
                day: 27,
                month: 8,
                year: 2023,
            }
            expect(component.isHovered(date)).toHaveBeenCalled()
            expect(component.hoveredDate).toHaveBeenCalled()
        })
    })

    describe('isInside', () => {
        it('should call isInside', () => {
            const date: NgbDateStruct = {
                day: 27,
                month: 8,
                year: 2023,
            }
            expect(component.isInside(date)).toHaveBeenCalled()
        })
    })

    describe('isFrom', () => {
        it('should call isFrom', () => {
            const date: NgbDateStruct = {
                day: 27,
                month: 8,
                year: 2023,
            }
            expect(component.isFrom(date)).toHaveBeenCalled()
        })
    })

    describe('isTo', () => {
        it('should call isFrom', () => {
            const date: NgbDateStruct = {
                day: 27,
                month: 8,
                year: 2023,
            }
            expect(component.isTo(date)).toHaveBeenCalled()
        })
    })
})
