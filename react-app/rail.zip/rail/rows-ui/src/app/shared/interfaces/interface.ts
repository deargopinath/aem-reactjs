export interface IAppNavigation {
    name: string
    path: string
    subNav: Array<IPageNavigation>
}
export interface IPageNavigation {
    name: string
    routeTo: string
    path?: string
}

export interface IFilters {
    name: string
    action: string
    regions: string[]
    routes: string[]
    mdus: string[]
}

export interface IDropdownSelectedList {
    name: string
    selectedItems: string[]
}

export interface IUser {
    id: string
    name: string
    username: string
    email: string
    region: string
    route: string
    mdu: string
    designation: string
    firstLogin: boolean
}

export interface IFireSteamRisk {
    RegionName: string
    RouteName: string
    MDUName: string
    WeatherParamName: string
    Value: [IValue]
}

export interface IValue {
    Day_Date: string
    MaxFireTemp?: string
    MaxSteamTemp?: string
}

export interface ILegend {
    color: string
    name: string
    info: string
}

export interface IBoundaries {
    region: string[]
    route: string[]
    mdu: string[]
}

export interface IFireSteam {
    0: IFireSteamCollection
    1: IFireSteamCollection
}

export interface IFireSteamCollection {
    selectedBoundries: IBoundaries
    boundries: IBoundaries
    title: string
    tableData: Array<IFireSteamRisk>
    cacheTable: Array<IFireSteamRisk>
    legends: Array<ILegend>
}

export interface IWidget {
    img_src: string
    heading: string
    description: string
    component: any
    section: number
}

export interface IWidgetAlignment {
    left: boolean
    right: boolean
}

export interface WindCurrent {
    RegionName: string
    RouteName: string
    MDUName: string
    Value: WindValues[]
}

interface WindValues {
    DateTime: string
    WindSpeed: string
    WindGusts: string
    RAG: string
    WindDirection: string
}

export interface AirTempCurrent {
    route: string
    region: string
    mdu: string
    value: AirValues[]
}

interface AirValues {
    time: string
    celcius: string
    dewPoint: string
}
