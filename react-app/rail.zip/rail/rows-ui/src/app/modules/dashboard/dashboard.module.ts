import { NgModule } from '@angular/core'
import { CommonModule, DatePipe } from '@angular/common'
import { DashboardComponent } from './dashboard/dashboard.component'
import { RouterModule, Routes } from '@angular/router'
import { MsalGuard } from '@azure/msal-angular'

import { MapComponent } from '../../components/GIS/map/map.component'
import { AdDirective } from '../../shared/directives/ad.directive'
import { HazardForecastComponent } from '../../components/widget-list/hazard-forecast/hazard-forecast.component'
import { Forecast24HoursComponent } from '../../components/widget-list/forecast24-hours/forecast24-hours.component'
import { RagStatusPipe } from '../../shared/pipes/rag-status.pipe'
import { SharedModule } from '../../shared/shared.module'
import { AlertSummaryCountComponent } from 'src/app/components/widget-list/alert-summary-count/alert-summary-count.component'
import { UserProfileComponent } from 'src/app/components/user-profile/user-profile.component'
import { ColorPickerComponent } from 'src/app/components/color-picker/color-picker.component'
import { DetailedHazardComponent } from './detailed-hazard/detailed-hazard.component'
import { FilterPanelComponent } from 'src/app/components/filter-panel/filter-panel.component'
import { WindTableComponent } from 'src/app/components/tables/wind-table/wind-table.component'
const routes: Routes = [
    { path: '', component: DashboardComponent },
    {
        path: 'dashboard',
        data: { breadcrumbs: ['dashboard'] },
        component: DashboardComponent,
        canActivate: [MsalGuard],
    },
    {
        path: 'forecast',
        data: { breadcrumbs: ['dashboard', 'forecast'] },
        component: DetailedHazardComponent,
        canActivate: [MsalGuard],
    },
]

@NgModule({
    declarations: [
        DashboardComponent,
        AdDirective,
        HazardForecastComponent,
        Forecast24HoursComponent,
        AlertSummaryCountComponent,
        RagStatusPipe,
        DetailedHazardComponent,
    ],
    imports: [
        CommonModule,
        MapComponent,
        RouterModule.forChild(routes),
        SharedModule,
        UserProfileComponent,
        ColorPickerComponent,
        FilterPanelComponent,
        WindTableComponent,
    ],
    providers: [DatePipe],
})
export class DashboardModule {}
