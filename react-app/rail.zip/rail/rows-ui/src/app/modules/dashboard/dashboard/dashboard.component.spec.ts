import { HazardForecastComponent } from '../../../components/widget-list/hazard-forecast/hazard-forecast.component'
import { DashboardComponent } from './dashboard.component'
import { SubjectService } from '../../../services/subject.service'
import { QueryList, ViewContainerRef } from '@angular/core'
import { AdDirective } from '../../../shared/directives/ad.directive'
import { ActivatedRoute, Router } from '@angular/router'
import { ApiCallService } from '../../../services/web-serivces/api-call.service'
import { UserAuthService } from '../../../services/user-auth.service'
import { MapService } from '../../../services/gis/map.service'
import { FilterService } from '../../../services/filter.service'
describe('DashboardComponent', () => {
    let component: DashboardComponent
    let subjectSvc: SubjectService
    let route: Router
    let api: ApiCallService
    let userSvc: UserAuthService
    let activatedRoute: ActivatedRoute
    let mapService: MapService
    let filterService: FilterService
    beforeEach(() => {
        component = new DashboardComponent(
            api,
            userSvc,
            subjectSvc,
            activatedRoute,
            mapService,
            filterService,
        )
    })

    it('should create', () => {
        expect(component).toBeTruthy()
    })

    it('should call ngOninit', () => {
        component.ngOnInit()
        spyOn(subjectSvc.updateWidget, 'next')
        const spy = spyOn(component, 'displayCurrentTable')
        expect(subjectSvc.updateWidget.next).toHaveBeenCalledWith([false])
        expect(spy).toHaveBeenCalled()
    })

    it('should check parameters and call fetchCurrentWindData, on calling displayCurrentTable', () => {
        const spy = spyOn(component, 'fetchCurrentWindData')
        subjectSvc.parameterName.next('Wind (mph)')
        subjectSvc.subParameterName.next('Wind speed')
        subjectSvc.isCapsuleSelected.next(true)
        expect(component.showtableBtn).toBeTrue()
        expect(spy).toHaveBeenCalled()
    })

    it('should check parameters and call fetchCurrentAirTempData, on calling displayCurrentTable', () => {
        const spy = spyOn(component, 'fetchCurrentAirTempData')
        subjectSvc.parameterName.next(
            'Air Temperature (\u00B0C)' || 'Air Temperature (°C)',
        )
        subjectSvc.subParameterName.next('Maximum Temperature')
        subjectSvc.isCapsuleSelected.next(true)
        expect(component.showtableBtn).toBeTrue()
        expect(spy).toHaveBeenCalled()
    })

    it('should check parameters and and call, on calling displayCurrentTable', () => {
        subjectSvc.isCapsuleSelected.next(false)
        expect(component.showtableBtn).toBeFalse()
    })

    it('should call addComponent', () => {
        component.components = [[HazardForecastComponent], []]
        component.leftContainer = Object.assign(new QueryList(), {
            _results: [HazardForecastComponent],
        }) as QueryList<AdDirective>

        component.checkComponentVisiblity(HazardForecastComponent, 0)
        expect(component.addComponent).toHaveBeenCalled()
    })
    it('should call removeComponent', () => {
        const instance = new String()
        component.components = [[{ instance: instance }], []]
        component.leftContainer = Object.assign(new QueryList(), {
            _results: [HazardForecastComponent],
        }) as QueryList<AdDirective>

        component.checkComponentVisiblity(String, 0)
        expect(component.removeComponent).toHaveBeenCalled()
    })

    it('should add a component', () => {
        const viewContainerRef = {
            createComponent(component: any) {
                return component
            },
        }
        const componentName = 'MyComponent'
        const section = 0
        component.components = [[], []]

        component.addComponent(componentName, viewContainerRef, section)
        expect(component.components[section][0].componentType.name).toBe(
            componentName,
        )
    })
    it('should remove a component', () => {
        const viewContainerRef = {
            remove(component: number) {},
        }
        const section = 0
        component.components = [['MyComponent'], []]

        component.removeComponent(0, viewContainerRef, section)
        expect(component.components[section][0].length).toBe(0)
    })

    it('should update call getLastValueOfheightUpdate', () => {
        component.components = [['MyComponent1', 'MyComponent2'], []]

        component.updateWidgetsHeight(0, 'add')
        expect(component.components[0].length).toBe(2)
    })
})
