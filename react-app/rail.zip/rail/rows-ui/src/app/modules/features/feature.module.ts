import { NgModule } from '@angular/core'
import { HotRunningRailComponent } from './hot-running-rail/hot-running-rail.component'
import { SharedModule } from 'src/app/shared/shared.module'
import { CommonModule } from '@angular/common'
import { RouterModule, Routes } from '@angular/router'
import { MsalGuard } from '@azure/msal-angular'

import { MapComponent } from '../../components/GIS/map/map.component'
import { HotRunningRailTableComponent } from '../../components/hot-running-rail-table/hot-running-rail-table.component'
import { FireRiskIndexComponent } from './fire-risk-index/fire-risk-index.component'
import { MatButtonToggleModule } from '@angular/material/button-toggle'
import { FireSteamRiskComponent } from 'src/app/components/tables/fire-steam-risk/fire-steam-risk.component'
import { FilterPanelComponent } from '../../components/filter-panel/filter-panel.component'

const routes: Routes = [
    {
        path: '',
        redirectTo: 'fire-risk-index',
        pathMatch: 'full',
    },
    {
        path: 'hot-running-rail',
        component: HotRunningRailComponent,
        canActivate: [MsalGuard],
    },
    {
        path: 'fire-risk-index',
        component: FireRiskIndexComponent,
        canActivate: [MsalGuard],
    },
]

@NgModule({
    declarations: [
        HotRunningRailComponent,
        HotRunningRailTableComponent,
        FireRiskIndexComponent,
    ],
    imports: [
        CommonModule,
        SharedModule,
        RouterModule.forChild(routes),
        MapComponent,
        MatButtonToggleModule,
        FireSteamRiskComponent,
        FilterPanelComponent,
    ],
})
export class FeatureModule {}
