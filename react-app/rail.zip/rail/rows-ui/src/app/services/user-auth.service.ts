import { Injectable } from '@angular/core'
import { BehaviorSubject } from 'rxjs'
import { IUser } from '../shared/interfaces/interface'
import { ApiCallService } from './web-serivces/api-call.service'
import { API_END_POINTS } from 'src/environments/environment'
import {  Router } from '@angular/router'

@Injectable({
    providedIn: 'root',
})
export class UserAuthService {
    public isUserLoggedIn$ = new BehaviorSubject<boolean>(false)
    private user: IUser = {
        id: '',
        name: '',
        username: '',
        email: '',
        region: '',
        route: '',
        mdu: '',
        designation: '',
        firstLogin: false,
    }
    private user$ = new BehaviorSubject<IUser>(this.user)
    constructor(
        private api: ApiCallService,
        private route: Router,
    ) {}

    /** returning the user object */
    getUser() {
        return this.user$.asObservable()
    }

    getUserDetails(userdetail: {
        id: string
        name: string
        username: string
        email: string
        designation: string
    }) {
        const { id } = userdetail
        this.api
            .singleApiCall(API_END_POINTS.getUserDetails + '/' + id, 'GET')
            .subscribe((user) => {
                if (user.length === 0) {
                    this.user.id = userdetail.id
                    this.user.name = userdetail.name
                    this.user.username = userdetail.username
                    this.user.email = userdetail.email
                    this.user.designation = userdetail.designation
                    this.user.firstLogin = true
                    this.user$.next(this.user)
                    this.route.navigateByUrl('myProfile')
                } else {
                    this.user.id = user[0].UPNID
                    this.user.name = user[0].Name
                    this.user.username = user[0].User_Name
                    this.user.email = user[0].EmailId
                    this.user.region = user[0].Region_Name
                    this.user.route = user[0].Route_Name
                    this.user.mdu = user[0].MDU_Name
                    this.user.designation = user[0].Designation
                    this.user.firstLogin = false
                    this.user$.next(this.user)
                }
            })
    }
}
