import { Injectable } from '@angular/core'
import {
    ROUTE_FILTER,
    REGION_FILTER,
    MDU_FILTER,
} from '../core/constants/app.constants'

@Injectable({
    providedIn: 'root',
})
export class OrganizationBoundaryService {
    resructureBoundariesData(BaoudnariesArray: Array<any>) {
        const boundariesName: any = {}
        BaoudnariesArray.forEach((boundry) => {
            const routeMDU: any = {}
            routeMDU[boundry[ROUTE_FILTER]] = boundry[MDU_FILTER].split(',')
            boundariesName[boundry[REGION_FILTER]] = {
                ...boundariesName[boundry[REGION_FILTER]],
                ...routeMDU,
            }
        })
        return boundariesName
    }
}
