import { OrganizationBoundaryService } from './organization-boundary.service'

describe('OrganizationBoundaryService', () => {
    let service: OrganizationBoundaryService

    beforeEach(() => {
        service = new OrganizationBoundaryService()
    })

    it('should restructure the boundaries data', () => {
        const boundariesArray = [
            {
                REGION_FILTER: 'Eastern',
                ROUTE_FILTER: 'Anglia',
                MDU_FILTER: 'Ipswich MDU',
            },
            {
                REGION_FILTER: 'Southern',
                ROUTE_FILTER: 'High Speed 1',
                MDU_FILTER: 'HS1',
            },
        ]

        const expectedBoundariesName = {
            Eastern: {
                Anglia: ['Ipswich MDU'],
            },
            Southern: {
                'High Speed 1': ['HS1'],
            },
        }

        const actualBoundariesName =
            service.resructureBoundariesData(boundariesArray)

        expect(actualBoundariesName).toEqual(expectedBoundariesName)
    })
})
