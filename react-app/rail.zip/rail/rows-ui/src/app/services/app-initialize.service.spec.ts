import { AppInitializeService } from './app-initialize.service'
import { SubjectService } from './subject.service'
import { ApiCallService } from './web-serivces/api-call.service'
import { OrganizationBoundaryService } from './organization-boundary.service'

describe('AppInitializeService', () => {
    let service: AppInitializeService
    let SubjectService: SubjectService
    let ApiCallService: ApiCallService
    let OrganizationBoundaryService: OrganizationBoundaryService

    beforeEach(() => {
        service = new AppInitializeService(
            SubjectService,
            ApiCallService,
            OrganizationBoundaryService,
        )
    })

    it('should call the onApplicationLoad method', () => {
        service.onApplicationLoad()
        expect(service.onApplicationLoad()).toHaveBeenCalled()
    })
})
