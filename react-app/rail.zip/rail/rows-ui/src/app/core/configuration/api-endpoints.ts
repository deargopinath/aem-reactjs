export const API_END_POINTS = {
    organizationalBoundry:
        'api/OrganizationalBoundry/triggers/When_a_HTTP_request_is_received/invoke?api-version=2022-05-01&sp=%2Ftriggers%2FWhen_a_HTTP_request_is_received%2Frun&sv=1.0&sig=t1Vc5ojRsRewiz237jh2hDeCvupdUBwPC9bpcXSgaao',
    hotRunningRail:
        'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/hotRunningRail',
    fireRisk:
        'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/fireRiskIndex',
    steamRisk:
        'https://was-uks-nprd-waf-rowsdev6004.azurewebsites.net/api/steamRiskIndex',
    osBaseMapLight_27700:
        'https://api.os.uk/maps/raster/v1/zxy/Light_27700/{z}/{x}/{y}.png?key=',
    geoServer:
        'https://was-uks-nprd-waf-rowsdev6001.azurewebsites.net/geoserver/',
    gisMicroservices: 'http://localhost/api/',
    zoomToFeatures: 'zoomToFeatures',
}
