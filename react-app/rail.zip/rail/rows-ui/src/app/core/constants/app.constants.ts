import { AlertSummaryCountComponent } from 'src/app/components/widget-list/alert-summary-count/alert-summary-count.component'
import { Forecast24HoursComponent } from 'src/app/components/widget-list/forecast24-hours/forecast24-hours.component'
import { HazardForecastComponent } from 'src/app/components/widget-list/hazard-forecast/hazard-forecast.component'

export const APP_NAVIGATION = [
    {
        name: 'Dashboard',
        path: 'dashboard',
        subNav: [
            {
                name: 'Dashboard',
                routeTo: 'dashboard',
                path: 'dashboard',
                module: 1,
            },
            {
                name: 'Configuration',
                routeTo: '',
                path: 'configuration',
            },
        ],
    },
    {
        name: 'Alerts',
        path: 'alert',
        subNav: [],
    },
    {
        name: 'Feature',
        path: 'feature',

        subNav: [
            {
                name: 'Fire risk index',
                routeTo: 'feature/fire-risk-index',
                path: 'fire-risk-index',
                module: 2,
                id: 2,
            },
            {
                name: 'Conductor rail',
                routeTo: '',
                path: '',
                module: 2,
                id: 3,
            },
            {
                name: 'Hot running rail',
                path: 'hot-running-rail',
                routeTo: 'feature/hot-running-rail',
                module: 2,
                id: 1,
            },
            {
                name: 'OLE icing risk',
                routeTo: '',
                path: '',
                module: 2,
                id: 4,
            },
            {
                name: 'Coastal surges and overtopping',
                routeTo: '',
                module: 2,
                id: 5,
            },
            {
                name: 'Precipitation analysis',
                routeTo: '',
                path: '',
                module: 2,
                id: 6,
            },
            {
                name: 'Convective rainfall',
                routeTo: '',
                path: '',
                module: 2,
                id: 7,
            },
            {
                name: 'RADAR analysis',
                routeTo: '',
                path: '',
                module: 2,
                id: 8,
            },
            {
                name: 'Adhesion and leaf fall',
                routeTo: '',
                path: '',
                module: 2,
                id: 9,
            },
            {
                name: 'Tunnel Icing risk',
                routeTo: '',
                path: '',
                module: 2,
                id: 10,
            },
            {
                name: 'Soil Moisture',
                routeTo: '',
                path: '',
                module: 2,
                id: 11,
            },
        ],
    },
    {
        name: 'Forecast',
        path: 'forecast',
        subNav: [
            {
                name: 'Map and Table interaction',
                routeTo: '',
                path: '',
            },
            {
                name: 'Combined weather map',
                routeTo: '',
                path: 'combined-weather-map',
            },
        ],
    },
    {
        name: 'Observed',
        path: 'observed',
        subNav: [
            {
                name: 'Map and Table interaction',
                routeTo: '',
                path: '',
            },
            {
                name: 'Combined weather map',
                routeTo: '',
                path: '',
            },
        ],
    },
    {
        name: 'Report',
        path: 'report',
        subNav: [
            {
                name: 'Configuration',
                routeTo: '',
                path: '',
            },
            {
                name: 'Download Report',
                routeTo: '',
                path: '',
            },
        ],
    },
    {
        name: 'Help',
        path: 'help',
        subNav: [],
    },
]

export const HRR_TABLE_LEGENDS = [
    { color: 'R', name: 'Max Rail Temp >= 46C' },
    { color: 'A', name: 'Max Rail Temp >= 43C' },
    { color: 'Y', name: 'Max Rail Temp >= 40C' },
    { color: 'G', name: 'Max Rail Temp < 40C' },
]
export const FIRE_RISK_LEGENDS = [
    { color: 'olivine', name: 'Very Low', info: '' },
    { color: 'manz', name: 'Low', info: '' },
    { color: 'cream_can', name: 'Moderate', info: '' },
    { color: 'sorbus', name: 'High', info: '' },
    { color: 'burnt_umber', name: 'Very High', info: '' },
    { color: 'astronaut_blue', name: 'Exceptional', info: '' },
]
export const STEAM_RISK_LEGENDS = [
    {
        color: 'mantis',
        name: 'Low',
        info: 'Spark arrestor and ash pan sprinkler confirmed operational',
    },
    {
        color: 'sorbus',
        name: 'High',
        info: 'In additional to above consider use of diesel assisted steam',
    },
    { color: 'burnt_umber', name: 'Very High', info: 'Diesel assisted steam' },
    {
        color: 'astronaut_blue',
        name: 'Exceptional',
        info: 'No Steam Operation',
    },
]

export const REGION_FILTER = 'RegionName'
export const ROUTE_FILTER = 'RouteName'
export const MDU_FILTER = 'MDUName'

export enum TOGGLE_TAB {
    fire,
    steam,
}

export const CAPTION = [
    'Fire severity index - (24 hours)',
    'Steam Risk Index - (24 hours)',
]

export const WIDGET_LIST = [
    {
        img_src: 'assets/icons/widget_hazard.png',
        heading: 'Hazard forecast 7 days',
        description:
            'The widget displays the 7 days hazard for the route for specific weather conditions with the RAG smarties.',
        component: HazardForecastComponent,
        section: 0,
    },
    {
        img_src: 'assets/icons/forecast-24-widget.png',
        heading: 'Forecast 24 hours',
        description:
            'The widget displays the route specific 24 hours forecast data for different weather parameters wind etc',
        component: Forecast24HoursComponent,
        section: 0,
    },
    {
        img_src: 'assets/icons/alert_widget.png',
        heading: 'Alert Summary',
        description:
            'The widget displays the count of route specific alerts for 24 hours.',
        component: AlertSummaryCountComponent,
        section: 1,
    },
    {
        img_src: 'assets/icons/satellite_widget.png',
        heading: 'Satellite Map',
        description:
            'The widget displays the observation for the visible, infrared and solar satellite.',
        component: null,
        section: 1,
    },
    {
        img_src: 'assets/icons/radar_widget.png',
        heading: 'RADAR Map',
        description:
            'The widget displays RADAR observations for the geospatial boundary.',
        component: null,
        section: 1,
    },
]

export const SEVEN_DAY_HAZARD_PARAMETER = [
    {
        weatherParameter: 'wind',
        name: 'Wind (mph)',
        icon: 'wind',
        enabled: true,
    },
    {
        weatherParameter: 'Air Temp(Min)',
        name: 'Air Temperature-Min (\u00B0C)',
        icon: 'air',
        enabled: true,
    },
    {
        weatherParameter: 'Air Temp(Max)',
        name: 'Air Temperature-Max (\u00B0C)',
        icon: 'air',
        enabled: true,
    },
    {
        weatherParameter: 'light',
        name: 'Lightning risk',
        icon: 'light',
        enabled: false,
    },
    {
        weatherParameter: 'snow',
        name: 'Snow (cm)',
        icon: 'snow',
        enabled: false,
    },
]

export const DASHBOARD_WEATHER_PARAMETERS = {
    forecast: [
        {
            weatherName: 'Precipitation (mm)',
            weatherIcon: 'rain',
            subWeathers: ['Precipitation', 'Soil Moisture'],
        },
        {
            weatherName: 'Wind (mph)',
            weatherIcon: 'wind',
            subWeathers: ['Wind speed', 'Wind direction', 'Wind gusts'],
        },
        {
            weatherName: 'Air Temperature (\u00B0C)',
            weatherIcon: 'air',
            subWeathers: ['Maximum Temperature', 'Minimum Temperature'],
        },
        {
            weatherName: 'Humidity (%)',
            weatherIcon: 'humidity',
            subWeathers: ['Humidity (%)'],
        },
        {
            weatherName: 'Lightning risk',
            weatherIcon: 'light',
            subWeathers: [],
        },
        {
            weatherName: 'Snow (cm)',
            weatherIcon: 'snow',
            subWeathers: ['Snowfall depth', 'Snow melt', 'Ground thaw'],
        },
    ],
    observered: [
        {
            weatherName: 'Precipitation (mm)',
            weatherIcon: 'rain',
            subWeathers: ['Precipitation', 'Soil Moisture'],
        },
        {
            weatherName: 'Wind (mph)',
            weatherIcon: 'wind',
            subWeathers: ['Wind speed', 'Wind direction', 'Wind gusts'],
        },
        {
            weatherName: 'Air Temperature (\u00B0C)',
            weatherIcon: 'air',
            subWeathers: ['Maximum Temperature', 'Minimum Temperature'],
        },
        {
            weatherName: 'Snow (cm)',
            weatherIcon: 'snow',
            subWeathers: ['Snowfall depth', 'Snow melt', 'Ground thaw'],
        },
    ],
}

export const HOTRUNNINGRAIL_WEATHER_PARAMETERS = {
    forecast: [
        {
            weatherName: 'Real/near-real time rail temperature data (\u00B0C)',
            weatherIcon: 'air',
            subWeathers: [],
            id: 1,
        },
        {
            weatherName: 'Max rail temperature (\u00B0C)',
            weatherIcon: 'air',
            subWeathers: [],
            id: 2,
        },
        {
            weatherName: 'Real/near-real time air temperature data (\u00B0C)',
            weatherIcon: 'air',
            subWeathers: [],
            id: 3,
        },
        {
            weatherName: 'Max air temperature (\u00B0C)',
            weatherIcon: 'air',
            subWeathers: [],
            id: 4,
        },
    ],
}

export const FIRERISK_WEATHER_PARAMETERS = {
    forecast: [
        {
            weatherName: 'Fire Risk Index',
            weatherIcon: 'air',
            subWeathers: [],
            id: 5,
        },
        {
            weatherName: 'Steam Risk Index',
            weatherIcon: 'air',
            subWeathers: [],
            id: 6,
        },
    ],
}

export const WEATHERPARAMETERS_LIST = [
    'Wind Gusts',
    'Wind direction',
    'Wind Speed',
    'Max Temperature',
    'Min Temperature',
    'Dew point',
    'Air Temperature',
    'Humidity',
    'Lightening risk',
    'Snow',
]

export const ALERT_SUMMARY_DATA = [
    {
        axis: 'y',
        label: 'DU Count Red',
        data: [],
        fill: false,
        backgroundColor: ['#E32C00'],
        borderColor: ['#E32C00'],
        borderWidth: 0.5,
    },
    {
        axis: 'y',
        label: 'DU Count Amber',
        data: [],
        fill: false,
        backgroundColor: ['#EA961F'],
        borderColor: ['#EA961F'],
        borderWidth: 0.5,
    },
    {
        axis: 'y',
        label: 'DU Count Yellow',
        data: [],
        fill: false,
        backgroundColor: ['#FFD800'],
        borderColor: ['#FFD800'],
        borderWidth: 0.5,
    },
    {
        axis: 'y',
        label: '',
        data: [],
        fill: false,
        backgroundColor: 'rgba(0,0,0,0)',
        barThickness: 0,
        borderWidth: 0,
    },
]

export const sampleData = [
    {
        RegionName: 'Southern',
        RouteName: 'Kent',
        WeatherParamName: 'Air Temp(Max)',
        Value: [
            {
                MDUName: 'Ashford MDU',
                RAG: 'R',
            },

            {
                MDUName: 'mdu3',
                RAG: 'A',
            },
        ],
    },
    {
        RegionName: 'Southern',
        RouteName: 'Kent',
        WeatherParamName: 'Wind Gust',
        Value: [
            {
                MDUName: 'Ashford MDU',
                RAG: '',
            },
            {
                MDUName: 'mdu2',
                RAG: 'Y',
            },

            {
                MDUName: 'mdu3',
                RAG: 'A',
            },
        ],
    },
    {
        RegionName: 'Southern',
        RouteName: 'Kent',
        WeatherParamName: 'Wind Speed',
        Value: [
            {
                MDUName: 'Ashford MDU',
                RAG: 'R',
            },
            {
                MDUName: 'mdu2',
                RAG: '',
            },

            {
                MDUName: 'mdu3',
                RAG: 'A',
            },
        ],
    },
]
