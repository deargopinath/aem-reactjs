export const TIME_DELAY = 500
export const SEVEN_DAY_HAZARD = {
    hourHeading: 'FORECAST - 24 HOURS',
    hourHeadingDescription: '(Weather and Hazard Summary)',
    hourDescription: `Mainly cloudy today with patchy light rain in places, although
    generally drier in the northeast. Staying mostly cloudy with dry
    conditions for a time this evening before a spell of showery
    rain will move northward across the southern half of the route.
    Towards the end of the night a band of rain will push in from
    the west, becoming more fragmented east of the Pennines to bring
    mostly light and patchy rain to much of the route.`,
    dayHeading: 'FORECAST - 7 DAYS',
    dayHeadingDescription: '(Weather and Hazard Summary)',
    dayDescription: `Overcast tomorrow with outbreaks of rain throughout the day,
    these mostly light in the south while heavy at times in the
    north. Becoming drier and mostly clear overnight as any light
    rain will gradually clear to the south. Turning chilly too with
    frosts in places. Largely dry and sunny on Thursday, although
    the odd spot of light rain possible near the east coast at
    times. Becoming cloudier from the north overnight with some
    patchy rain possible. Frosts also possible in southern parts of
    the route. Variable amounts of cloud with some patches of light
    rain at times on Friday and Saturday. Generally drier and
    chillier during the nights, leading to frosts developing under
    any clear spells.`,
}

export const PROFILE_STATUS_ADD_SUCCESS_MESSAGE =
    'User profile added Successfully'
export const PROFILE_STATUS_UPDATE_SUCCESS_MESSAGE =
    'User profile updated Successfully'
export const PROFILE_STATUS_ADD_FAIL_MESSAGE = 'Failed to add user profile'
export const PROFILE_STATUS_UPDATE_FAIL_MESSAGE =
    'Failed to update user profile'
