# rows-ui

User interface for the ROWS application

## Component overview

```
+--------------------+
|       rows-ui      |
+------+------+------+
       |      |
  +----+      +----+
  |                |
[SSO]       [rows-gateway]
                   |
                   |
            [Services, data]
```

## Pre-requisites

-   Nodejs 18 or above
-   Angular 16.0.4

## Development

> npm install
> ng serve

## Testing

> npm run test

## Format and style check

> ng lint
