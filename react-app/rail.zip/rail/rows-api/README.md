# rows-api
Weather forecast and user profile APIs

# Solution overview
```
   (rows-ui)
       |
 (APIM & SSO)
       |      
+------+------+
|  rows-api   |
+------+------+
       |
   (Database)
```

# Development
```
> cd WeatherAPI
> pip install -r requirements.txt
> python manage.py runserver
> python manage.py runserver --settings settings_local
```

# Testing
```
> pytest
```

# Deployment
```
> docker build -t rows-api .
> docker run -dp 127.0.0.1:8000:8000 rows-api
```

# Format and style check
```
> black .
> ruff check .
```