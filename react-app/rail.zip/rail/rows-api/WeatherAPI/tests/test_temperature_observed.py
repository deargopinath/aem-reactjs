from django.test import Client, TestCase, TransactionTestCase
import sqlite3


class ValidRequestTestCase(TestCase):
    def test_valid_request(self):
        print("Test - Temperature observed - valid request")
        assert Client().get("/api/temperatureObserved").status_code == 200


class InvalidRequestTestCase(TransactionTestCase):
    def test_invalid_request(self):
        db_connection = sqlite3.connect("../WeatherAPI/db.sqlite3")
        db_cmd = db_connection.cursor()
        db_cmd.execute("ALTER TABLE TEMPERATURE_OBSERVED_TABLE RENAME TO AIRTEMP")
        try:
            Client().get("/api/temperatureObserved")
        except TypeError as err:
            print("Test - Temperature observed - DB error - ", str(err))
        db_cmd.execute("ALTER TABLE AIRTEMP RENAME TO TEMPERATURE_OBSERVED_TABLE")
        db_connection.close()
