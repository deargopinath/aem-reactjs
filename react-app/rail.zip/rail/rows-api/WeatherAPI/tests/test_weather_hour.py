from django.test import Client, TestCase, TransactionTestCase
import sqlite3


class WeatherHourlyTest(TestCase):
    urlbase = "/api/weatherHourly/"
    def test_weather_hourly(self):
        print("Test - Weather Hourly - Data available")
        url =self.urlbase + "North West & Central,Eastern/LNW North,East Coast/"
        assert Client().get(url).status_code == 200

    def test_weather_hourly_optional(self):
        print("Test - Weather Hourly - Data available")
        url = self.urlbase + "North West & Central,Eastern/LNW North,East Coast/Air Temperature"
        assert Client().get(url).status_code == 200


class WeatherHourlyErrorTest(TransactionTestCase):
    urlbase = "/api/weatherHourly/"
    def test_weather_hourly_error(self):
        db_connection = sqlite3.connect("../WeatherAPI/db.sqlite3")
        db_cmd = db_connection.cursor()
        db_cmd.execute("ALTER TABLE WEATHER_HOURLY_TABLE RENAME TO HNT_TEST")
        try:
            Client().get(self.urlbase + "North West & Central,Eastern/LNW North,East Coast/")
        except TypeError as err:
            print("Test -  Weather Hourly - DB error - ", str(err))
        db_cmd.execute("ALTER TABLE HNT_TEST RENAME TO WEATHER_HOURLY_TABLE")
        db_connection.close()
