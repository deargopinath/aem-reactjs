import sqlite3
import pandas


def setup_test_data():
    # Table definitions
    REGION_ROUTE = "RegionName varchar, RouteName varchar"
    MDU = ", MDUName varchar"
    WP = ", WeatherParamName varchar"
    VALUE = ", Value varchar"
    WS = ", WeatherStation varchar"
    table_defs = {
        "fire": REGION_ROUTE + MDU + WP + VALUE,
        "hotrail": "MaxAirTemp decimal(10, 2), MaxRailTemp decimal(10, 2), "
        + "PeriodAbove46C int, "
        + REGION_ROUTE
        + MDU
        + ", DateTime datetime, TimeofMaxRailTemp varchar"
        + ", Date date, DayOfWeek varchar",
        "humidity_now": REGION_ROUTE + MDU + VALUE,
        "mdu": REGION_ROUTE + MDU,
        "precipitation_now": REGION_ROUTE + MDU + VALUE,
        "steam": REGION_ROUTE + MDU + WP + VALUE,
        "temperature_now": REGION_ROUTE + MDU + VALUE,
        "temperature_observed": REGION_ROUTE + MDU + WS + VALUE,
        "wind_base": "FileDate varchar, WeatherParamID int, Date varchar, "
        + "DateTime varchar, Latitude decimal(10, 2), Longitude decimal(10, 2), "
        + "RegionID int, RouteID int, MDUID int, DateId int, "
        + "DayOfWeek varchar, Value decimal(10, 2), RAG varchar",
        "wind_current": REGION_ROUTE + MDU + VALUE,
        "wind_hourly": REGION_ROUTE + MDU + WP + VALUE,
        "wind_weekly": REGION_ROUTE + WP + VALUE,
    }

    # Connect to local DB
    db_connection = sqlite3.connect("db.sqlite3")
    db_cmd = db_connection.cursor()

    # Delete and recreate mock data
    for key in table_defs.keys():
        table = key.upper() + "_TABLE"
        db_cmd.execute("DROP TABLE IF EXISTS " + table)
        db_cmd.execute("CREATE TABLE " + table + " (" + table_defs[key] + ")")
        table_data = pandas.read_csv("tests/data/" + key + ".csv")
        table_data.to_sql(table, db_connection, if_exists="replace", index=False)
        print(table + " was created successfully.")

    # Save and exit
    db_connection.commit()
    db_connection.close()


if __name__ == "__main__":
    setup_test_data()
