from django.test import Client, TestCase, TransactionTestCase
import sqlite3


class PrecipitationNowTest(TestCase):
    def test_humidity_now(self):
        print("Test - Precipitation Now - Data available")
        assert Client().get("/api/precipitationNow").status_code == 200


class PrecipitationNowErrorTest(TransactionTestCase):
    def test_humidity_now_error(self):
        db_connection = sqlite3.connect("../WeatherAPI/db.sqlite3")
        db_cmd = db_connection.cursor()
        db_cmd.execute("ALTER TABLE PRECIPITATION_NOW_TABLE RENAME TO HNT_TEST")
        try:
            Client().get("/api/precipitationNow")
        except TypeError as err:
            print("Test -  Precipitation Now - DB error - ", str(err))
        db_cmd.execute("ALTER TABLE HNT_TEST RENAME TO PRECIPITATION_NOW_TABLE")
        db_connection.close()
