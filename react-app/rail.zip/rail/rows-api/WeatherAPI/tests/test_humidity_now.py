from django.test import Client, TestCase, TransactionTestCase
import sqlite3


class HumidityNowTest(TestCase):
    def test_humidity_now(self):
        print("Test - Humidity Now - Data available")
        assert Client().get("/api/humidityNow").status_code == 200


class HumidityNowErrorTest(TransactionTestCase):
    def test_humidity_now_error(self):
        db_connection = sqlite3.connect("../WeatherAPI/db.sqlite3")
        db_cmd = db_connection.cursor()
        db_cmd.execute("ALTER TABLE HUMIDITY_NOW_TABLE RENAME TO HNT_TEST")
        try:
            Client().get("/api/humidityNow")
        except TypeError as err:
            print("Test - Humidity Now - DB error - ", str(err))
        db_cmd.execute("ALTER TABLE HNT_TEST RENAME TO HUMIDITY_NOW_TABLE")
        db_connection.close()
