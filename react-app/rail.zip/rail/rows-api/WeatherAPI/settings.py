"""
Django settings for WeatherAPI project.
"""
from django.utils.crypto import get_random_string
from pathlib import Path
from utils.config_azure import sql_user_name, sql_user_password

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent


# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/4.2/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!

SECRET_KEY = get_random_string(length=64)

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = False

ALLOWED_HOSTS = ["*"]


# Application definition

INSTALLED_APPS = [
    "daphne",
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "readonly_model",
    "rest_framework",
    "corsheaders",
    "pyodbc",
    "WeatherAPIApp.apps.WeatherapiappConfig",
]

MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

CORS_ORIGIN_ALLOW_ALL = True

ROOT_URLCONF = "WeatherAPI.urls"

REST_FRAMEWORK = {
    "DEFAULT_SCHEMA_CLASS": "rest_framework.schemas.coreapi.AutoSchema",
    "EXCEPTION_HANDLER": "utils.exceptionhandler.custom_exception_handler",
}


SWAGGER_SETTINGS = {
    "USE_SESSION_AUTH": False,
}

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "standard": {"format": "%(asctime)s\t%(levelname)s\t%(message)s"},
    },
    "handlers": {
        "file_log": {
            "level": "INFO",
            "class": "logging.handlers.RotatingFileHandler",
            "filename": "django.log",
            "maxBytes": 1024 * 1024 * 5,  # 5MB
            "backupCount": 1,
            "formatter": "standard",
        },
        "console_log": {"class": "logging.StreamHandler", "formatter": "standard"},
    },
    "loggers": {
        "django": {
            "handlers": ["file_log", "console_log"],
            "level": "INFO",
            "propagate": True,
        }
    },
}

WSGI_APPLICATION = "WeatherAPI.wsgi.application"
ASGI_APPLICATION = "WeatherAPI.asgi.application"

# Database
# https://docs.djangoproject.com/en/4.2/ref/settings/#databases

DATABASES = {
    "default": {
        "ENGINE": "mssql",
        "NAME": "sqluksnprdwafdevsqldb6001",
        "HOST": "tcp:sqluksnprdwafdevsqldb6001.database.windows.net,1433",
        "PORT": "1433",
        "USER": sql_user_name(),
        "PASSWORD": sql_user_password(),
        "OPTIONS": {
            "driver": "ODBC Driver 17 for SQL Server",
        },
    }
}


# Password validation
# https://docs.djangoproject.com/en/4.2/ref/settings/#auth-password-validators
AUTH_PREFIX = "django.contrib.auth.password_validation."

AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": AUTH_PREFIX + "UserAttributeSimilarityValidator",
    },
    {
        "NAME": AUTH_PREFIX + "MinimumLengthValidator",
    },
    {
        "NAME": AUTH_PREFIX + "CommonPasswordValidator",
    },
    {
        "NAME": AUTH_PREFIX + "NumericPasswordValidator",
    },
]


# Internationalization
# https://docs.djangoproject.com/en/4.2/topics/i18n/

LANGUAGE_CODE = "en-us"

TIME_ZONE = "UTC"

USE_I18N = True

USE_TZ = True


# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/4.2/howto/static-files/

STATIC_URL = "/static/"
# Default primary key field type
# https://docs.djangoproject.com/en/4.2/ref/settings/#default-auto-field

ALERT_SUMMARY_COUNT_TABLE = "[DEV_DASHBOARD].[VW_DB_ALERT_SUMMARY_DASHBOARD]"
DATABRICKS_SERVER = "adb-6308622097186979.19.azuredatabricks.net"
DATABRICKS_SERVICE = "/sql/1.0/warehouses/b74daa720f1fd5e4"
DATABRICKS_TOKEN = "dapib6eed579d96d1e2cfb80a1e2ef782f2d"
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
FIRE_TABLE = "[DEV_DASHBOARD].[7DAYS_FIRE_RISK_FORECAST_DASHBOARD]"
HOTRAIL_TABLE = "[DEV_DASHBOARD].[HOT_RUNNING_RAIL_DASHBOARD]"
HUMIDITY_NOW_TABLE = "[DEV_DASHBOARD].[VW_DB_HUMIDITY_CURRENT_HOUR_FORECAST_DASHBOARD]"
ORGANIZATIONAL_BOUNDRY_TABLE = "[DEV_DASHBOARD].[ORGANIZATIONAL_BOUNDRY_ASSOC]"
PRECIPITATION_NOW_TABLE = (
    "[DEV_DASHBOARD].[VW_DB_PRECIPITATION_CURRENT_HOUR_FORECAST_DASHBOARD]"
)
STEAM_TABLE = "[DEV_DASHBOARD].[7DAYS_STEAM_RISK_FORECAST_DASHBOARD]"
TEMPERATURE_NOW_TABLE = "[DEV_DASHBOARD].[VW_DB_AIRTEMP_LANDING]"
TEMPERATURE_OBSERVED_TABLE = (
    "[DEV_DASHBOARD].[VW_DB_AIRTEMP_DEWPOINT_CURRENT_HOUR_OBSERVED_DASHBOARD]"
)
USER_PROFILE_GET_TABLE = "[DEV_DASHBOARD].[VW_DB_ROWS_USER_PROFILE]"
USER_PROFILE_SET_TABLE = "[DEV_DASHBOARD].[NR_ROWS_USER]"
WEATHER_HOURLY_TABLE = "[DEV_DASHBOARD].[VW_DB_FORECAST_24HRS_DASHBOARD]"
WEEKLY_HAZARD_WEATHER_TABLE = "[DEV_DASHBOARD].[VW_DB_7DAYS_HAZARD_FORECAST_DASHBOARD]"
WIND_BASE_TABLE = "[DEV_DASHBOARD].[WEATHER_BASE]"
WIND_CURRENT_TABLE = "[DEV_DASHBOARD].[WIND_CURRENT_HOUR_FORECAST_DASHBOARD]"
