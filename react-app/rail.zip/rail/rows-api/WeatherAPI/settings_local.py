# Local environment settings
from django.utils.crypto import get_random_string
from pathlib import Path
from tests.setup_test_data import setup_test_data

setup_test_data()

BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = get_random_string(length=64)
DEBUG = False
ALLOWED_HOSTS = ["*"]

# Application definition

INSTALLED_APPS = [
    "daphne",
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "readonly_model",
    "rest_framework",
    "corsheaders",
    "pyodbc",
    "WeatherAPIApp.apps.WeatherapiappConfig",
]

MIDDLEWARE = [
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

CORS_ORIGIN_ALLOW_ALL = True

ROOT_URLCONF = "WeatherAPI.urls"

REST_FRAMEWORK = {
    "DEFAULT_SCHEMA_CLASS": "rest_framework.schemas.coreapi.AutoSchema",
    "EXCEPTION_HANDLER": "utils.exceptionhandler.custom_exception_handler",
}

SWAGGER_SETTINGS = {
    "USE_SESSION_AUTH": False,
}

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "standard": {"format": "%(asctime)s\t%(levelname)s\t%(message)s"},
    },
    "handlers": {
        "console_log": {"class": "logging.StreamHandler", "formatter": "standard"}
    },
    "loggers": {
        "django": {
            "handlers": ["console_log"],
            "level": "INFO",
            "propagate": True,
        }
    },
}

WSGI_APPLICATION = "WeatherAPI.wsgi.application"
ASGI_APPLICATION = "WeatherAPI.asgi.application"

# Database

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": "db.sqlite3",
        "TEST": {"NAME": "db.sqlite3"},
    }
}


# Password validation
AUTH_PREFIX = "django.contrib.auth.password_validation."
AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": AUTH_PREFIX + "UserAttributeSimilarityValidator",
    },
    {
        "NAME": AUTH_PREFIX + "MinimumLengthValidator",
    },
    {
        "NAME": AUTH_PREFIX + "CommonPasswordValidator",
    },
    {
        "NAME": AUTH_PREFIX + "NumericPasswordValidator",
    },
]

# Internationalization
LANGUAGE_CODE = "en-gb"
TIME_ZONE = "Europe/London"
USE_I18N = True
USE_TZ = True

# Static files (CSS, JavaScript, Images)
STATIC_URL = "/static/"

# Database tables

ALERT_SUMMARY_COUNT_TABLE = "[DEV_DASHBOARD].[VW_DB_ALERT_SUMMARY_DASHBOARD]"
ALERT_SUMMARY_COUNT_TABLE = "[DEV_DASHBOARD].[VW_DB_ALERT_SUMMARY_DASHBOARD]"
DATABRICKS_SERVER = "adb-6308622097186979.19.azuredatabricks.net"
DATABRICKS_SERVICE = "/sql/1.0/warehouses/b74daa720f1fd5e4"
DATABRICKS_TOKEN = "dapib6eed579d96d1e2cfb80a1e2ef782f2d"
FIRE_TABLE = "FIRE_TABLE"
HOTRAIL_TABLE = "HOTRAIL_TABLE"
HUMIDITY_NOW_TABLE = "HUMIDITY_NOW_TABLE"
ORGANIZATIONAL_BOUNDRY_TABLE = "MDU_TABLE"
PRECIPITATION_NOW_TABLE = "PRECIPITATION_NOW_TABLE"
STEAM_TABLE = "STEAM_TABLE"
TEMPERATURE_NOW_TABLE = "TEMPERATURE_NOW_TABLE"
TEMPERATURE_OBSERVED_TABLE = "TEMPERATURE_OBSERVED_TABLE"
USER_PROFILE_GET_TABLE = "[DEV_DASHBOARD].[VW_DB_ROWS_USER_PROFILE]"
USER_PROFILE_SET_TABLE = "[DEV_DASHBOARD].[NR_ROWS_USER]"
WEATHER_HOURLY_TABLE = "[DEV_DASHBOARD].[VW_DB_FORECAST_24HRS_DASHBOARD]"
WEEKLY_HAZARD_WEATHER_TABLE = "WEEKLY_HAZARD_WEATHER_TABLE"
WIND_BASE_TABLE = "WIND_BASE_TABLE"
WIND_CURRENT_TABLE = "WIND_CURRENT_TABLE"
WIND_HOURLY_TABLE = "WIND_HOURLY_TABLE"
WIND_WEEKLY_TABLE = "WIND_WEEKLY_TABLE"
