from django.db import models
from django.conf import settings


class AlertSummaryCountModel(models.Model):
    WeatherParamName = models.CharField(
        max_length=13,
        primary_key=True,
        unique=False,
        default=None,
        blank=True,
        db_column="WeatherParamName",
    )

    RegionName = models.CharField(max_length=50, null=True)
    RouteName = models.CharField(max_length=50, null=True)
    Value = models.TextField(null=True)

    class Meta:
        db_table = settings.ALERT_SUMMARY_COUNT_TABLE
