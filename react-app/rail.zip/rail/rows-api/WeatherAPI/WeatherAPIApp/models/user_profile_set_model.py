from django.db import models
from django.conf import settings


class UserProfileSetModel(models.Model):
    UPNID = models.CharField(
        max_length=100, primary_key=True, unique=False, default=None, db_column="UPNID"
    )
    User_Name = models.CharField(max_length=500, null=True, blank=True)
    Name = models.CharField(max_length=500, null=True, blank=True)
    EmailId = models.CharField(max_length=500, null=True, blank=True)
    Designation = models.CharField(max_length=500, null=True, blank=True)
    Region_Name = models.CharField(max_length=500, null=True, blank=True)
    Route_Name = models.CharField(max_length=500, null=True, blank=True)
    MDU_Name = models.CharField(max_length=500, null=True, blank=True)
    Updated_Date = models.DateField(null=True)

    class Meta:
        db_table = settings.USER_PROFILE_SET_TABLE
