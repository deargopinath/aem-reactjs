from django.db import models
from django.conf import settings


class TempratureObservedModel(models.Model):
    RegionName = models.CharField(
        db_column="RegionName", max_length=50, primary_key=True
    )
    RouteName = models.CharField(db_column="RouteName", max_length=50, null=True)
    MDUName = models.CharField(db_column="MDUName", max_length=50, null=True)
    WeatherStation = models.CharField(
        db_column="WeatherStation", max_length=254, null=True
    )
    Value = models.JSONField(db_column="Value", null=True)

    class Meta:
        db_table = settings.TEMPERATURE_OBSERVED_TABLE
        managed = False
        read_only_model = True
