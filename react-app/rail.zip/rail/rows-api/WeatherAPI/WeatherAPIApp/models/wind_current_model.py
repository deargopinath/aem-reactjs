from django.db import models
from django.conf import settings


class WindCurrentModel(models.Model):
    RegionName = models.CharField(
        max_length=500,
        primary_key=True,
        unique=False,
        default=None,
        blank=True,
        db_column="RegionName",
    )
    RouteName = models.CharField(max_length=500, null=True)
    MDUName = models.CharField(max_length=500, null=True)
    Value = models.CharField(max_length=500, null=True)

    class Meta:
        db_table = settings.WIND_CURRENT_TABLE
