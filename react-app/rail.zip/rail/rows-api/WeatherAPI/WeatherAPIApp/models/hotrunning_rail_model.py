from django.db import models
from django.conf import settings


class HotRunningRailModel(models.Model):
    MaxAirTemp = models.DecimalField(
        decimal_places=2,
        max_digits=10,
        primary_key=True,
        unique=False,
        default=None,
        blank=True,
        db_column="MaxAirTemp",
    )
    MaxRailTemp = models.DecimalField(decimal_places=2, max_digits=10)
    PeriodAbove46C = models.IntegerField()
    RegionName = models.CharField(max_length=500, null=True)
    RouteName = models.CharField(max_length=500, null=True)
    MDUName = models.CharField(max_length=500, null=True)
    DateTime = models.DateTimeField(null=True)
    TimeofMaxRailTemp = models.CharField(max_length=500, null=True)
    Date = models.DateField(null=True)
    DayOfWeek = models.CharField(max_length=500, null=True)

    class Meta:
        db_table = settings.HOTRAIL_TABLE
