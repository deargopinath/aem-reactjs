from django.db import models
from django.conf import settings


class WindBaseModel(models.Model):
    FileDate = models.CharField(
        max_length=500,
        primary_key=True,
        unique=False,
        default=None,
        blank=True,
        db_column="FileDate",
    )
    WeatherParamID = models.IntegerField()
    Date = models.CharField(max_length=500, null=True)
    DateTime = models.CharField(max_length=500, null=True)
    Latitude = models.DecimalField(decimal_places=2, max_digits=10)
    Longitude = models.DecimalField(decimal_places=2, max_digits=10)
    RegionID = models.IntegerField()
    RouteID = models.IntegerField()
    MDUID = models.IntegerField()
    DateId = models.IntegerField()
    DayOfWeek = models.CharField(max_length=500, null=True)
    Value = models.DecimalField(decimal_places=2, max_digits=10)
    RAG = models.CharField(max_length=500, null=True)

    class Meta:
        db_table = settings.WIND_BASE_TABLE
