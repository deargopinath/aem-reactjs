from django.db import models
from django.conf import settings


class HumidityNowModel(models.Model):
    region = models.CharField(db_column="RegionName", max_length=64, primary_key=True)
    route = models.CharField(db_column="RouteName", max_length=64)
    mdu = models.CharField(db_column="MDUName", max_length=64)
    value = models.JSONField(db_column="Value", max_length=64)

    class Meta:
        db_table = settings.HUMIDITY_NOW_TABLE
        managed = False
        read_only_model = True
