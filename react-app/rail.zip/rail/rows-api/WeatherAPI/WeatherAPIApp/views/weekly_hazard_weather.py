import json
from django.http.response import JsonResponse
from rest_framework import generics

from WeatherAPIApp.models import weekly_hazard_weather_model

# Create your views here.
# logger_debug = logging.getLogger('django')
# logger_info = logging.getLogger('django')


class WeeklyHazardWeatherAPI(generics.GenericAPIView):
    def get(self, request, regionname, routename):
        try:
            # windWeeklyDataDetails = WindWeekly.objects.all()
            # routeName = request.GET.get('RouteName')
            # routeName="Kent"
            if regionname is not None and routename is not None:
                Weekly_Hazard_Data_Details = (
                    weekly_hazard_weather_model.WeeklyHazardWeatherModel.objects.filter(
                        RegionName=regionname, RouteName=routename
                    )
                )
            else:
                Weekly_Hazard_Data_Details = (
                    weekly_hazard_weather_model.WeeklyHazardWeatherModel.objects.all()
                )

            response_data = []
            for weekly_data in Weekly_Hazard_Data_Details:
                json_weekly_string = weekly_data.Value
                try:
                    parsed_weekly_json = json.loads(json_weekly_string)
                except Exception as ex:
                    return f"The error '{ex}' occurred."

                instance_data_weather_weekly = {
                    "RegionName": weekly_data.RegionName,
                    "RouteName": weekly_data.RouteName,
                    "WeatherParamName": weekly_data.WeatherParamName,
                    "Value": parsed_weekly_json,
                }

                response_data.append(instance_data_weather_weekly)

            response = JsonResponse(
                response_data,
                content_type="application/json; charset=utf-8",
                safe=False,
            )
            # logger_debug.info('Wind Weekly response generated')
            return response

        except Exception:
            # logger_info.info(f"The error '{e}' occurred.")
            return (
                {
                    "error": "An error occurred while fetching\
                     the details of Wind Weekly."
                },
                500,
            )
