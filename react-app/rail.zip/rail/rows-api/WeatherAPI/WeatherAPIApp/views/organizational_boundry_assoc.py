from django.http.response import JsonResponse
from rest_framework import generics

from WeatherAPIApp.models import organizational_boundry_model

from WeatherAPIApp.serializers import organizational_boundry_serializer

# Create your views here.
# logger_debug = logging.getLogger('django')
# logger_info = logging.getLogger('django')


class OrganizationalBoundryAPI(generics.GenericAPIView):
    def get(self, request):
        try:
            organizational_Boundry_Assoc = (
                organizational_boundry_model.OrganizationalBoundryModel.objects.all()
            )
            organizational_Boundry_Assoc_serializer = (
                organizational_boundry_serializer.OrganizationalBoundryAssocSerializer(
                    organizational_Boundry_Assoc, many=True
                )
            )
            return JsonResponse(
                organizational_Boundry_Assoc_serializer.data, safe=False
            )

        except Exception:
            # logger_info.info(f"The error '{e}' occurred.")
            return (
                {
                    "error": "An error occurred while fetching\
                     the details of organizational boundry."
                },
                500,
            )
