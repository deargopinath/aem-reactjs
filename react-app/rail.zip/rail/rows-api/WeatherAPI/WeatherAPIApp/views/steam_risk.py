import json
from django.http.response import JsonResponse
from rest_framework import generics

from WeatherAPIApp.models import steam_risk_model

# logger_debug = logging.getLogger('django')
# logger_info = logging.getLogger('django')


class WeatherSteamAPI(generics.GenericAPIView):
    def get(self, request):
        try:
            # logger_info.info('Steam Risk Started')
            steam_Risk_Indexes = steam_risk_model.SteamRiskModel.objects.all()

            response_data = []
            for steam_Risk_Index in steam_Risk_Indexes:
                json_steam_string = steam_Risk_Index.Value
                try:
                    parsed_json_steam = json.loads(json_steam_string)
                except Exception as ex:
                    return f"The error '{ex}' occurred."

                steam_data = {
                    "RouteName": steam_Risk_Index.RouteName,
                    "RegionName": steam_Risk_Index.RegionName,
                    "MDUName": steam_Risk_Index.MDUName,
                    "WeatherParamName": steam_Risk_Index.WeatherParamName,
                    "Value": parsed_json_steam,
                }

                response_data.append(steam_data)

            response = JsonResponse(
                response_data,
                content_type="application/json; charset=utf-8",
                safe=False,
            )
            # logger_info.info('Steam Risk response generated')
            return response
        except Exception:
            # logger_info.info(f"The error '{e}' occurred.")
            return (
                {
                    "error": "An error occurred while fetching\
                     the details of Steam Risk."
                },
                500,
            )
