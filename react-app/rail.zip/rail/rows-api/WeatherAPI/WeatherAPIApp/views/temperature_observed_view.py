from django.http import HttpResponse, HttpResponseServerError
from WeatherAPIApp.models import TempratureObservedModel
import json
import logging


# Air temperature observed
def get_temperature_observed(request):
    LOG = logging.getLogger("django")
    LOG.info("temperature_observed - Received request - " + request.path)
    try:
        LOG.info("temperature_observed - Sending data from the DB")
        return HttpResponse(
            json.dumps(
                list(
                    {
                        "RegionName": row.RegionName,
                        "RouteName": row.RouteName,
                        "MDUName": row.MDUName,
                        "WeatherStation": row.WeatherStation,
                        "Value": row.Value,
                    }
                    for row in TempratureObservedModel.objects.all()
                )
            ),
            content_type="application/json",
        )
    except Exception:
        LOG.error("temperature_observed - Database connection failed")
        return HttpResponseServerError
