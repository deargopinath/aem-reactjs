from django.http import JsonResponse
from rest_framework import generics
from databricks import sql
from django.conf import settings


class HourlyViewAPI(generics.GenericAPIView):
    def get(self, request):
        try:
            with sql.connect(
                server_hostname=settings.DATABRICKS_SERVER,
                http_path=settings.DATABRICKS_SERVICE,
                access_token=settings.DATABRICKS_TOKEN,
            ) as connection:
                with connection.cursor() as cursor:
                    cursor.execute("select * from poc_delta.vw_hour_wind_data")
                    result = cursor.fetchall()
                    #    for row in result:
                    return JsonResponse({"data": result})

        except Exception:
            # logger_info.info(f"The error '{e}' occurred.")
            return (
                {
                    "error": "An error occurred while fetching\
                     the details of hourly view."
                },
                500,
            )
