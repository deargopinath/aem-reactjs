from django.http.response import JsonResponse
from rest_framework import generics
import json

from WeatherAPIApp.models import alert_summary_count_model


class AlertSummaryCountAPI(generics.GenericAPIView):
    def get(self, request, regionname, routename):
        try:
            if regionname is not None and routename is not None:
                alert_Summary_Details = (
                    alert_summary_count_model.AlertSummaryCountModel.objects.filter(
                        RegionName=regionname, RouteName=routename
                    )
                )

            response_data = []
            for alert_summary in alert_Summary_Details:
                alert_json_string = alert_summary.Value
                try:
                    parsed_alert_json = json.loads(alert_json_string)
                except Exception:
                    return JsonResponse(
                        {"error": "An error occurred while parsing the Json"},
                        status=500,
                    )
                instance_alert_summary_count = {
                    "RegionName": alert_summary.RegionName,
                    "RouteName": alert_summary.RouteName,
                    "WeatherParamName": alert_summary.WeatherParamName,
                    "Value": parsed_alert_json,
                }
                response_data.append(instance_alert_summary_count)

            response = JsonResponse(
                response_data,
                content_type="application/json; charset=utf-8",
                safe=False,
            )
            return response

        except Exception:
            return (
                {
                    "error": "An error occurred while fetching\
                     the details of Alert Summary Count."
                },
                500,
            )
