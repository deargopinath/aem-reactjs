from django.http.response import JsonResponse
from rest_framework import generics

from WeatherAPIApp.models import hotrunning_rail_model

from WeatherAPIApp.serializers import hotrunning_rail_serializer

# Create your views here.
# logger_debug = logging.getLogger('django')
# logger_info = logging.getLogger('django')


class HotRunningRailAPI(generics.GenericAPIView):
    def get(self, request):
        try:
            hot_Running_Rails = (
                hotrunning_rail_model.HotRunningRailModel.objects.all().order_by(
                    "Date", "RegionName"
                )
            )
            hot_Running_Rails_serializer = (
                hotrunning_rail_serializer.HotRunningRailSerializer(
                    hot_Running_Rails, many=True
                )
            )
            return JsonResponse(hot_Running_Rails_serializer.data, safe=False)

        except Exception:
            # logger_info.info(f"The error '{e}' occurred.")
            return (
                {
                    "error": "An error occurred while fetching \
                     the details of hot running rail."
                },
                500,
            )
