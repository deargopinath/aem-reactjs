import json
from django.http.response import JsonResponse
from rest_framework import generics

from WeatherAPIApp.models import wind_current_model

# Create your views here.
# logger_debug = logging.getLogger('django')
# logger_info = logging.getLogger('django')


class WindCurrentAPI(generics.GenericAPIView):
    def get(self, request, regionname, routename):
        try:
            wind_Current_Data_Details = (
                wind_current_model.WindCurrentModel.objects.all()
            )
            response_data = []
            for wind_current_data in wind_Current_Data_Details:
                json_wind_current_string = wind_current_data.Value
                try:
                    parsed_wind_current_json = json.loads(json_wind_current_string)
                except Exception as ex:
                    return f"The error '{ex}' occurred."

                instance_data_wind_current = {
                    "RegionName": wind_current_data.RegionName,
                    "RouteName": wind_current_data.RouteName,
                    "MDUName": wind_current_data.MDUName,
                    "Value": parsed_wind_current_json,
                }

                response_data.append(instance_data_wind_current)

            response = JsonResponse(
                response_data,
                content_type="application/json; charset=utf-8",
                safe=False,
            )
            # logger_debug.info('Wind Current response generated')
            return response

        except Exception:
            # logger_info.info(f"The error '{e}' occurred.")
            return (
                {
                    "error": "An error occurred while fetching\
                     the details of Wind Current."
                },
                500,
            )
