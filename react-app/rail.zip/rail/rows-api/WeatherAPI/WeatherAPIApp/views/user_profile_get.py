from django.http.response import JsonResponse
from rest_framework import generics

from WeatherAPIApp.models import user_profile_get_model

from WeatherAPIApp.serializers import user_profile_get_serializer


class UserProfileAPI(generics.GenericAPIView):
    def get(self, request, id):
        try:
            if id is not None:
                user_Profile_Details = (
                    user_profile_get_model.UserProfileGetModel.objects.filter(UPNID=id)
                )
            else:
                user_Profile_Details = (
                    user_profile_get_model.UserProfileGetModel.objects.all()
                )

            user_Profile_Details_serializer = (
                user_profile_get_serializer.UserProfileGetSerializer(
                    user_Profile_Details, many=True
                )
            )

            return JsonResponse(user_Profile_Details_serializer.data, safe=False)

        except Exception:
            return (
                {
                    "error": "An error occurred while fetching \
                     the details of user."
                },
                500,
            )
