from django.http import HttpResponse, HttpResponseServerError
from WeatherAPIApp.models import TemperatureNowModel
import json
import logging


# Current air temperature for a specific region and route
def get_temperature_now(request):
    LOG = logging.getLogger("django")
    LOG.info("get_temperature_now - Received request - " + request.path)
    try:
        LOG.info("get_temperature_now - Sending data from the DB")
        return HttpResponse(
            json.dumps(
                list(
                    {
                        "RegionName": row.region,
                        "RouteName": row.route,
                        "MDUName": row.mdu,
                        "Value": row.value,
                    }
                    for row in TemperatureNowModel.objects.all()
                )
            ),
            content_type="application/json",
        )
    except Exception:
        LOG.error("get_temperature_now - Database connection failed")
        return HttpResponseServerError
