from django.http.response import JsonResponse
from rest_framework import generics

from WeatherAPIApp.models import wind_base_model

from WeatherAPIApp.serializers import wind_base_serializer

# Create your views here.
# logger_debug = logging.getLogger('django')
# logger_info = logging.getLogger('django')

"""Added for POC to get the weather data"""


class WindWeatherDataAPI(generics.GenericAPIView):
    def get(self, request):
        try:
            wind_Weather_Data = wind_base_model.WindBaseModel.objects.all()
            # Date = request.GET.get('RouteName')
            # mduID=13
            # date='2023-09-08'
            # if mduID is not None:
            #     windWeatherData = WindWeatherData.objects.filter(MDUID=mduID)
            wind_Weather_Data_serializer = (
                wind_base_serializer.WindWeatherDataSerializer(
                    wind_Weather_Data, many=True
                )
            )
            return JsonResponse(wind_Weather_Data_serializer.data, safe=False)

        except Exception:
            # logger_info.info(f"The error '{e}' occurred.")
            return (
                {
                    "error": "An error occurred while fetching\
                    the details of\
                     Wind Current."
                },
                500,
            )
