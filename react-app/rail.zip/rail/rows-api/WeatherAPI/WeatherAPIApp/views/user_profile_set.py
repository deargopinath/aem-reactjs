from django.http.response import JsonResponse
from rest_framework import generics
from rest_framework.parsers import JSONParser
from WeatherAPIApp.models import user_profile_set_model

# from WeatherAPIApp.models import userprofilemodel

from WeatherAPIApp.serializers import user_profile_set_serializer


class UserProfileSetAPI(generics.GenericAPIView):
    def post(self, request):
        try:
            user_data = JSONParser().parse(request)
            user = user_profile_set_model.UserProfileSetModel.objects.filter(
                UPNID=user_data["UPNID"]
            ).first()

            if user is not None:
                user_profile_set_detail_serializer = (
                    user_profile_set_serializer.UserProfileSetSerializer(
                        user, data=user_data
                    )
                )
                if user_profile_set_detail_serializer.is_valid():
                    user_profile_set_detail_serializer.save()
                    return JsonResponse("User profile updated Successfully", safe=False)
                return JsonResponse("Failed to update user profile", safe=False)
            else:
                user_profile_set_detail_serializer = (
                    user_profile_set_serializer.UserProfileSetSerializer(data=user_data)
                )
                if user_profile_set_detail_serializer.is_valid():
                    user_profile_set_detail_serializer.save()
                    return JsonResponse("User profile added Successfully", safe=False)
                return JsonResponse("Failed to add user profile", safe=False)

        except Exception:
            return (
                {
                    "error": "An error occurred while adding \
                     the details of user."
                },
                500,
            )
