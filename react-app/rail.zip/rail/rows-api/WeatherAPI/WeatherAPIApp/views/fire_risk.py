import json
from django.http.response import JsonResponse
from rest_framework import generics

from WeatherAPIApp.models import fire_risk_model

#  logger_debug = logging.getLogger('django')
#  logger_info = logging.getLogger('django')


class WeatherFireAPI(generics.GenericAPIView):
    def get(self, request):
        try:
            # logger_debug.info('Fire Risk Started')
            fire_Risk_Indexes = fire_risk_model.FireRiskModel.objects.all()

            response_data = []
            for fire_Risk_Index in fire_Risk_Indexes:
                json_fire_string = fire_Risk_Index.Value
                try:
                    parsed_fire_json = json.loads(json_fire_string)
                except Exception as ex:
                    return f"The error '{ex}' occurred."

                instance_data = {
                    "RouteName": fire_Risk_Index.RouteName,
                    "RegionName": fire_Risk_Index.RegionName,
                    "MDUName": fire_Risk_Index.MDUName,
                    "WeatherParamName": fire_Risk_Index.WeatherParamName,
                    "Value": parsed_fire_json,
                }

                response_data.append(instance_data)

            response = JsonResponse(
                response_data,
                content_type="application/json; charset=utf-8",
                safe=False,
            )
            # logger_debug.info('Fire Risk response generated')
            return response

        except Exception:
            # logger_debug.info(f"The error '{e}' occurred.")
            return (
                {
                    "error": "An error occurred while\
                    fetching the details of Fire Risk."
                },
                500,
            )
