import json
from django.http.response import JsonResponse
from rest_framework import generics
from django.db.models import Q

from WeatherAPIApp.models import weather_hourly_model

# Create your views here.

class WeatherHourlyAPI(generics.GenericAPIView):
    def get(self, request, regionname, routename,weatherparamname=None):
        try:
            if regionname is not None and routename is not None and weatherparamname is not None:
                regionnamelist   = regionname.split(',')
                routenamelist   =  routename.split(',')
                weatherparamnamelist = weatherparamname.split(',')

                weather_Hourly_Data_Details = weather_hourly_model.WeatherHourlyModel.objects.filter((Q(RegionName__in=regionnamelist) & Q(RouteName__in=routenamelist)) & Q(WeatherParamName__in = weatherparamnamelist))

            else:
                regionnamelist   = regionname.split(',')
                routenamelist   =  routename.split(',')
                weather_Hourly_Data_Details = (
                    weather_hourly_model.WeatherHourlyModel.objects.filter((Q(RegionName__in=regionnamelist) & Q(RouteName__in=routenamelist)))
                )   

            response_data = []
            for weather_hourly_data in weather_Hourly_Data_Details:
                json_wind_hourly_string = weather_hourly_data.Value
                try:
                    parsed_weather_hourly_json = json.loads(json_wind_hourly_string)
                except Exception as ex:
                    return f"The error '{ex}' occurred."

                instance_data_weather_hourly = {
                    "RegionName": weather_hourly_data.RegionName,
                    "RouteName": weather_hourly_data.RouteName,
                    "MDUName": weather_hourly_data.MDUName,
                    "WeatherParamName": weather_hourly_data.WeatherParamName,
                    "Value": parsed_weather_hourly_json,
                }

                response_data.append(instance_data_weather_hourly)

            response = JsonResponse(
                response_data,
                content_type="application/json; charset=utf-8",
                safe=False,
            )
            # logger_debug.info('Wind Hourly response generated')
            return response

        except Exception:
            # logger_info.info(f"The error '{e}' occurred.")
            return (
                {
                    "error": "An error occurred while fetching\
                     the details of Wind Hourly."
                },
                500,
            )
