from django.urls import re_path
from .views import (
    fire_risk,
    get_temperature_now,
    get_humidity_now,
    hotrunning_rail,
    hourly_view_weather,
    organizational_boundry_assoc,
    steam_risk,
    user_profile_get,
    user_profile_set,
    weather_base,
    weather_hourly,
    weekly_hazard_weather,
    wind_current,
    alert_summary_count,
    get_precipitation_now,
    get_temperature_observed,
)
from django.conf.urls.static import static
from django.conf import settings

# Configure your URLs here.

urlpatterns = [
    re_path(
        r"^api/fireRiskIndex$", fire_risk.WeatherFireAPI.as_view(), name="fireRiskIndex"
    ),
    re_path(
        r"^api/steamRiskIndex$",
        steam_risk.WeatherSteamAPI.as_view(),
        name="steamRiskIndex",
    ),
    re_path(
        r"^api/hotRunningRail$",
        hotrunning_rail.HotRunningRailAPI.as_view(),
        name="hotRunnungRail",
    ),
    re_path(r"^api/humidityNow$", get_humidity_now, name="humidityNow"),
    re_path(
        r"^api/organizationalBoundryAssoc$",
        organizational_boundry_assoc.OrganizationalBoundryAPI.as_view(),
        name="organizationalBoundry",
    ),
    re_path(r"^api/precipitationNow$", get_precipitation_now, name="precipitationNow"),
    re_path(r"^api/temperatureNow$", get_temperature_now, name="temperatureNow"),
    re_path(
        r"^api/temperatureObserved$",
        get_temperature_observed,
        name="temperatureObserved",
    ),
    re_path(
        r"^api/weeklyHazardWeather/(?P<regionname>.+)/(?P<routename>.+)/$",
        weekly_hazard_weather.WeeklyHazardWeatherAPI.as_view(),
        name="weeklyHazardWeather",
    ),
    re_path(
        r"^api/weatherHourly/(?P<regionname>[\w|\W]+)/(?P<routename>[\w|\W]+)/(?P<weatherparamname>[\w|\W]+)/$",
        weather_hourly.WeatherHourlyAPI.as_view(),
        name="weatherHourly",
        #re_path(r'^path/to/api/end_point/(?P<player_ids>[\d,]+)/', views.some_view),
    ),
    re_path(
        r"^api/weatherHourly/(?P<regionname>[\w|\W]+)/(?P<routename>[\w|\W]+)/$",
        weather_hourly.WeatherHourlyAPI.as_view(),
        name="weatherHourly",
        #re_path(r'^path/to/api/end_point/(?P<player_ids>[\d,]+)/', views.some_view),
    ),
    re_path(
        r"^api/windCurrent$", wind_current.WindCurrentAPI.as_view(), name="windCurrent"
    ),
    re_path(
        r"^api/windWeather$",
        weather_base.WindWeatherDataAPI.as_view(),
        name="windWeather",
    ),
    re_path(
        r"^api/hourlyViewWeather$",
        hourly_view_weather.HourlyViewAPI.as_view(),
        name="hourlyViewWeather",
    ),
    re_path(
        r"^api/profile/(?P<id>.+)/$",
        user_profile_get.UserProfileAPI.as_view(),
        name="userProfile",
    ),
    re_path(
        r"^api/profile$",
        user_profile_set.UserProfileSetAPI.as_view(),
        name="userProfileSet",
    ),
    re_path(
        r"^api/alertSummaryCount/(?P<regionname>.+)/(?P<routename>.+)/$",
        alert_summary_count.AlertSummaryCountAPI.as_view(),
        name="alertSummaryCount",
    ),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
