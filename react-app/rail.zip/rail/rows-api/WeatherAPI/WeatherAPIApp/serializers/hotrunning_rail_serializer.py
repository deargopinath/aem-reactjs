from rest_framework import serializers
from WeatherAPIApp.models import hotrunning_rail_model


class HotRunningRailSerializer(serializers.ModelSerializer):
    class Meta:
        model = hotrunning_rail_model.HotRunningRailModel
        fields = "__all__"
