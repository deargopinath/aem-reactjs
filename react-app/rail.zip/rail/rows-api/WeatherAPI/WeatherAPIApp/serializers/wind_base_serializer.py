from rest_framework import serializers
from WeatherAPIApp.models import wind_base_model


class WindWeatherDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = wind_base_model.WindBaseModel
        fields = "__all__"
