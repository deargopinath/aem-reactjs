from rest_framework import serializers
from WeatherAPIApp.models import weekly_hazard_weather_model


class WeeklyHazardWeatherSerializer(serializers.ModelSerializer):
    class Meta:
        model = weekly_hazard_weather_model.WeeklyHazardWeatherModel
        fields = "__all__"
