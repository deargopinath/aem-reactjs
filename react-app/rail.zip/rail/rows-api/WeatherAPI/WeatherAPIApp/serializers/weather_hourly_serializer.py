from rest_framework import serializers
from WeatherAPIApp.models import weather_hourly_model


class WeatherHourlySerializer(serializers.ModelSerializer):
    class Meta:
        model = weather_hourly_model.WeatherHourlyModel
        fields = "__all__"
