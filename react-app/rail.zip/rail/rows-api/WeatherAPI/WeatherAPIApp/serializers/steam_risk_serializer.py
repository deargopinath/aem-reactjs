from rest_framework import serializers
from WeatherAPIApp.models import steam_risk_model


class SteamRiskIndexSerializer(serializers.ModelSerializer):
    class Meta:
        model = steam_risk_model.SteamRiskModel
        fields = "__all__"
