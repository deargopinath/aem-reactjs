from rest_framework import serializers
from WeatherAPIApp.models import user_profile_get_model


class UserProfileGetSerializer(serializers.ModelSerializer):
    class Meta:
        model = user_profile_get_model.UserProfileGetModel
        fields = "__all__"
