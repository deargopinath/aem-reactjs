from rest_framework import serializers
from WeatherAPIApp.models import organizational_boundry_model


class OrganizationalBoundryAssocSerializer(serializers.ModelSerializer):
    class Meta:
        model = organizational_boundry_model.OrganizationalBoundryModel
        fields = "__all__"
