from rest_framework import serializers
from WeatherAPIApp.models import wind_current_model


class WindCurrentSerializer(serializers.ModelSerializer):
    class Meta:
        model = wind_current_model.WindCurrentModel
        fields = "__all__"
