from rest_framework import serializers
from WeatherAPIApp.models import fire_risk_model


class FireRiskIndexSerializer(serializers.ModelSerializer):
    class Meta:
        model = fire_risk_model.FireRiskModel
        fields = "__all__"
