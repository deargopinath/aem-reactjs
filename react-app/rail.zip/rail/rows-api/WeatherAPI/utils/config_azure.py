import os
from azure.identity import ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient
from dotenv import load_dotenv

load_dotenv()
# Grabbing environment variables from the .env file
KVUri = os.getenv("KEY_VAULT_URI")

# Creating a variable to store the key vault value in
SQL_USERNAME = "sqlusername"
SQL_PASSWORD = "sqluserpass"
DJANGO_SECRETKEY = "djangokey"

managedIdentityCredential = ManagedIdentityCredential()
key_client = SecretClient(vault_url=KVUri, credential=managedIdentityCredential)


def sql_user_name():
    # Lastly the secret is retrieved from the key vault using get_secret
    get_sql_user_name = key_client.get_secret(SQL_USERNAME).value
    return get_sql_user_name


def sql_user_password():
    # Lastly the secret is retrieved from the key vault using get_secret
    get_sql_user_password = key_client.get_secret(SQL_PASSWORD).value
    return get_sql_user_password


def django_secret_key():
    # Lastly the secret is retrieved from the key vault using get_secret
    get_django_secret_key = key_client.get_secret(DJANGO_SECRETKEY).value
    return get_django_secret_key
