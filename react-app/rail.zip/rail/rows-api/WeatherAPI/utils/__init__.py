from .config_azure import sql_user_name, sql_user_password, django_secret_key
