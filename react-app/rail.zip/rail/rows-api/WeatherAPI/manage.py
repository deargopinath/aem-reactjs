#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
from django.core.management import execute_from_command_line
import os
import sys


def main():
    settings_file = "settings"
    if sys.argv.__contains__("test"):
        sys.argv.append("--keepdb")
        settings_file = "settings_local"

    os.environ.setdefault("DJANGO_SETTINGS_MODULE", settings_file)
    execute_from_command_line(sys.argv)


if __name__ == "__main__":
    main()
