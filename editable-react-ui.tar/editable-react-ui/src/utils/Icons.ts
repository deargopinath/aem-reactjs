import {library} from '@fortawesome/fontawesome-svg-core'
import {faCheckSquare, faChevronLeft, faSearch, faHeadphonesAlt,
  faMusic, faCamera, faPaintBrush, faFutbol, faTheaterMasks}
  from '@fortawesome/free-solid-svg-icons'
library.add(faCheckSquare, faChevronLeft, faSearch, faHeadphonesAlt,
  faMusic, faCamera, faPaintBrush, faFutbol, faTheaterMasks)
