const http = require('http');
const server = http.createServer((req, res) => {
  let output = { data: 'Mock API' };
  let code = 404;
  if (req.method === 'OPTIONS') {
    code = 204;
  }
  if (req.method === 'GET' || req.method === 'POST') {
    if (req.headers.authorization != undefined && req.headers['authorization'].length > 10) {
      code = 200;
      try {
        let mockData = (req.url === '/api/profile') ? './profile.json' : './quotes.json';
        output = require(mockData);
      } catch (err) {
        console.log(err.name + ' : ' + err.message);
        output = { error: err.message };
      }
    } else {
      code = 403
      output = {error: 'SSO token could not be verified'}
    }
  }
  const headerOptions = {
    'Access-Control-Allow-Headers': '*',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'OPTIONS, POST, GET',
    'Content-Type': 'application/json',
  };
  res.writeHead(code, headerOptions);
  if (code !== 204) {
    res.write(JSON.stringify(output));
  }
  res.end();
});

server.listen(8888);
console.log('Success: Quotes service started at http://localhost:8888');
