export const environment = {
  production: true
};

export const APP_ID = 'APP_ID'
export const SSO_URL = 'https://login.microsoftonline.com/AZURE_TENANT_ID'
export const LOGIN_REDIRECT = 'https://ANGULAR_UI_HOST/dashboard'
export const LOGOUT_REDIRECT = 'https://ANGULAR_UI_HOST/logout'

export const QUOTES_API = 'https://API_HOST/api/quotes'
export const PROFILE_API = 'https://graph.microsoft.com/v1.0/me'