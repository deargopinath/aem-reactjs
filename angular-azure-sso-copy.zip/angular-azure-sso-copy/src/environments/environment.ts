import 'zone.js/plugins/zone-error';

export const environment = {
  production: false
};

export const APP_ID = 'APP_ID'
export const SSO_URL = 'https://login.microsoftonline.com/AZURE_TENANT_ID'

export const LOGIN_REDIRECT = 'http://localhost:4200/dashboard'
export const LOGOUT_REDIRECT = 'http://localhost:4200/logout'

export const QUOTES_API = 'http://localhost:8888/api/quotes'
export const PROFILE_API = 'https://graph.microsoft.com/v1.0/me'
// export const PROFILE_API = 'http://localhost:8888/api/profile'